-- =========================================================
-- Zella workflows, part 2: leads, tasks, quotes, duplicates.
-- Run AFTER part 1 (1_callbacks section). Safe to re-run.
-- =========================================================

alter table public.customers
  add column if not exists lead_stage text,
  add column if not exists assigned_to uuid,
  add column if not exists priority text,
  add column if not exists qualification jsonb not null default '{}'::jsonb,
  add column if not exists qualification_result text,
  add column if not exists contact_deadline_at timestamptz,
  add column if not exists next_follow_up_at timestamptz,
  add column if not exists lost_reason text,
  add column if not exists lost_at timestamptz,
  add column if not exists reactivate_after timestamptz,
  add column if not exists converted_at timestamptz;
do $$ begin
  alter table public.customers add constraint customers_lead_stage_chk
    check (lead_stage is null or lead_stage in ('new', 'contacted', 'qualified', 'unqualified', 'quote_sent', 'won', 'lost'));
  alter table public.customers add constraint customers_priority_chk check (priority is null or priority in ('normal', 'high', 'urgent'));
exception when duplicate_object then null; end $$;
create index if not exists customers_lead_stage_idx on public.customers (business_id, lead_stage);

-- Staff to-do items created by workflows (or by hand)
create table if not exists public.crm_tasks (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete cascade,
  kind text not null default 'follow_up',
  title text not null,
  body text,
  priority text not null default 'normal' check (priority in ('normal', 'high', 'urgent')),
  status text not null default 'open' check (status in ('open', 'done', 'cancelled')),
  due_at timestamptz,
  assigned_to uuid,
  source text not null default 'automation' check (source in ('automation', 'ai', 'staff')),
  entity_id uuid,
  escalated_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists crm_tasks_biz_idx on public.crm_tasks (business_id, status, due_at);
create unique index if not exists crm_tasks_one_open_idx on public.crm_tasks (business_id, customer_id, kind)
  where status = 'open' and customer_id is not null and kind in ('overdue_contact', 'duplicate_review', 'onboarding', 'quote_review');

create table if not exists public.lead_rules (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  -- all keys must match: {"source":"website","keyword":"emergency","answer_equals":{"urgent":"yes"}}
  match jsonb not null default '{}'::jsonb,
  assign_to uuid,
  set_priority text check (set_priority in ('normal', 'high', 'urgent')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.lead_questions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  key text not null,
  question text not null,
  required boolean not null default false,
  -- optional rule that counts as "qualified": {"equals":"yes"} or {"min":3}
  qualifies_when jsonb,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  unique (business_id, key)
);
create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  title text not null,
  status text not null default 'issued' check (status in ('issued', 'accepted', 'declined', 'expired')),
  issued_at timestamptz not null default now(),
  expires_at timestamptz,
  follow_ups_sent integer not null default 0,
  max_follow_ups integer not null default 3,
  follow_up_every_days integer not null default 3,
  next_follow_up_at timestamptz,
  closed_at timestamptz,
  created_by uuid
);
create index if not exists quotes_biz_idx on public.quotes (business_id, status, next_follow_up_at);
create table if not exists public.duplicate_reviews (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete cascade,   -- the existing record it might match
  incoming jsonb not null,
  status text not null default 'open' check (status in ('open', 'merged', 'kept_separate', 'dismissed')),
  resolved_by uuid, resolved_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists duplicate_reviews_biz_idx on public.duplicate_reviews (business_id, status);

alter table public.crm_tasks enable row level security;
alter table public.lead_rules enable row level security;
alter table public.lead_questions enable row level security;
alter table public.quotes enable row level security;
alter table public.duplicate_reviews enable row level security;
do $$ declare t text; begin
  foreach t in array array['crm_tasks','quotes','duplicate_reviews'] loop
    execute format('drop policy if exists %I on public.%I', t || '_select', t);
    execute format('create policy %I on public.%I for select to authenticated using (public.zella_is_member(business_id))', t || '_select', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('revoke insert, update, delete on public.%I from authenticated', t);
    execute format('grant select on public.%I to authenticated', t);
  end loop;
  foreach t in array array['lead_rules','lead_questions'] loop
    execute format('drop policy if exists %I on public.%I', t || '_all', t);
    execute format('create policy %I on public.%I for all to authenticated using (public.zella_is_member(business_id)) with check (public.zella_is_member(business_id))', t || '_all', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- ---- helpers ------------------------------------------------------------
create or replace function public.zella_create_task(p_business_id uuid, p_customer_id uuid, p_kind text, p_title text, p_body text default null,
  p_priority text default 'normal', p_due_at timestamptz default null, p_assigned_to uuid default null, p_source text default 'automation', p_entity_id uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.crm_tasks (business_id, customer_id, kind, title, body, priority, due_at, assigned_to, source, entity_id)
  values (p_business_id, p_customer_id, coalesce(p_kind, 'follow_up'), p_title, p_body, case when p_priority in ('high','urgent') then p_priority else 'normal' end,
          p_due_at, p_assigned_to, case when p_source in ('automation','ai','staff') then p_source else 'automation' end, p_entity_id)
  on conflict (business_id, customer_id, kind) where status = 'open' and customer_id is not null and kind in ('overdue_contact','duplicate_review','onboarding','quote_review')
  do nothing returning id into v_id;
  return v_id;
end $$;
revoke all on function public.zella_create_task(uuid, uuid, text, text, text, text, timestamptz, uuid, text, uuid) from public, anon, authenticated;
grant execute on function public.zella_create_task(uuid, uuid, text, text, text, text, timestamptz, uuid, text, uuid) to service_role;

create or replace function public.zella_staff_create_task(p_business_id uuid, p_customer_id uuid, p_title text, p_due_at timestamptz default null, p_assigned_to uuid default null, p_priority text default 'normal')
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  if nullif(trim(coalesce(p_title, '')), '') is null then raise exception 'EMPTY_TITLE'; end if;
  if p_customer_id is not null and not exists (select 1 from public.customers where id = p_customer_id and business_id = p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  insert into public.crm_tasks (business_id, customer_id, kind, title, priority, due_at, assigned_to, source)
  values (p_business_id, p_customer_id, 'follow_up', trim(p_title), case when p_priority in ('high','urgent') then p_priority else 'normal' end, p_due_at, p_assigned_to, 'staff') returning id into v_id;
  return v_id;
end $$;
create or replace function public.zella_complete_task(p_task_id uuid, p_cancel boolean default false) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_b uuid;
begin
  select business_id into v_b from public.crm_tasks where id = p_task_id;
  if v_b is null or not public.zella_is_member(v_b) then raise exception 'NOT_ALLOWED'; end if;
  update public.crm_tasks set status = case when p_cancel then 'cancelled' else 'done' end, completed_at = now() where id = p_task_id and status = 'open';
  return found;
end $$;
revoke all on function public.zella_staff_create_task(uuid, uuid, text, timestamptz, uuid, text) from public, anon;
revoke all on function public.zella_complete_task(uuid, boolean) from public, anon;
grant execute on function public.zella_staff_create_task(uuid, uuid, text, timestamptz, uuid, text) to authenticated, service_role;
grant execute on function public.zella_complete_task(uuid, boolean) to authenticated, service_role;

-- Routing + priority rules. First match in sort order wins; otherwise the
-- team member with the fewest open leads gets it.
create or replace function public.zella_apply_lead_rules(p_customer_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c record; r record; v_assign uuid; v_priority text := 'normal'; v_text text; v_ok boolean; k text; v_hit boolean := false;
begin
  select * into c from public.customers where id = p_customer_id;
  if not found then return; end if;
  v_text := lower(coalesce(c.notes, '') || ' ' || coalesce(c.qualification::text, ''));
  for r in select * from public.lead_rules where business_id = c.business_id and is_active order by sort_order, created_at loop
    v_ok := true;
    if r.match ? 'source' and coalesce(c.source, '') <> r.match ->> 'source' then v_ok := false; end if;
    if v_ok and r.match ? 'keyword' and position(lower(r.match ->> 'keyword') in v_text) = 0 then v_ok := false; end if;
    if v_ok and r.match ? 'answer_equals' then
      for k in select jsonb_object_keys(r.match -> 'answer_equals') loop
        if lower(coalesce(c.qualification ->> k, '')) <> lower(r.match -> 'answer_equals' ->> k) then v_ok := false; end if;
      end loop;
    end if;
    if v_ok then
      v_hit := true;
      v_assign := coalesce(v_assign, r.assign_to);
      if r.set_priority is not null and (r.set_priority = 'urgent' or (r.set_priority = 'high' and v_priority = 'normal')) then v_priority := r.set_priority; end if;
      if v_assign is not null and v_priority <> 'normal' then exit; end if;
    end if;
  end loop;
  if v_assign is null then
    select m.user_id into v_assign from public.business_members m
     where m.business_id = c.business_id and m.status = 'active'
     order by (select count(*) from public.customers x where x.business_id = c.business_id and x.assigned_to = m.user_id and x.lead_stage in ('new','contacted','qualified','quote_sent')), m.created_at
     limit 1;
  end if;
  update public.customers set assigned_to = coalesce(c.assigned_to, v_assign),
         priority = case when c.priority in ('high','urgent') and v_priority = 'normal' then c.priority else v_priority end
   where id = p_customer_id;
end $$;
revoke all on function public.zella_apply_lead_rules(uuid) from public, anon, authenticated;

-- Save the answers to the business's approved qualifying questions, then judge them.
create or replace function public.zella_save_qualification(p_customer_id uuid, p_answers jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare c record; q record; v_ans text; v_stage text := 'qualified'; v_any boolean := false; v_ok boolean;
begin
  select * into c from public.customers where id = p_customer_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if auth.uid() is not null and not public.zella_is_member(c.business_id) then raise exception 'NOT_ALLOWED'; end if;
  -- keep only keys that are approved questions
  update public.customers set qualification = coalesce(qualification, '{}'::jsonb) || coalesce((
    select jsonb_object_agg(e.key, e.value) from jsonb_each(coalesce(p_answers, '{}'::jsonb)) e
     where exists (select 1 from public.lead_questions lq where lq.business_id = c.business_id and lq.key = e.key and lq.is_active)), '{}'::jsonb)
   where id = p_customer_id returning * into c;
  for q in select * from public.lead_questions where business_id = c.business_id and is_active loop
    v_ans := c.qualification ->> q.key;
    if q.required and nullif(trim(coalesce(v_ans, '')), '') is null then v_stage := 'new'; end if;
    if q.qualifies_when is not null and nullif(trim(coalesce(v_ans, '')), '') is not null then
      v_any := true; v_ok := true;
      if q.qualifies_when ? 'equals' then v_ok := lower(coalesce(v_ans, '')) = lower(q.qualifies_when ->> 'equals'); end if;
      if v_ok and q.qualifies_when ? 'min' then v_ok := coalesce(nullif(regexp_replace(coalesce(v_ans, ''), '[^0-9.]', '', 'g'), '')::numeric, -1) >= (q.qualifies_when ->> 'min')::numeric; end if;
      if not v_ok and v_stage = 'qualified' then v_stage := 'unqualified'; end if;
    end if;
  end loop;
  -- The result is stored on the record. The pipeline stage only moves once a person has contacted the lead.
  update public.customers set qualification_result = case when v_stage = 'new' then 'incomplete' else v_stage end,
         lead_stage = case when lead_stage = 'contacted' and v_stage in ('qualified', 'unqualified') then v_stage else lead_stage end
   where id = p_customer_id;
  perform public.zella_apply_lead_rules(p_customer_id);
  return v_stage;
end $$;
revoke all on function public.zella_save_qualification(uuid, jsonb) from public, anon;
grant execute on function public.zella_save_qualification(uuid, jsonb) to authenticated, service_role;

-- ---- capture a lead (call, website form, SMS, AI) --------------------------
create or replace function public.zella_capture_lead(
  p_business_id uuid, p_first_name text default null, p_last_name text default null, p_phone text default null, p_email text default null,
  p_source text default 'website', p_notes text default null, p_answers jsonb default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_m record; v_id uuid; v_auto record; v_minutes integer; v_assigned uuid; v_pri text; v_name text; v_note_add text;
begin
  if not exists (select 1 from public.businesses where id = p_business_id and suspended_at is null and cancelled_at is null) then raise exception 'BUSINESS_NOT_AVAILABLE'; end if;
  -- validate: need some way to reach them, and sane lengths
  if public.zella_digits(p_phone) is null and nullif(trim(coalesce(p_email, '')), '') is null then raise exception 'NO_CONTACT'; end if;
  if p_email is not null and trim(p_email) <> '' and p_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'BAD_EMAIL'; end if;
  v_name := nullif(trim(coalesce(p_first_name, '') || ' ' || coalesce(p_last_name, '')), '');
  select * into v_m from public.zella_match_customer(p_business_id, p_phone, p_email);

  if v_m.certainty = 'uncertain' then
    insert into public.duplicate_reviews (business_id, customer_id, incoming)
    values (p_business_id, v_m.customer_id, jsonb_build_object('first_name', p_first_name, 'last_name', p_last_name, 'phone', p_phone, 'email', p_email, 'source', p_source, 'notes', p_notes, 'answers', p_answers));
    perform public.zella_create_task(p_business_id, v_m.customer_id, 'duplicate_review', 'Possible duplicate: check ' || coalesce(v_name, 'a new enquiry'), 'Zella found more than one possible match, so nothing was created or changed.', 'normal', now() + interval '1 day', null, 'ai');
    perform public.zella_notify(p_business_id, 'duplicate', 'Possible duplicate to review', coalesce(v_name, 'A new enquiry') || ' may already be in your list.', 'info', 'tasks', v_m.customer_id);
    return jsonb_build_object('result', 'needs_review', 'customer_id', v_m.customer_id);
  end if;

  if v_m.certainty = 'exact' then
    v_note_add := nullif(trim(coalesce(p_notes, '')), '');
    update public.customers set notes = case when v_note_add is null then notes else coalesce(notes || E'\n', '') || to_char(now(), 'YYYY-MM-DD') || ': ' || v_note_add end,
           updated_at = now() where id = v_m.customer_id;
    if p_answers is not null then perform public.zella_save_qualification(v_m.customer_id, p_answers); end if;
    return jsonb_build_object('result', 'matched', 'customer_id', v_m.customer_id);
  end if;

  select a.* into v_auto from public.automations a where a.business_id = p_business_id and a.trigger_type = 'new_lead_callback' and a.status = 'active' limit 1;
  v_minutes := coalesce((v_auto.trigger_config ->> 'contact_within_minutes')::integer, 60);
  insert into public.customers (business_id, first_name, last_name, phone, email, source, notes, lead_stage, contact_deadline_at)
  values (p_business_id, nullif(trim(p_first_name), ''), nullif(trim(p_last_name), ''), nullif(trim(p_phone), ''), lower(nullif(trim(p_email), '')), coalesce(nullif(p_source, ''), 'website'),
          left(p_notes, 2000), 'new', now() + make_interval(mins => v_minutes))
  returning id into v_id;
  if p_answers is not null then perform public.zella_save_qualification(v_id, p_answers); else perform public.zella_apply_lead_rules(v_id); end if;
  select assigned_to, priority into v_assigned, v_pri from public.customers where id = v_id;
  update public.customers set next_follow_up_at = contact_deadline_at where id = v_id;
  perform public.zella_create_task(p_business_id, v_id, 'follow_up', 'Contact ' || coalesce(v_name, 'the new lead'), coalesce(p_notes, ''), coalesce(v_pri, 'normal'), now() + make_interval(mins => v_minutes), v_assigned, 'ai');
  -- the business turned on automatic callbacks for new leads
  if v_auto.id is not null and public.zella_digits(p_phone) is not null then
    perform public.zella_create_callback(p_business_id, p_phone, 'new_lead', coalesce(v_pri, 'normal'), 'New lead: ' || coalesce(p_notes, 'call them back.'), null, v_id, null, null, 'system', 'new_lead_callback');
  end if;
  perform public.zella_notify(p_business_id, 'new_lead', case when v_pri in ('high','urgent') then 'New priority lead' else 'New lead' end,
    coalesce(v_name, 'A new enquiry') || ' came in from ' || coalesce(p_source, 'website') || '.', case when v_pri in ('high','urgent') then 'urgent' else 'info' end, 'leads', v_id, v_assigned);
  return jsonb_build_object('result', 'created', 'customer_id', v_id, 'assigned_to', v_assigned, 'priority', v_pri);
end $$;
revoke all on function public.zella_capture_lead(uuid, text, text, text, text, text, text, jsonb) from public, anon, authenticated;
grant execute on function public.zella_capture_lead(uuid, text, text, text, text, text, text, jsonb) to service_role;

-- Staff: resolve a possible duplicate.
create or replace function public.zella_resolve_duplicate(p_review_id uuid, p_action text) returns uuid
language plpgsql security definer set search_path = public as $$
declare d record; v_id uuid := null; i jsonb;
begin
  select * into d from public.duplicate_reviews where id = p_review_id for update;
  if not found or not public.zella_is_member(d.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if d.status <> 'open' then raise exception 'ALREADY_RESOLVED'; end if;
  i := d.incoming;
  if p_action = 'merge' and d.customer_id is not null then
    update public.customers set first_name = coalesce(first_name, nullif(i ->> 'first_name', '')), last_name = coalesce(last_name, nullif(i ->> 'last_name', '')),
           phone = coalesce(phone, nullif(i ->> 'phone', '')), email = coalesce(email, lower(nullif(i ->> 'email', ''))),
           notes = case when nullif(i ->> 'notes', '') is null then notes else coalesce(notes || E'\n', '') || (i ->> 'notes') end, updated_at = now()
     where id = d.customer_id;
    v_id := d.customer_id;
    update public.duplicate_reviews set status = 'merged', resolved_by = auth.uid(), resolved_at = now() where id = p_review_id;
  elsif p_action = 'keep_separate' then
    insert into public.customers (business_id, first_name, last_name, phone, email, source, notes, lead_stage)
    values (d.business_id, nullif(i ->> 'first_name', ''), nullif(i ->> 'last_name', ''), nullif(i ->> 'phone', ''), lower(nullif(i ->> 'email', '')), coalesce(nullif(i ->> 'source', ''), 'website'), nullif(i ->> 'notes', ''), 'new')
    returning id into v_id;
    perform public.zella_apply_lead_rules(v_id);
    update public.duplicate_reviews set status = 'kept_separate', resolved_by = auth.uid(), resolved_at = now() where id = p_review_id;
  elsif p_action = 'dismiss' then
    update public.duplicate_reviews set status = 'dismissed', resolved_by = auth.uid(), resolved_at = now() where id = p_review_id;
  else raise exception 'BAD_ACTION'; end if;
  update public.crm_tasks set status = 'done', completed_at = now() where business_id = d.business_id and kind = 'duplicate_review' and status = 'open' and customer_id is not distinct from d.customer_id;
  return v_id;
end $$;
revoke all on function public.zella_resolve_duplicate(uuid, text) from public, anon;
grant execute on function public.zella_resolve_duplicate(uuid, text) to authenticated, service_role;

-- Staff: change a lead's stage, assignment. Won/lost stop the sales reminders.
create or replace function public.zella_set_lead_stage(p_customer_id uuid, p_stage text, p_reason text default null, p_reengage_days integer default null)
returns text language plpgsql security definer set search_path = public as $$
declare c record;
begin
  select * into c from public.customers where id = p_customer_id for update;
  if not found or not public.zella_is_member(c.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if p_stage not in ('new','contacted','qualified','unqualified','quote_sent','won','lost') then raise exception 'BAD_STAGE'; end if;
  if p_stage = 'lost' and nullif(trim(coalesce(p_reason, '')), '') is null then raise exception 'REASON_REQUIRED'; end if;

  update public.customers set lead_stage = p_stage, updated_at = now(),
         last_contacted_at = case when p_stage = 'contacted' then now() else last_contacted_at end,
         converted_at = case when p_stage = 'won' then now() else converted_at end,
         lost_reason = case when p_stage = 'lost' then trim(p_reason) else lost_reason end,
         lost_at = case when p_stage = 'lost' then now() else lost_at end,
         reactivate_after = case when p_stage = 'lost' and p_reengage_days > 0 and not coalesce(do_not_contact, false) then now() + make_interval(days => p_reengage_days) else null end,
         contact_deadline_at = case when p_stage in ('contacted','qualified','quote_sent','won','lost') then null else contact_deadline_at end,
         next_follow_up_at = case when p_stage in ('won','lost') then null else next_follow_up_at end
   where id = p_customer_id;

  if p_stage in ('contacted','qualified','quote_sent','won','lost') then
    update public.crm_tasks set status = 'done', completed_at = now() where customer_id = p_customer_id and status = 'open' and kind in ('follow_up', 'overdue_contact');
  end if;
  if p_stage in ('won', 'lost') then
    -- stop active sales reminders
    update public.followup_tasks set status = 'cancelled', outcome = 'lead_' || p_stage, completed_at = now(), updated_at = now()
     where customer_id = p_customer_id and status = 'pending' and kind in ('quote_follow_up', 'lead_reactivation', 'new_lead_callback');
    update public.callbacks set status = 'cancelled', outcome = 'lead_' || p_stage, auto_call = false, completed_at = now(), updated_at = now()
     where customer_id = p_customer_id and status not in ('completed', 'cancelled');
    update public.quotes set status = case when p_stage = 'won' then 'accepted' else 'declined' end, closed_at = now(), next_follow_up_at = null
     where customer_id = p_customer_id and status = 'issued';
  end if;
  if p_stage = 'won' then
    perform public.zella_create_task(c.business_id, p_customer_id, 'onboarding', 'Start onboarding for ' || coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), 'the new customer'), null, 'normal', now() + interval '1 day', c.assigned_to, 'automation');
  end if;
  return p_stage;
end $$;
create or replace function public.zella_assign_lead(p_customer_id uuid, p_user_id uuid) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_b uuid;
begin
  select business_id into v_b from public.customers where id = p_customer_id;
  if v_b is null or not public.zella_is_member(v_b) then raise exception 'NOT_ALLOWED'; end if;
  if p_user_id is not null and not exists (select 1 from public.business_members where business_id = v_b and user_id = p_user_id and status = 'active') then raise exception 'NOT_A_MEMBER'; end if;
  update public.customers set assigned_to = p_user_id, updated_at = now() where id = p_customer_id;
  update public.crm_tasks set assigned_to = p_user_id where customer_id = p_customer_id and status = 'open';
  return true;
end $$;
revoke all on function public.zella_set_lead_stage(uuid, text, text, integer) from public, anon;
revoke all on function public.zella_assign_lead(uuid, uuid) from public, anon;
grant execute on function public.zella_set_lead_stage(uuid, text, text, integer) to authenticated, service_role;
grant execute on function public.zella_assign_lead(uuid, uuid) to authenticated, service_role;

-- n8n (scheduled): leads not contacted by their deadline -> overdue task + notify owner, escalate if configured.
create or replace function public.zella_flag_overdue_leads() returns integer
language plpgsql security definer set search_path = public as $$
declare c record; n integer := 0; v_esc integer; v_auto record;
begin
  for c in select * from public.customers x
            where x.lead_stage = 'new' and x.contact_deadline_at is not null and x.contact_deadline_at < now() and x.last_contacted_at is null loop
    select a.* into v_auto from public.automations a where a.business_id = c.business_id and a.trigger_type = 'new_lead_callback' and a.status = 'active' limit 1;
    v_esc := nullif(v_auto.trigger_config ->> 'escalate_after_minutes', '')::integer;
    if public.zella_create_task(c.business_id, c.id, 'overdue_contact', 'Overdue: contact ' || coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), 'this lead'),
         'This lead was not contacted in time.', 'high', now(), c.assigned_to, 'automation') is not null then
      perform public.zella_notify(c.business_id, 'lead_overdue', 'Lead not contacted in time', coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), 'A lead') || ' is waiting.', 'warning', 'tasks', c.id, c.assigned_to);
      n := n + 1;
    end if;
    if v_esc is not null and c.contact_deadline_at < now() - make_interval(mins => v_esc) then
      update public.crm_tasks set escalated_at = now(), priority = 'urgent'
       where customer_id = c.id and kind = 'overdue_contact' and status = 'open' and escalated_at is null;
      if found then
        perform public.zella_notify(c.business_id, 'lead_escalated', 'Escalated: lead still not contacted', coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), 'A lead') || ' has waited too long.', 'urgent', 'tasks', c.id);
      end if;
    end if;
  end loop;
  return n;
end $$;
revoke all on function public.zella_flag_overdue_leads() from public, anon, authenticated;
grant execute on function public.zella_flag_overdue_leads() to service_role;

-- ---- quotes -----------------------------------------------------------------
create or replace function public.zella_issue_quote(p_customer_id uuid, p_title text, p_expires_in_days integer default 30) returns uuid
language plpgsql security definer set search_path = public as $$
declare c record; v_id uuid; v_auto record;
begin
  select * into c from public.customers where id = p_customer_id;
  if not found or not public.zella_is_member(c.business_id) then raise exception 'NOT_ALLOWED'; end if;
  select a.* into v_auto from public.automations a where a.business_id = c.business_id and a.trigger_type = 'quote_follow_up' and a.status = 'active' limit 1;
  insert into public.quotes (business_id, customer_id, title, expires_at, max_follow_ups, follow_up_every_days, next_follow_up_at, created_by)
  values (c.business_id, p_customer_id, coalesce(nullif(trim(p_title), ''), 'Quote'), now() + make_interval(days => greatest(1, coalesce(p_expires_in_days, 30))),
          coalesce((v_auto.trigger_config ->> 'max_follow_ups')::integer, 3), coalesce((v_auto.trigger_config ->> 'every_days')::integer, 3),
          case when v_auto.id is not null then now() + make_interval(days => coalesce((v_auto.trigger_config ->> 'every_days')::integer, 3)) end, auth.uid())
  returning id into v_id;
  update public.customers set lead_stage = 'quote_sent', contact_deadline_at = null, updated_at = now() where id = p_customer_id and coalesce(lead_stage, 'new') not in ('won', 'lost');
  return v_id;
end $$;
create or replace function public.zella_set_quote_status(p_quote_id uuid, p_status text) returns text
language plpgsql security definer set search_path = public as $$
declare q record;
begin
  select * into q from public.quotes where id = p_quote_id for update;
  if not found or not public.zella_is_member(q.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if p_status not in ('accepted', 'declined', 'expired') then raise exception 'BAD_STATUS'; end if;
  update public.quotes set status = p_status, closed_at = now(), next_follow_up_at = null where id = p_quote_id and status = 'issued';
  update public.followup_tasks set status = 'cancelled', outcome = 'quote_' || p_status, completed_at = now(), updated_at = now()
   where entity_ref = p_quote_id and status = 'pending';
  return p_status;
end $$;
-- n8n (scheduled): follow up on open quotes, stop when closed / expired / customer opted out / limit reached.
create or replace function public.zella_queue_quote_followups() returns integer
language plpgsql security definer set search_path = public as $$
declare q record; v_tz text; n integer := 0; c record; v_auto record;
begin
  for q in select * from public.quotes where status = 'issued' and next_follow_up_at is not null and next_follow_up_at <= now() for update skip locked loop
    if q.expires_at is not null and q.expires_at < now() then
      update public.quotes set status = 'expired', closed_at = now(), next_follow_up_at = null where id = q.id; continue;
    end if;
    select * into c from public.customers where id = q.customer_id;
    select a.* into v_auto from public.automations a where a.business_id = q.business_id and a.trigger_type = 'quote_follow_up' and a.status = 'active' limit 1;
    if c.id is null or coalesce(c.do_not_contact, false) or c.lead_stage in ('won', 'lost') or v_auto.id is null then
      update public.quotes set next_follow_up_at = null where id = q.id; continue;
    end if;
    if q.follow_ups_sent >= q.max_follow_ups then
      update public.quotes set next_follow_up_at = null where id = q.id;
      perform public.zella_create_task(q.business_id, q.customer_id, 'quote_review', 'Quote still open after ' || q.follow_ups_sent || ' follow-ups: ' || q.title, 'Decide whether to close it.', 'normal', now(), c.assigned_to, 'automation', q.id);
      continue;
    end if;
    select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = q.business_id;
    insert into public.followup_tasks (business_id, customer_id, kind, channel, due_at, max_attempts, entity_ref)
    values (q.business_id, q.customer_id, 'quote_follow_up', case when v_auto.trigger_config ->> 'channel' = 'call' then 'call' else 'sms' end, public.zella_next_call_time(now(), v_tz), 1, q.id);
    update public.quotes set follow_ups_sent = follow_ups_sent + 1, next_follow_up_at = now() + make_interval(days => q.follow_up_every_days) where id = q.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.zella_issue_quote(uuid, text, integer) from public, anon;
revoke all on function public.zella_set_quote_status(uuid, text) from public, anon;
revoke all on function public.zella_queue_quote_followups() from public, anon, authenticated;
grant execute on function public.zella_issue_quote(uuid, text, integer) to authenticated, service_role;
grant execute on function public.zella_set_quote_status(uuid, text) to authenticated, service_role;
grant execute on function public.zella_queue_quote_followups() to service_role;

-- ---- reactivation (only for businesses that switched it on, and only with permission) -----
create or replace function public.zella_queue_lead_reactivation(p_limit integer default 25) returns integer
language plpgsql security definer set search_path = public as $$
declare c record; v_auto record; n integer := 0; v_tz text; v_days integer;
begin
  for v_auto in select * from public.automations a where a.trigger_type = 'lead_reactivation' and a.status = 'active' loop
    v_days := coalesce((v_auto.trigger_config ->> 'inactive_days')::integer, 60);
    select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b
     where b.id = v_auto.business_id and b.suspended_at is null and b.cancelled_at is null;
    if v_tz is null then continue; end if;
    for c in select x.* from public.customers x
              where x.business_id = v_auto.business_id and not coalesce(x.do_not_contact, false) and public.zella_digits(x.phone) is not null
                and ((x.lead_stage = 'lost' and x.reactivate_after is not null and x.reactivate_after <= now())
                  or (x.lead_stage in ('new','contacted','qualified','unqualified') and coalesce(x.last_contacted_at, x.created_at) < now() - make_interval(days => v_days)))
                and not exists (select 1 from public.followup_tasks f where f.customer_id = x.id and f.kind = 'lead_reactivation' and f.created_at > now() - interval '90 days')
              limit greatest(1, least(coalesce(p_limit, 25), 100)) loop
      insert into public.followup_tasks (business_id, customer_id, kind, channel, due_at, max_attempts)
      values (c.business_id, c.id, 'lead_reactivation', case when v_auto.trigger_config ->> 'channel' = 'call' then 'call' else 'sms' end, public.zella_next_call_time(now(), v_tz), 1);
      update public.customers set reactivate_after = null where id = c.id and reactivate_after is not null;
      n := n + 1;
    end loop;
  end loop;
  return n;
end $$;
revoke all on function public.zella_queue_lead_reactivation(integer) from public, anon, authenticated;
grant execute on function public.zella_queue_lead_reactivation(integer) to service_role;
