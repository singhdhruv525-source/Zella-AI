-- =========================================================
-- Zella workflows, part 1: shared helpers, staff notifications,
-- and the callback queue (missed calls, requested callbacks,
-- "needs a human", failed transfers, retries).
-- Run AFTER zella_crm_details.sql and zella_followups.sql. Safe to re-run.
-- =========================================================

create or replace function public.zella_is_member(p_business_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.business_members m
                  where m.business_id = p_business_id and m.user_id = auth.uid() and m.status = 'active');
$$;
create or replace function public.zella_digits(p text)
returns text language sql immutable as $$
  select nullif(right(regexp_replace(coalesce(p, ''), '\D', '', 'g'), 10), '');
$$;
revoke all on function public.zella_is_member(uuid) from public, anon;
grant execute on function public.zella_is_member(uuid) to authenticated, service_role;
grant execute on function public.zella_digits(text) to authenticated, service_role;

-- Match a caller / form to an existing record. 'uncertain' means a person
-- must review it: never create a duplicate and never merge silently.
create or replace function public.zella_match_customer(p_business_id uuid, p_phone text, p_email text)
returns table (customer_id uuid, certainty text)
language plpgsql stable security definer set search_path = public as $$
declare v_phone text := public.zella_digits(p_phone); v_email text := lower(nullif(trim(coalesce(p_email, '')), ''));
        v_by_phone uuid[]; v_by_email uuid[];
begin
  select coalesce(array_agg(c.id), '{}') into v_by_phone from public.customers c
   where c.business_id = p_business_id and v_phone is not null and public.zella_digits(c.phone) = v_phone;
  select coalesce(array_agg(c.id), '{}') into v_by_email from public.customers c
   where c.business_id = p_business_id and v_email is not null and lower(c.email) = v_email;
  if cardinality(v_by_phone) = 0 and cardinality(v_by_email) = 0 then
    return query select null::uuid, 'none'::text; return;
  end if;
  if cardinality(v_by_phone) = 1 and cardinality(v_by_email) = 0 then return query select v_by_phone[1], 'exact'; return; end if;
  if cardinality(v_by_email) = 1 and cardinality(v_by_phone) = 0 then return query select v_by_email[1], 'exact'; return; end if;
  if cardinality(v_by_phone) = 1 and cardinality(v_by_email) = 1 and v_by_phone[1] = v_by_email[1] then
    return query select v_by_phone[1], 'exact'; return;
  end if;
  return query select coalesce(v_by_phone[1], v_by_email[1]), 'uncertain';
end $$;
revoke all on function public.zella_match_customer(uuid, text, text) from public, anon, authenticated;
grant execute on function public.zella_match_customer(uuid, text, text) to service_role;

-- ---------------------------------------------------------
-- Staff notifications (n8n delivers them by email / SMS / push)
-- ---------------------------------------------------------
create table if not exists public.staff_notifications (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid,                       -- null = everyone who manages the business
  kind text not null,
  severity text not null default 'info' check (severity in ('info', 'warning', 'urgent')),
  title text not null,
  body text,
  page_key text,                      -- which CRM page to open
  entity_id uuid,
  delivery_status text not null default 'pending' check (delivery_status in ('pending', 'sent', 'failed', 'skipped')),
  delivery_error text,
  delivered_at timestamptz,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists staff_notifications_biz_idx on public.staff_notifications (business_id, created_at desc);
create index if not exists staff_notifications_pending_idx on public.staff_notifications (created_at) where delivery_status = 'pending';
alter table public.staff_notifications enable row level security;
drop policy if exists staff_notifications_select on public.staff_notifications;
create policy staff_notifications_select on public.staff_notifications for select to authenticated
  using (public.zella_is_member(business_id) and (user_id is null or user_id = auth.uid()));
revoke all on public.staff_notifications from anon;
revoke insert, update, delete on public.staff_notifications from authenticated;
grant select on public.staff_notifications to authenticated;

create or replace function public.zella_notify(p_business_id uuid, p_kind text, p_title text, p_body text default null,
  p_severity text default 'info', p_page_key text default null, p_entity_id uuid default null, p_user_id uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.staff_notifications (business_id, user_id, kind, severity, title, body, page_key, entity_id)
  values (p_business_id, p_user_id, p_kind, p_severity, p_title, p_body, p_page_key, p_entity_id) returning id into v_id;
  return v_id;
end $$;
revoke all on function public.zella_notify(uuid, text, text, text, text, text, uuid, uuid) from public, anon, authenticated;
grant execute on function public.zella_notify(uuid, text, text, text, text, text, uuid, uuid) to service_role;

create or replace function public.zella_mark_notifications_read(p_ids uuid[]) returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  update public.staff_notifications set read_at = now()
   where id = any (p_ids) and read_at is null and public.zella_is_member(business_id) and (user_id is null or user_id = auth.uid());
  get diagnostics n = row_count; return n;
end $$;
revoke all on function public.zella_mark_notifications_read(uuid[]) from public, anon;
grant execute on function public.zella_mark_notifications_read(uuid[]) to authenticated, service_role;

create or replace function public.zella_claim_notifications(p_limit integer default 50)
returns setof public.staff_notifications language plpgsql security definer set search_path = public as $$
begin
  return query
  update public.staff_notifications n set delivery_status = 'sent', delivered_at = now()
   where n.id in (select s.id from public.staff_notifications s where s.delivery_status = 'pending' order by s.created_at
                   limit greatest(1, least(coalesce(p_limit, 50), 200)) for update skip locked)
  returning n.*;
end $$;
create or replace function public.zella_fail_notification(p_id uuid, p_error text) returns void
language sql security definer set search_path = public as $$
  update public.staff_notifications set delivery_status = 'failed', delivery_error = left(p_error, 300) where id = p_id;
$$;
revoke all on function public.zella_claim_notifications(integer) from public, anon, authenticated;
revoke all on function public.zella_fail_notification(uuid, text) from public, anon, authenticated;
grant execute on function public.zella_claim_notifications(integer) to service_role;
grant execute on function public.zella_fail_notification(uuid, text) to service_role;

alter table public.followup_tasks add column if not exists entity_ref uuid;

-- ---------------------------------------------------------
-- Callbacks
-- ---------------------------------------------------------
alter table public.calls add column if not exists transfer_status text;
do $$ begin
  alter table public.calls add constraint calls_transfer_status_chk
    check (transfer_status is null or transfer_status in ('not_needed', 'attempted', 'connected', 'failed', 'no_one_available'));
exception when duplicate_object then null; end $$;

create table if not exists public.callbacks (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  call_id uuid,
  appointment_id uuid,
  reason text not null default 'other'
    check (reason in ('missed_call', 'new_lead', 'requested', 'needs_human', 'transfer_failed', 'appointment_request', 'booking_failed', 'after_hours', 'other')),
  priority text not null default 'normal' check (priority in ('normal', 'high', 'urgent')),
  status text not null default 'new' check (status in (
    'new', 'scheduled', 'due', 'in_progress', 'contacted', 'reschedule_requested', 'retry_scheduled',
    'waiting_on_customer', 'completed', 'cancelled', 'escalated', 'needs_review')),
  contact_number text,
  summary text,
  preferred_at timestamptz,
  due_at timestamptz,
  assigned_to uuid,
  assigned_team text,
  auto_call boolean not null default false,       -- the business authorised Zella to call back
  attempts integer not null default 0,
  max_attempts integer not null default 3,
  retry_delay_minutes integer not null default 120,
  outcome text,
  note text,
  locked_at timestamptz,
  created_by text not null default 'ai',          -- ai | system | staff
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists callbacks_biz_idx on public.callbacks (business_id, status, due_at);
create index if not exists callbacks_due_idx on public.callbacks (due_at) where status in ('scheduled', 'retry_scheduled', 'due');
create index if not exists callbacks_customer_idx on public.callbacks (customer_id);
-- older installs: allow the 'new_lead' reason
alter table public.callbacks drop constraint if exists callbacks_reason_check;
alter table public.callbacks add constraint callbacks_reason_check
  check (reason in ('missed_call', 'new_lead', 'requested', 'needs_human', 'transfer_failed', 'appointment_request', 'booking_failed', 'after_hours', 'other'));
-- one live callback per caller and reason
create unique index if not exists callbacks_one_live_idx on public.callbacks (business_id, (public.zella_digits(contact_number)), reason)
  where contact_number is not null and status not in ('completed', 'cancelled', 'needs_review');

create table if not exists public.callback_attempts (
  id uuid primary key default gen_random_uuid(),
  callback_id uuid not null references public.callbacks(id) on delete cascade,
  business_id uuid not null references public.businesses(id) on delete cascade,
  attempt_no integer not null,
  attempted_at timestamptz not null default now(),
  outcome text not null check (outcome in ('connected', 'no_answer', 'busy', 'voicemail', 'invalid_number', 'failed_connection', 'declined')),
  provider_ref text,
  error text,
  notes text,
  next_attempt_at timestamptz,
  initiated_by text not null default 'system'
);
create index if not exists callback_attempts_cb_idx on public.callback_attempts (callback_id, attempt_no);

alter table public.callbacks enable row level security;
alter table public.callback_attempts enable row level security;
drop policy if exists callbacks_select on public.callbacks;
create policy callbacks_select on public.callbacks for select to authenticated using (public.zella_is_member(business_id));
drop policy if exists callback_attempts_select on public.callback_attempts;
create policy callback_attempts_select on public.callback_attempts for select to authenticated using (public.zella_is_member(business_id));
revoke all on public.callbacks, public.callback_attempts from anon;
revoke insert, update, delete on public.callbacks, public.callback_attempts from authenticated;
grant select on public.callbacks, public.callback_attempts to authenticated;

-- Create a callback. Used by the AI (service role) and, through the wrapper below, by staff.
-- Never duplicates: asking again for the same caller and reason updates the live one.
create or replace function public.zella_create_callback(
  p_business_id uuid, p_contact_number text, p_reason text default 'other', p_priority text default 'normal',
  p_summary text default null, p_preferred_at timestamptz default null, p_customer_id uuid default null,
  p_call_id uuid default null, p_appointment_id uuid default null, p_created_by text default 'ai', p_automation text default 'missed_call_follow_up'
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_tz text; v_auto record; v_due timestamptz; v_cust uuid := p_customer_id; v_id uuid; v_note text;
  v_reason text := case when p_reason in ('missed_call','new_lead','requested','needs_human','transfer_failed','appointment_request','booking_failed','after_hours') then p_reason else 'other' end;
  v_priority text := case when p_priority in ('high','urgent') then p_priority else 'normal' end;
  v_max integer; v_delay integer; v_first integer;
begin
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id;
  if v_tz is null then raise exception 'BUSINESS_NOT_FOUND'; end if;
  if nullif(trim(coalesce(p_contact_number, '')), '') is null and v_cust is null then raise exception 'NO_CONTACT'; end if;
  if v_cust is null then select m.customer_id into v_cust from public.zella_match_customer(p_business_id, p_contact_number, null) m where m.certainty = 'exact'; end if;
  if nullif(trim(coalesce(p_contact_number, '')), '') is null then select c.phone into p_contact_number from public.customers c where c.id = v_cust; end if;

  -- Zella calls back by itself only when the business switched that on.
  select a.* into v_auto from public.automations a
   where a.business_id = p_business_id and a.trigger_type = case when p_automation = 'new_lead_callback' then 'new_lead_callback' else 'missed_call_follow_up' end and a.status = 'active' limit 1;
  v_max := coalesce((v_auto.trigger_config ->> 'max_attempts')::integer, 3);
  -- missed-call: retry after retry_delay_minutes (default 2h); new lead: retry_after_hours (default 24h)
  v_delay := coalesce((v_auto.trigger_config ->> 'retry_delay_minutes')::integer, (v_auto.trigger_config ->> 'retry_after_hours')::integer * 60, 120);
  v_first := coalesce((v_auto.trigger_config ->> 'minutes_after')::integer, 5);

  -- Never silently book an inappropriate time: move it into the calling window.
  v_due := public.zella_next_call_time(coalesce(p_preferred_at, now() + make_interval(mins => v_first)), v_tz);
  if p_preferred_at is not null and v_due <> p_preferred_at then
    v_note := 'The requested time was outside calling hours, so it was moved to the next available time.';
  end if;

  insert into public.callbacks (business_id, customer_id, call_id, appointment_id, reason, priority, status, contact_number, summary,
      preferred_at, due_at, auto_call, max_attempts, retry_delay_minutes, note, created_by)
  values (p_business_id, v_cust, p_call_id, p_appointment_id, v_reason, v_priority, 'scheduled', p_contact_number, left(p_summary, 1000),
      p_preferred_at, v_due, (v_auto.id is not null and coalesce(v_auto.trigger_config ->> 'channel', 'call') = 'call' and v_reason not in ('needs_human', 'transfer_failed')),
      v_max, v_delay, v_note, case when p_created_by in ('ai','system','staff') then p_created_by else 'ai' end)
  on conflict (business_id, (public.zella_digits(contact_number)), reason) where contact_number is not null and status not in ('completed','cancelled','needs_review')
  do update set summary = coalesce(excluded.summary, callbacks.summary), priority = case when excluded.priority = 'urgent' or callbacks.priority = 'urgent' then 'urgent' when excluded.priority = 'high' or callbacks.priority = 'high' then 'high' else 'normal' end,
                call_id = coalesce(excluded.call_id, callbacks.call_id), updated_at = now()
  returning id into v_id;

  perform public.zella_notify(p_business_id, 'callback', 'Callback needed',
    coalesce(p_summary, 'A caller needs a call back.'), case when v_priority = 'normal' then 'info' else 'urgent' end, 'callbacks', v_id);
  return v_id;
end $$;

create or replace function public.zella_staff_create_callback(
  p_business_id uuid, p_contact_number text, p_summary text default null, p_preferred_at timestamptz default null,
  p_customer_id uuid default null, p_priority text default 'normal'
) returns uuid language plpgsql security definer set search_path = public as $$
begin
  if not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  return public.zella_create_callback(p_business_id, p_contact_number, 'requested', p_priority, p_summary, p_preferred_at, p_customer_id, null, null, 'staff');
end $$;

-- Staff actions on a callback (assign, start, mark contacted, reschedule, complete, cancel, escalate...).
create or replace function public.zella_update_callback(
  p_callback_id uuid, p_status text default null, p_note text default null, p_preferred_at timestamptz default null, p_assign_to uuid default null
) returns text language plpgsql security definer set search_path = public as $$
declare v_cb record; v_tz text; v_status text;
begin
  select * into v_cb from public.callbacks where id = p_callback_id for update;
  if not found or not public.zella_is_member(v_cb.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if p_status is not null and p_status not in ('scheduled','in_progress','contacted','reschedule_requested','waiting_on_customer','completed','cancelled','escalated','needs_review') then
    raise exception 'BAD_STATUS';
  end if;
  if v_cb.status in ('completed','cancelled') and p_status is not null then raise exception 'ALREADY_CLOSED'; end if;
  v_status := coalesce(p_status, v_cb.status);
  if p_preferred_at is not null then
    select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = v_cb.business_id;
    v_status := case when p_status is null or p_status = 'reschedule_requested' then 'scheduled' else v_status end;
    update public.callbacks set preferred_at = p_preferred_at, due_at = public.zella_next_call_time(p_preferred_at, v_tz) where id = p_callback_id;
  end if;
  update public.callbacks set status = v_status, note = coalesce(nullif(p_note, ''), note),
      assigned_to = coalesce(p_assign_to, assigned_to), locked_at = null,
      completed_at = case when v_status in ('completed','cancelled') then now() else completed_at end,
      outcome = case when v_status in ('completed','cancelled') then coalesce(nullif(p_note, ''), outcome, v_status) else outcome end,
      updated_at = now()
   where id = p_callback_id;
  return v_status;
end $$;

-- n8n: take callbacks that are due and that Zella is allowed to make by itself.
create or replace function public.zella_claim_callbacks(p_limit integer default 10)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_res jsonb := '[]'::jsonb; v_cb record; v_biz record; v_cust record; v_next timestamptz;
begin
  for v_cb in
    select c.* from public.callbacks c
     where c.status in ('scheduled', 'retry_scheduled', 'due') and c.due_at <= now() and c.auto_call
       and (c.locked_at is null or c.locked_at < now() - interval '15 minutes')
     order by case c.priority when 'urgent' then 0 when 'high' then 1 else 2 end, c.due_at
     limit greatest(1, least(coalesce(p_limit, 10), 50)) for update skip locked
  loop
    select b.id, b.name, coalesce(b.timezone, 'America/New_York') as tz, b.suspended_at, b.cancelled_at, coalesce(b.is_active, true) as is_active
      into v_biz from public.businesses b where b.id = v_cb.business_id;
    select c.first_name, c.last_name, coalesce(c.do_not_contact, false) as dnc into v_cust from public.customers c where c.id = v_cb.customer_id;
    if v_biz.id is null or v_biz.suspended_at is not null or v_biz.cancelled_at is not null or not v_biz.is_active then
      update public.callbacks set status = 'needs_review', outcome = 'business_inactive', updated_at = now() where id = v_cb.id; continue;
    end if;
    if coalesce(v_cust.dnc, false) then
      update public.callbacks set status = 'cancelled', outcome = 'do_not_contact', completed_at = now(), updated_at = now() where id = v_cb.id; continue;
    end if;
    v_next := public.zella_next_call_time(now(), v_biz.tz);
    if v_next > now() + interval '1 minute' then
      update public.callbacks set due_at = v_next, updated_at = now() where id = v_cb.id; continue;
    end if;
    update public.callbacks set status = 'in_progress', attempts = attempts + 1, locked_at = now(), updated_at = now() where id = v_cb.id;
    v_res := v_res || jsonb_build_array(jsonb_build_object(
      'callback_id', v_cb.id, 'attempt', v_cb.attempts + 1, 'max_attempts', v_cb.max_attempts, 'reason', v_cb.reason,
      'contact_number', v_cb.contact_number, 'summary', v_cb.summary,
      'business', jsonb_build_object('id', v_biz.id, 'name', v_biz.name, 'timezone', v_biz.tz),
      'customer', jsonb_build_object('id', v_cb.customer_id, 'first_name', v_cust.first_name, 'last_name', v_cust.last_name)));
  end loop;
  return v_res;
end $$;

-- n8n or staff: record what happened on an attempt, then apply the retry policy.
create or replace function public.zella_record_callback_attempt(
  p_callback_id uuid, p_outcome text, p_provider_ref text default null, p_error text default null, p_notes text default null
) returns text language plpgsql security definer set search_path = public as $$
declare v_cb record; v_tz text; v_next timestamptz; v_status text; v_by text; v_uid uuid := auth.uid();
begin
  select * into v_cb from public.callbacks where id = p_callback_id for update;
  if not found then raise exception 'CALLBACK_NOT_FOUND'; end if;
  if v_uid is not null and not public.zella_is_member(v_cb.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if p_outcome not in ('connected','no_answer','busy','voicemail','invalid_number','failed_connection','declined') then raise exception 'BAD_OUTCOME'; end if;
  if v_cb.status in ('completed','cancelled') then raise exception 'ALREADY_CLOSED'; end if;
  v_by := case when v_uid is null then 'system' else v_uid::text end;
  -- staff calling by hand count as an attempt too
  if v_cb.status <> 'in_progress' then v_cb.attempts := v_cb.attempts + 1; end if;

  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = v_cb.business_id;
  if p_outcome in ('no_answer','busy','voicemail','failed_connection') and v_cb.attempts < v_cb.max_attempts then
    v_status := 'retry_scheduled';
    v_next := public.zella_next_call_time(now() + make_interval(mins => greatest(5, v_cb.retry_delay_minutes)), v_tz);
  elsif p_outcome in ('no_answer','busy','voicemail','failed_connection','invalid_number') then
    v_status := 'needs_review';       -- attempt limit reached (or bad number): stop automatic calling, hand to staff
  elsif p_outcome = 'connected' then v_status := 'contacted';
  else v_status := 'completed';       -- declined
  end if;

  insert into public.callback_attempts (callback_id, business_id, attempt_no, outcome, provider_ref, error, notes, next_attempt_at, initiated_by)
  values (p_callback_id, v_cb.business_id, v_cb.attempts, p_outcome, p_provider_ref, left(p_error, 300), p_notes, v_next, v_by);

  update public.callbacks set status = v_status, attempts = v_cb.attempts, due_at = coalesce(v_next, due_at), locked_at = null,
      outcome = case when v_status in ('contacted','completed','needs_review') then p_outcome else outcome end,
      completed_at = case when v_status = 'completed' then now() else completed_at end,
      auto_call = case when v_status = 'needs_review' then false else auto_call end,
      note = coalesce(nullif(p_notes, ''), note), updated_at = now()
   where id = p_callback_id;

  if v_status = 'needs_review' and p_outcome <> 'invalid_number' and v_cb.reason in ('missed_call', 'new_lead') then
    -- the business allowed a text as a last resort
    if exists (select 1 from public.automations a where a.business_id = v_cb.business_id and a.status = 'active'
                 and a.trigger_type = case when v_cb.reason = 'new_lead' then 'new_lead_callback' else 'missed_call_follow_up' end
                 and coalesce((a.trigger_config ->> 'fallback_sms')::boolean, false))
       and v_cb.customer_id is not null
       and exists (select 1 from public.customers c where c.id = v_cb.customer_id and not coalesce(c.do_not_contact, false) and public.zella_digits(c.phone) is not null) then
      insert into public.followup_tasks (business_id, customer_id, kind, channel, due_at, max_attempts, entity_ref)
      values (v_cb.business_id, v_cb.customer_id, 'callback_sms', 'sms', public.zella_next_call_time(now(), v_tz), 1, v_cb.id) on conflict do nothing;
    end if;
  end if;
  if v_status = 'needs_review' then
    perform public.zella_notify(v_cb.business_id, 'callback_review', 'A callback needs a person',
      case when p_outcome = 'invalid_number' then 'The phone number could not be reached.' else 'Zella tried ' || v_cb.attempts || ' times without reaching them.' end,
      'warning', 'callbacks', p_callback_id);
  end if;
  return v_status;
end $$;

-- The customer got in touch another way (called, texted, was booked): stop any waiting callbacks.
create or replace function public.zella_stop_callbacks_for(p_business_id uuid, p_customer_id uuid default null, p_phone text default null, p_reason text default 'customer_responded')
returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  update public.callbacks set status = 'completed', outcome = left(p_reason, 60), completed_at = now(), locked_at = null, auto_call = false, updated_at = now()
   where business_id = p_business_id and status in ('new','scheduled','due','retry_scheduled','waiting_on_customer')
     and ((p_customer_id is not null and customer_id = p_customer_id) or (p_phone is not null and public.zella_digits(contact_number) = public.zella_digits(p_phone)));
  get diagnostics n = row_count; return n;
end $$;

-- Missed call -> callback. Needs-a-human / failed transfer -> urgent callback.
create or replace function public.zella_calls_to_callbacks() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_row jsonb := to_jsonb(new); v_old jsonb := case when tg_op = 'UPDATE' then to_jsonb(old) else '{}'::jsonb end;
        v_phone text := coalesce(v_row ->> 'from_number', v_row ->> 'caller_number', v_row ->> 'phone');
        v_dir text := coalesce(v_row ->> 'direction', 'inbound');
begin
  if v_dir <> 'inbound' then return new; end if;
  if (v_row ->> 'status') = 'missed' and coalesce(v_old ->> 'status', '') <> 'missed' then
    perform public.zella_create_callback(new.business_id, v_phone, 'missed_call', 'normal', 'Missed call. Call them back.', null, new.customer_id, new.id, null, 'system');
  end if;
  if coalesce((v_row ->> 'transfer_status'), '') in ('failed', 'no_one_available') and coalesce(v_old ->> 'transfer_status', '') not in ('failed', 'no_one_available') then
    perform public.zella_create_callback(new.business_id, v_phone, 'transfer_failed', 'urgent',
      'The caller asked for a person but the transfer did not connect. ' || coalesce(v_row ->> 'summary', ''), null, new.customer_id, new.id, null, 'system');
  elsif coalesce((v_row ->> 'needs_human')::boolean, false) and not coalesce((v_old ->> 'needs_human')::boolean, false)
        and coalesce(v_row ->> 'transfer_status', '') <> 'connected' then
    perform public.zella_create_callback(new.business_id, v_phone, 'needs_human', 'high', coalesce(nullif(v_row ->> 'escalation_reason', ''), 'The caller needs a person.'), null, new.customer_id, new.id, null, 'system');
  end if;
  return new;
end $$;
drop trigger if exists zella_calls_callbacks_trg on public.calls;
create trigger zella_calls_callbacks_trg after insert or update on public.calls
  for each row execute function public.zella_calls_to_callbacks();

-- A customer who is marked do-not-contact must never be called again.
create or replace function public.zella_dnc_stops_callbacks() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.do_not_contact, false) and not coalesce(old.do_not_contact, false) then
    update public.callbacks set status = 'cancelled', outcome = 'do_not_contact', auto_call = false, completed_at = now(), updated_at = now()
     where customer_id = new.id and status not in ('completed', 'cancelled');
    update public.followup_tasks set status = 'cancelled', outcome = 'do_not_contact', completed_at = now(), updated_at = now()
     where customer_id = new.id and status = 'pending';
  end if;
  return new;
end $$;
drop trigger if exists zella_dnc_trg on public.customers;
create trigger zella_dnc_trg after update of do_not_contact on public.customers
  for each row execute function public.zella_dnc_stops_callbacks();

drop function if exists public.zella_create_callback(uuid, text, text, text, text, timestamptz, uuid, uuid, uuid, text);
revoke all on function public.zella_create_callback(uuid, text, text, text, text, timestamptz, uuid, uuid, uuid, text, text) from public, anon, authenticated;
revoke all on function public.zella_staff_create_callback(uuid, text, text, timestamptz, uuid, text) from public, anon;
revoke all on function public.zella_update_callback(uuid, text, text, timestamptz, uuid) from public, anon;
revoke all on function public.zella_claim_callbacks(integer) from public, anon, authenticated;
revoke all on function public.zella_record_callback_attempt(uuid, text, text, text, text) from public, anon;
revoke all on function public.zella_stop_callbacks_for(uuid, uuid, text, text) from public, anon, authenticated;
revoke all on function public.zella_calls_to_callbacks() from public, anon, authenticated;
revoke all on function public.zella_dnc_stops_callbacks() from public, anon, authenticated;
grant execute on function public.zella_create_callback(uuid, text, text, text, text, timestamptz, uuid, uuid, uuid, text, text) to service_role;
grant execute on function public.zella_staff_create_callback(uuid, text, text, timestamptz, uuid, text) to authenticated, service_role;
grant execute on function public.zella_update_callback(uuid, text, text, timestamptz, uuid) to authenticated, service_role;
grant execute on function public.zella_claim_callbacks(integer) to service_role;
grant execute on function public.zella_record_callback_attempt(uuid, text, text, text, text) to authenticated, service_role;
grant execute on function public.zella_stop_callbacks_for(uuid, uuid, text, text) to service_role;
