-- =========================================================
-- Zella workflows, part 4: AI-receptionist maintenance and
-- platform-owner (Zella admin) automations.
-- Run AFTER parts 1-3. Safe to re-run.
-- =========================================================

-- ---------- platform settings and alerts (Zella admins only) ----------
create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
insert into public.platform_settings (key, value) values
  ('invitation_reminder_hours', '[24, 72]'),
  ('setup_incomplete_after_days', '3'),
  ('trial_notice_days', '[7, 3, 1]'),
  ('payment_grace_days', '7'),
  ('payment_suspend_after_days', '14'),
  ('payment_auto_suspend', 'false'),
  ('retention_days', '90'),
  ('transfer_failure_threshold', '3')
on conflict (key) do nothing;
alter table public.platform_settings enable row level security;
revoke all on public.platform_settings from anon, authenticated;
create or replace function public.zella_setting(p_key text, p_default jsonb) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select value from public.platform_settings where key = p_key), p_default);
$$;
revoke all on function public.zella_setting(text, jsonb) from public, anon, authenticated;
grant execute on function public.zella_setting(text, jsonb) to service_role;

create table if not exists public.platform_alerts (
  id uuid primary key default gen_random_uuid(),
  kind text not null,
  severity text not null default 'warning' check (severity in ('info', 'warning', 'urgent')),
  business_id uuid references public.businesses(id) on delete cascade,
  title text not null,
  detail text,
  meta jsonb not null default '{}'::jsonb,
  dedupe_key text not null default '',
  status text not null default 'open' check (status in ('open', 'acknowledged', 'resolved')),
  occurrences integer not null default 1,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  notified_at timestamptz,
  acknowledged_by uuid, acknowledged_at timestamptz,
  resolved_by uuid, resolved_at timestamptz, resolution_note text
);
create unique index if not exists platform_alerts_one_open_idx on public.platform_alerts (kind, coalesce(business_id, '00000000-0000-0000-0000-000000000000'::uuid), dedupe_key) where status <> 'resolved';
create index if not exists platform_alerts_status_idx on public.platform_alerts (status, last_seen_at desc);
alter table public.platform_alerts enable row level security;
revoke all on public.platform_alerts from anon, authenticated;
do $$ begin
  if to_regclass('public.platform_admins') is not null then
    drop policy if exists platform_alerts_admin_select on public.platform_alerts;
    create policy platform_alerts_admin_select on public.platform_alerts for select to authenticated
      using (exists (select 1 from public.platform_admins p where p.user_id = auth.uid() and p.is_active));
    grant select on public.platform_alerts to authenticated;
  end if;
end $$;

create or replace function public.zella_platform_alert(p_kind text, p_title text, p_detail text default null, p_severity text default 'warning',
  p_business_id uuid default null, p_dedupe_key text default '', p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.platform_alerts (kind, title, detail, severity, business_id, dedupe_key, meta)
  values (p_kind, p_title, left(p_detail, 1000), case when p_severity in ('info','urgent') then p_severity else 'warning' end, p_business_id, coalesce(p_dedupe_key, ''), coalesce(p_meta, '{}'::jsonb))
  on conflict (kind, coalesce(business_id, '00000000-0000-0000-0000-000000000000'::uuid), dedupe_key) where status <> 'resolved'
  do update set occurrences = platform_alerts.occurrences + 1, last_seen_at = now(), detail = coalesce(excluded.detail, platform_alerts.detail), meta = platform_alerts.meta || excluded.meta
  returning id into v_id;
  return v_id;
end $$;
create or replace function public.zella_resolve_platform_alerts(p_kind text, p_business_id uuid, p_dedupe_key text default null, p_note text default null) returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  update public.platform_alerts set status = 'resolved', resolved_at = now(), resolution_note = left(p_note, 300)
   where kind = p_kind and business_id is not distinct from p_business_id and status <> 'resolved' and (p_dedupe_key is null or dedupe_key = p_dedupe_key);
  get diagnostics n = row_count; return n;
end $$;
-- n8n: alerts that still need to be emailed to platform admins, with who to email.
create or replace function public.zella_claim_platform_alerts(p_limit integer default 25) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_alerts jsonb; v_emails jsonb := '[]'::jsonb;
begin
  with c as (
    update public.platform_alerts a set notified_at = now()
     where a.id in (select s.id from public.platform_alerts s where s.notified_at is null and s.status = 'open' order by s.first_seen_at limit greatest(1, least(coalesce(p_limit, 25), 100)) for update skip locked)
    returning a.*)
  select coalesce(jsonb_agg(to_jsonb(c)), '[]'::jsonb) into v_alerts from c;
  if to_regclass('auth.users') is not null and to_regclass('public.platform_admins') is not null then
    execute 'select coalesce(jsonb_agg(u.email), ''[]''::jsonb) from public.platform_admins p join auth.users u on u.id = p.user_id where p.is_active and u.email is not null' into v_emails;
  end if;
  return jsonb_build_object('alerts', v_alerts, 'admin_emails', v_emails);
end $$;
create or replace function public.zella_set_alert_status(p_id uuid, p_status text, p_user uuid default null, p_note text default null) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_status not in ('acknowledged', 'resolved') then raise exception 'BAD_STATUS'; end if;
  update public.platform_alerts set status = p_status,
         acknowledged_by = case when p_status = 'acknowledged' then p_user else acknowledged_by end, acknowledged_at = case when p_status = 'acknowledged' then now() else acknowledged_at end,
         resolved_by = case when p_status = 'resolved' then p_user else resolved_by end, resolved_at = case when p_status = 'resolved' then now() else resolved_at end,
         resolution_note = coalesce(left(p_note, 300), resolution_note)
   where id = p_id and status <> 'resolved';
  return found;
end $$;
revoke all on function public.zella_platform_alert(text, text, text, text, uuid, text, jsonb) from public, anon, authenticated;
revoke all on function public.zella_resolve_platform_alerts(text, uuid, text, text) from public, anon, authenticated;
revoke all on function public.zella_claim_platform_alerts(integer) from public, anon, authenticated;
revoke all on function public.zella_set_alert_status(uuid, text, uuid, text) from public, anon, authenticated;
grant execute on function public.zella_platform_alert(text, text, text, text, uuid, text, jsonb) to service_role;
grant execute on function public.zella_resolve_platform_alerts(text, uuid, text, text) to service_role;
grant execute on function public.zella_claim_platform_alerts(integer) to service_role;
grant execute on function public.zella_set_alert_status(uuid, text, uuid, text) to service_role;

-- tell a business's owners something (not every member)
create or replace function public.zella_notify_owners(p_business_id uuid, p_kind text, p_title text, p_body text, p_severity text default 'warning', p_page_key text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.zella_notify(p_business_id, p_kind, p_title, p_body, p_severity, p_page_key, null, null);
end $$;
revoke all on function public.zella_notify_owners(uuid, text, text, text, text, text) from public, anon, authenticated;

-- =========================================================
-- A. AI receptionist maintenance
-- =========================================================
alter table public.integrations add column if not exists last_error text, add column if not exists last_checked_at timestamptz, add column if not exists error_count integer not null default 0;
alter table public.calls add column if not exists failure_reason text, add column if not exists failure_context jsonb;

-- 3. repeated failed transfers (n8n, e.g. every 15 minutes)
create or replace function public.zella_detect_transfer_failures() returns integer
language plpgsql security definer set search_path = public as $$
declare b record; v_n integer; v_thr integer := (public.zella_setting('transfer_failure_threshold', '3'))::text::integer; v_found integer := 0; v_cfg record; v_auto boolean;
begin
  for b in
    select c.business_id, count(*) as n from public.calls c
     where c.transfer_status in ('failed', 'no_one_available') and c.created_at > now() - interval '24 hours'
     group by c.business_id having count(*) >= v_thr
  loop
    v_found := v_found + 1;
    perform public.zella_platform_alert('repeated_transfer_failures', 'Transfers keep failing', b.n || ' transfers failed in 24 hours.', 'warning', b.business_id, to_char(now(), 'YYYY-MM-DD'), jsonb_build_object('failures', b.n));
    -- an authorised fallback route is applied automatically; otherwise it is only recommended
    select cfg.* into v_cfg from public.ai_agent_configs cfg join public.ai_agents ag on ag.id = cfg.agent_id where ag.business_id = b.business_id and ag.is_default limit 1;
    v_auto := coalesce((v_cfg.escalation_rules ->> 'auto_fallback')::boolean, false) and nullif(v_cfg.escalation_rules ->> 'fallback_number', '') is not null;
    if exists (select 1 from public.staff_notifications where business_id = b.business_id and kind in ('transfer_fallback_applied', 'transfer_failures') and created_at > now() - interval '24 hours') then
      continue;   -- the owner was already told today
    end if;
    if v_auto and coalesce(v_cfg.escalation_rules ->> 'transfer_route', '') <> 'fallback' then
      update public.ai_agent_configs set escalation_rules = coalesce(escalation_rules, '{}'::jsonb) || '{"transfer_route":"fallback"}'::jsonb, updated_at = now() where id = v_cfg.id;
      perform public.zella_notify_owners(b.business_id, 'transfer_fallback_applied', 'Switched to your backup number', 'Transfers kept failing, so Zella is now sending callers to your backup route.', 'urgent', 'receptionist');
    else
      perform public.zella_notify_owners(b.business_id, 'transfer_failures', 'Transfers keep failing', 'Callers asking for a person are not getting through. Check your transfer number or add a backup.', 'urgent', 'receptionist');
    end if;
  end loop;
  return v_found;
end $$;

-- 4. phone connection failure (Telnyx / Vapi report their state here)
create or replace function public.zella_report_telephony_event(p_business_id uuid, p_provider text, p_state text, p_error text default null, p_retryable boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_i record; v_retry boolean := false;
begin
  if p_state not in ('connected', 'error', 'disconnected') then raise exception 'BAD_STATE'; end if;
  select * into v_i from public.integrations where business_id = p_business_id and provider = p_provider limit 1;
  if v_i.id is null then raise exception 'INTEGRATION_NOT_FOUND'; end if;
  if p_state = 'connected' then
    update public.integrations set status = 'active', last_error = null, error_count = 0, last_checked_at = now() where id = v_i.id;
    perform public.zella_resolve_platform_alerts('integration_disconnected', p_business_id, p_provider, 'Reconnected');
    return jsonb_build_object('status', 'active', 'retry', false);
  end if;
  update public.integrations set status = case when p_state = 'error' then 'error' else 'disconnected' end, last_error = left(p_error, 300), error_count = error_count + 1, last_checked_at = now() where id = v_i.id;
  -- retry only where it is safe: transient errors, a few times
  v_retry := coalesce(p_retryable, false) and v_i.error_count + 1 <= 3;
  if not v_retry then
    perform public.zella_platform_alert('integration_disconnected', initcap(p_provider) || ' connection problem', p_error, 'urgent', p_business_id, p_provider, jsonb_build_object('state', p_state));
    perform public.zella_notify_owners(p_business_id, 'integration_down', initcap(p_provider) || ' needs reconnecting', 'Your ' || p_provider || ' connection is ' || p_state || '. Open Integrations to reconnect it.', 'urgent', 'integrations');
  end if;
  return jsonb_build_object('status', p_state, 'retry', v_retry, 'retry_in_minutes', case when v_retry then 5 * (v_i.error_count + 1) end);
end $$;

-- 5. a call could not be completed normally
create or replace function public.zella_report_call_failure(p_business_id uuid, p_call_id uuid, p_error text, p_context jsonb default '{}'::jsonb, p_phone text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_phone text := p_phone; v_cb uuid; v_cust uuid; v_recent integer;
begin
  if p_call_id is not null then
    update public.calls set failure_reason = left(p_error, 300), failure_context = p_context where id = p_call_id and business_id = p_business_id
      returning customer_id, coalesce(v_phone, (to_jsonb(calls) ->> 'from_number')) into v_cust, v_phone;
  end if;
  -- fallback: a person follows up, with the error and context kept on the call
  if nullif(trim(coalesce(v_phone, '')), '') is not null then
    v_cb := public.zella_create_callback(p_business_id, v_phone, 'needs_human', 'high', 'The call could not be completed normally. Please call them back.', null, v_cust, p_call_id, null, 'system');
  end if;
  select count(*) into v_recent from public.calls where business_id = p_business_id and failure_reason is not null and created_at > now() - interval '1 hour';
  if v_recent >= 3 then
    perform public.zella_platform_alert('agent_failures', 'The AI receptionist keeps failing calls', v_recent || ' calls failed in the last hour. Last error: ' || left(p_error, 200), 'urgent', p_business_id, to_char(now(), 'YYYY-MM-DD-HH24'));
    perform public.zella_notify_owners(p_business_id, 'agent_failures', 'Some calls could not be handled', 'Several calls failed in the last hour. Zella has queued callbacks for them.', 'urgent', 'callbacks');
  end if;
  return v_cb;
end $$;

-- 6. agent configuration versions: save -> validate -> publish (owners/admins/managers only)
create table if not exists public.agent_config_versions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  agent_id uuid not null references public.ai_agents(id) on delete cascade,
  version integer not null,
  config jsonb not null,
  status text not null default 'draft' check (status in ('draft', 'valid', 'invalid', 'published', 'superseded')),
  validation_errors jsonb not null default '[]'::jsonb,
  sync_status text not null default 'none' check (sync_status in ('none', 'pending', 'live', 'failed')),
  sync_error text,
  created_by uuid, published_by uuid, published_at timestamptz,
  created_at timestamptz not null default now(),
  unique (agent_id, version)
);
alter table public.agent_config_versions enable row level security;
drop policy if exists agent_config_versions_select on public.agent_config_versions;
create policy agent_config_versions_select on public.agent_config_versions for select to authenticated using (public.zella_is_member(business_id));
revoke all on public.agent_config_versions from anon;
revoke insert, update, delete on public.agent_config_versions from authenticated;
grant select on public.agent_config_versions to authenticated;

create or replace function public.zella_can_manage(p_business_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.business_members m where m.business_id = p_business_id and m.user_id = auth.uid() and m.status = 'active' and m.role in ('owner', 'admin', 'manager'));
$$;
revoke all on function public.zella_can_manage(uuid) from public, anon;
grant execute on function public.zella_can_manage(uuid) to authenticated, service_role;

create or replace function public.zella_save_agent_config_draft(p_agent_id uuid, p_config jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_b uuid; v_v integer; v_id uuid; v_allowed text[] := array['system_prompt','personality','tone','goals','capabilities','knowledge_base','escalation_rules','appointment_rules','voice_config','business_context'];
begin
  select business_id into v_b from public.ai_agents where id = p_agent_id;
  if v_b is null or not public.zella_can_manage(v_b) then raise exception 'NOT_ALLOWED'; end if;
  select coalesce(max(version), 0) + 1 into v_v from public.agent_config_versions where agent_id = p_agent_id;
  insert into public.agent_config_versions (business_id, agent_id, version, config, created_by)
  values (v_b, p_agent_id, v_v, (select coalesce(jsonb_object_agg(e.key, e.value), '{}'::jsonb) from jsonb_each(p_config) e where e.key = any (v_allowed)), auth.uid()) returning id into v_id;
  return v_id;
end $$;
create or replace function public.zella_validate_agent_config(p_version_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v record; v_errs jsonb := '[]'::jsonb; c jsonb;
begin
  select * into v from public.agent_config_versions where id = p_version_id for update;
  if not found or (auth.uid() is not null and not public.zella_can_manage(v.business_id)) then raise exception 'NOT_ALLOWED'; end if;
  if v.status in ('published', 'superseded') then raise exception 'ALREADY_PUBLISHED'; end if;
  c := v.config;
  if length(coalesce(trim(c ->> 'system_prompt'), '')) < 20 then v_errs := v_errs || '["The instructions are missing or too short."]'::jsonb; end if;
  if coalesce(c ->> 'system_prompt', '') ~* '(sk-[a-z0-9]{16,}|api[_-]?key|password\s*[:=])' then v_errs := v_errs || '["The instructions contain what looks like a secret key or password. Remove it."]'::jsonb; end if;
  if c ? 'capabilities' and jsonb_typeof(c -> 'capabilities') not in ('object', 'array') then v_errs := v_errs || '["Capabilities are not in a valid format."]'::jsonb; end if;
  if c ? 'escalation_rules' and jsonb_typeof(c -> 'escalation_rules') <> 'object' then v_errs := v_errs || '["Escalation rules are not in a valid format."]'::jsonb; end if;
  if not (c ? 'escalation_rules') or coalesce(c -> 'escalation_rules', '{}'::jsonb) = '{}'::jsonb then v_errs := v_errs || '["Say how callers reach a person (escalation rules)."]'::jsonb; end if;
  update public.agent_config_versions set status = case when jsonb_array_length(v_errs) = 0 then 'valid' else 'invalid' end, validation_errors = v_errs where id = p_version_id;
  return v_errs;
end $$;
create or replace function public.zella_publish_agent_config(p_version_id uuid) returns integer
language plpgsql security definer set search_path = public as $$
declare v record; c jsonb;
begin
  select * into v from public.agent_config_versions where id = p_version_id for update;
  if not found or not public.zella_can_manage(v.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if v.status <> 'valid' then raise exception 'NOT_VALID'; end if;   -- only a validated version can go live
  c := v.config;
  update public.ai_agent_configs set system_prompt = coalesce(c ->> 'system_prompt', system_prompt), personality = coalesce(c ->> 'personality', personality), tone = coalesce(c ->> 'tone', tone),
         goals = coalesce(c -> 'goals', goals), capabilities = coalesce(c -> 'capabilities', capabilities), knowledge_base = coalesce(c -> 'knowledge_base', knowledge_base),
         escalation_rules = coalesce(c -> 'escalation_rules', escalation_rules), appointment_rules = coalesce(c -> 'appointment_rules', appointment_rules),
         voice_config = coalesce(c -> 'voice_config', voice_config), business_context = coalesce(c -> 'business_context', business_context), updated_at = now()
   where agent_id = v.agent_id;
  update public.agent_config_versions set status = 'superseded' where agent_id = v.agent_id and status = 'published';
  update public.agent_config_versions set status = 'published', published_by = auth.uid(), published_at = now(), sync_status = 'pending' where id = p_version_id;
  perform public.zella_notify_owners(v.business_id, 'agent_config_published', 'AI receptionist updated', 'Version ' || v.version || ' was published. It goes live once it has synced.', 'info', 'receptionist');
  return v.version;
end $$;
create or replace function public.zella_claim_agent_syncs(p_limit integer default 10) returns setof public.agent_config_versions
language plpgsql security definer set search_path = public as $$
begin
  return query select v.* from public.agent_config_versions v where v.status = 'published' and v.sync_status = 'pending' order by v.published_at limit greatest(1, least(coalesce(p_limit, 10), 50)) for update skip locked;
end $$;
create or replace function public.zella_complete_agent_sync(p_version_id uuid, p_ok boolean, p_error text default null) returns void
language plpgsql security definer set search_path = public as $$
declare v record;
begin
  select * into v from public.agent_config_versions where id = p_version_id for update;
  if not found or v.status <> 'published' then return; end if;
  update public.agent_config_versions set sync_status = case when p_ok then 'live' else 'failed' end, sync_error = case when p_ok then null else left(p_error, 300) end where id = p_version_id;
  if not p_ok then
    perform public.zella_platform_alert('agent_sync_failed', 'An AI receptionist update did not go live', p_error, 'warning', v.business_id, p_version_id::text);
    perform public.zella_notify_owners(v.business_id, 'agent_sync_failed', 'Your latest AI changes are not live yet', 'We could not apply version ' || v.version || '. The previous version is still answering calls.', 'warning', 'receptionist');
  end if;
end $$;
revoke all on function public.zella_detect_transfer_failures() from public, anon, authenticated;
revoke all on function public.zella_report_telephony_event(uuid, text, text, text, boolean) from public, anon, authenticated;
revoke all on function public.zella_report_call_failure(uuid, uuid, text, jsonb, text) from public, anon, authenticated;
revoke all on function public.zella_save_agent_config_draft(uuid, jsonb) from public, anon;
revoke all on function public.zella_validate_agent_config(uuid) from public, anon;
revoke all on function public.zella_publish_agent_config(uuid) from public, anon;
revoke all on function public.zella_claim_agent_syncs(integer) from public, anon, authenticated;
revoke all on function public.zella_complete_agent_sync(uuid, boolean, text) from public, anon, authenticated;
grant execute on function public.zella_detect_transfer_failures() to service_role;
grant execute on function public.zella_report_telephony_event(uuid, text, text, text, boolean) to service_role;
grant execute on function public.zella_report_call_failure(uuid, uuid, text, jsonb, text) to service_role;
grant execute on function public.zella_save_agent_config_draft(uuid, jsonb) to authenticated, service_role;
grant execute on function public.zella_validate_agent_config(uuid) to authenticated, service_role;
grant execute on function public.zella_publish_agent_config(uuid) to authenticated, service_role;
grant execute on function public.zella_claim_agent_syncs(integer) to service_role;
grant execute on function public.zella_complete_agent_sync(uuid, boolean, text) to service_role;

-- 7. activation check: go live only when the required checks pass
create table if not exists public.activation_tests (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  ok boolean not null,
  detail text,
  created_at timestamptz not null default now()
);
alter table public.activation_tests enable row level security;
drop policy if exists activation_tests_select on public.activation_tests;
create policy activation_tests_select on public.activation_tests for select to authenticated using (public.zella_is_member(business_id));
revoke all on public.activation_tests from anon; revoke insert, update, delete on public.activation_tests from authenticated; grant select on public.activation_tests to authenticated;
-- n8n runs the test call and reports here
create or replace function public.zella_record_activation_test(p_business_id uuid, p_ok boolean, p_detail text default null) returns void
language sql security definer set search_path = public as $$
  insert into public.activation_tests (business_id, ok, detail) values (p_business_id, p_ok, left(p_detail, 300));
$$;
create or replace function public.zella_activation_report(p_business_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_checks jsonb := '[]'::jsonb; v_ok boolean; v_all boolean := true; r record;
begin
  if auth.uid() is not null and not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  for r in
    select * from (values
      ('owner', 'An owner has accepted their invitation', exists (select 1 from public.business_members m where m.business_id = p_business_id and m.status = 'active')),
      ('phone', 'Phone line connected', exists (select 1 from public.integrations i where i.business_id = p_business_id and i.provider = 'telnyx' and i.status = 'active')),
      ('assistant', 'AI assistant connected', exists (select 1 from public.integrations i where i.business_id = p_business_id and i.provider = 'vapi' and i.status = 'active')),
      ('agent', 'AI receptionist has instructions', exists (select 1 from public.ai_agents ag join public.ai_agent_configs cfg on cfg.agent_id = ag.id where ag.business_id = p_business_id and ag.is_default and length(coalesce(cfg.system_prompt, '')) >= 20)),
      ('transfer', 'A way for callers to reach a person', exists (select 1 from public.ai_agents ag join public.ai_agent_configs cfg on cfg.agent_id = ag.id where ag.business_id = p_business_id and ag.is_default and coalesce(cfg.escalation_rules, '{}'::jsonb) <> '{}'::jsonb)),
      ('knowledge', 'At least one approved answer is ready', exists (select 1 from public.knowledge_items k where k.business_id = p_business_id and k.status = 'ready')),
      ('automations', 'At least one automation switched on', exists (select 1 from public.automations a where a.business_id = p_business_id and a.status in ('active', 'paused'))),
      ('test_call', 'A test call passed', coalesce((select t.ok from public.activation_tests t where t.business_id = p_business_id order by t.created_at desc limit 1), false))
    ) as t(key, label, ok)
  loop
    v_checks := v_checks || jsonb_build_array(jsonb_build_object('key', r.key, 'label', r.label, 'ok', r.ok));
    v_all := v_all and r.ok;
  end loop;
  return jsonb_build_object('ready', v_all, 'live', exists (select 1 from public.businesses where id = p_business_id and onboarding_status = 'active'), 'checks', v_checks);
end $$;
-- The business asks to go live. It only happens when every check passes.
create or replace function public.zella_request_activation(p_business_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_rep jsonb;
begin
  if not public.zella_can_manage(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  if exists (select 1 from public.businesses where id = p_business_id and (suspended_at is not null or cancelled_at is not null)) then raise exception 'BUSINESS_NOT_AVAILABLE'; end if;
  v_rep := public.zella_activation_report(p_business_id);
  if (v_rep ->> 'ready')::boolean then
    update public.businesses set onboarding_status = 'active', is_active = true, updated_at = now() where id = p_business_id;
    update public.automations set status = 'active', updated_at = now() where business_id = p_business_id and status = 'paused';
    perform public.zella_resolve_platform_alerts('setup_incomplete', p_business_id, null, 'Went live');
    perform public.zella_notify_owners(p_business_id, 'went_live', 'You are live', 'Your AI receptionist is now answering calls.', 'info', 'today');
  end if;
  return v_rep;
end $$;
revoke all on function public.zella_record_activation_test(uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.zella_activation_report(uuid) from public, anon;
revoke all on function public.zella_request_activation(uuid) from public, anon;
grant execute on function public.zella_record_activation_test(uuid, boolean, text) to service_role;
grant execute on function public.zella_activation_report(uuid) to authenticated, service_role;
grant execute on function public.zella_request_activation(uuid) to authenticated, service_role;

-- 8. performance review: what happened, and what to look at
create or replace function public.zella_performance_review(p_business_id uuid, p_days integer default 7) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_since timestamptz := now() - make_interval(days => greatest(1, least(coalesce(p_days, 7), 90)));
        v_calls integer; v_missed integer; v_ai integer; v_tf integer; v_fail integer; v_gaps integer; v_booked integer; v_cb_open integer; v_cb_review integer; v_noshow integer; v_issues jsonb := '[]'::jsonb;
begin
  if auth.uid() is not null and not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  select count(*), count(*) filter (where status = 'missed'), count(*) filter (where coalesce(ai_handled, false)),
         count(*) filter (where transfer_status in ('failed', 'no_one_available')), count(*) filter (where failure_reason is not null)
    into v_calls, v_missed, v_ai, v_tf, v_fail from public.calls where business_id = p_business_id and created_at >= v_since;
  select count(*) into v_gaps from public.knowledge_gaps where business_id = p_business_id and status = 'open';
  select count(*) into v_booked from public.appointments where business_id = p_business_id and created_at >= v_since and coalesce(booking_state, 'confirmed') = 'confirmed';
  select count(*) filter (where status not in ('completed', 'cancelled', 'needs_review')), count(*) filter (where status = 'needs_review') into v_cb_open, v_cb_review from public.callbacks where business_id = p_business_id;
  select count(*) into v_noshow from public.appointments where business_id = p_business_id and status = 'no_show' and start_time >= v_since;
  if v_calls > 0 and v_missed::numeric / v_calls > 0.2 then v_issues := v_issues || to_jsonb(v_missed || ' of ' || v_calls || ' calls were missed.'); end if;
  if v_tf > 0 then v_issues := v_issues || to_jsonb(v_tf || ' transfer(s) to a person failed.'); end if;
  if v_fail > 0 then v_issues := v_issues || to_jsonb(v_fail || ' call(s) could not be completed.'); end if;
  if v_gaps > 0 then v_issues := v_issues || to_jsonb(v_gaps || ' question(s) Zella could not answer need your review.'); end if;
  if v_cb_review > 0 then v_issues := v_issues || to_jsonb(v_cb_review || ' callback(s) need a person.'); end if;
  if v_noshow > 0 then v_issues := v_issues || to_jsonb(v_noshow || ' no-show(s).'); end if;
  return jsonb_build_object('days', p_days, 'calls', v_calls, 'missed', v_missed, 'ai_handled', v_ai, 'transfers_failed', v_tf, 'failed_calls', v_fail,
    'unanswered_questions', v_gaps, 'appointments_booked', v_booked, 'callbacks_open', v_cb_open, 'callbacks_needing_review', v_cb_review, 'no_shows', v_noshow, 'issues', v_issues);
end $$;
-- n8n (weekly): post each live business's review to its owners
create or replace function public.zella_post_weekly_reviews() returns integer
language plpgsql security definer set search_path = public as $$
declare b record; v_rev jsonb; n integer := 0;
begin
  for b in select id from public.businesses where onboarding_status = 'active' and suspended_at is null and cancelled_at is null loop
    v_rev := public.zella_performance_review(b.id, 7);
    if (v_rev ->> 'calls')::int > 0 or jsonb_array_length(v_rev -> 'issues') > 0 then
      perform public.zella_notify_owners(b.id, 'weekly_review', 'Your week with Zella',
        (v_rev ->> 'calls') || ' calls, ' || (v_rev ->> 'appointments_booked') || ' booked.' || case when jsonb_array_length(v_rev -> 'issues') > 0 then ' To look at: ' || (select string_agg(x, ' ') from jsonb_array_elements_text(v_rev -> 'issues') x) else ' Nothing needs attention.' end,
        case when jsonb_array_length(v_rev -> 'issues') > 0 then 'warning' else 'info' end, 'reports');
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;
revoke all on function public.zella_performance_review(uuid, integer) from public, anon;
revoke all on function public.zella_post_weekly_reviews() from public, anon, authenticated;
grant execute on function public.zella_performance_review(uuid, integer) to authenticated, service_role;
grant execute on function public.zella_post_weekly_reviews() to service_role;

-- =========================================================
-- B. Platform-owner workflows
-- =========================================================
alter table public.business_invitations add column if not exists reminder_count integer not null default 0, add column if not exists last_reminded_at timestamptz;
alter table public.subscriptions add column if not exists status_changed_at timestamptz not null default now(),
  add column if not exists past_due_since timestamptz, add column if not exists trial_notice_days integer[] not null default '{}';
alter table public.businesses add column if not exists retention_until timestamptz;
alter table public.automations add column if not exists paused_by_suspension boolean not null default false;

-- 1. provisioning tracker: the edge function reports each stage
create table if not exists public.provisioning_steps (
  business_id uuid not null references public.businesses(id) on delete cascade,
  step text not null,
  status text not null default 'pending' check (status in ('pending', 'done', 'failed')),
  error text,
  updated_at timestamptz not null default now(),
  primary key (business_id, step)
);
alter table public.provisioning_steps enable row level security;
revoke all on public.provisioning_steps from anon, authenticated;
create or replace function public.zella_track_provisioning(p_business_id uuid, p_step text, p_status text, p_error text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into public.provisioning_steps (business_id, step, status, error) values (p_business_id, p_step, p_status, left(p_error, 300))
  on conflict (business_id, step) do update set status = excluded.status, error = excluded.error, updated_at = now();
  if p_status = 'failed' then
    perform public.zella_platform_alert('provisioning_failed', 'Setup failed at: ' || p_step, p_error, 'urgent', p_business_id, p_step);
  else
    perform public.zella_resolve_platform_alerts('provisioning_failed', p_business_id, p_step, 'Step completed');
  end if;
end $$;
-- After a retry, check the result really is complete
create or replace function public.zella_verify_provisioning(p_business_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_missing text[] := '{}';
begin
  if not exists (select 1 from public.business_members m where m.business_id = p_business_id) then v_missing := array_append(v_missing, 'owner'); end if;
  if not exists (select 1 from public.business_modules bm where bm.business_id = p_business_id) then v_missing := array_append(v_missing, 'modules'); end if;
  if not exists (select 1 from public.ai_agents a where a.business_id = p_business_id) then v_missing := array_append(v_missing, 'ai_agent'); end if;
  if not exists (select 1 from public.automations a where a.business_id = p_business_id) then v_missing := array_append(v_missing, 'automations'); end if;
  if cardinality(v_missing) = 0 and not exists (select 1 from public.provisioning_steps where business_id = p_business_id and status = 'failed') then
    perform public.zella_resolve_platform_alerts('provisioning_failed', p_business_id, null, 'Verified complete');
  end if;
  return jsonb_build_object('complete', cardinality(v_missing) = 0, 'missing', to_jsonb(v_missing));
end $$;
create or replace function public.zella_business_status_trigger() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  -- failed provisioning shows up for admins
  if new.onboarding_status = 'failed' and old.onboarding_status is distinct from 'failed' then
    perform public.zella_platform_alert('provisioning_failed', 'Business setup failed', 'Open the business to see the failed step and retry.', 'urgent', new.id, 'status');
  elsif old.onboarding_status = 'failed' and new.onboarding_status <> 'failed' then
    perform public.zella_resolve_platform_alerts('provisioning_failed', new.id, 'status', 'Status changed');
  end if;
  -- suspension: stop what must not run, keep every record
  if new.suspended_at is not null and old.suspended_at is null then
    update public.automations set status = 'paused', paused_by_suspension = true where business_id = new.id and status = 'active';
    update public.callbacks set status = 'needs_review', outcome = 'business_suspended', auto_call = false, updated_at = now() where business_id = new.id and status in ('scheduled', 'retry_scheduled', 'due', 'new');
    update public.followup_tasks set status = 'cancelled', outcome = 'business_suspended', completed_at = now(), updated_at = now() where business_id = new.id and status = 'pending';
    update public.appointment_reminders set status = 'cancelled', error = 'business_suspended' where business_id = new.id and status = 'pending';
    update public.waitlist_entries set status = 'waiting', offered_start = null, offered_end = null, offer_expires_at = null where business_id = new.id and status = 'offered';
    perform public.zella_platform_alert('business_suspended', 'Business suspended', new.suspension_reason, 'info', new.id, to_char(new.suspended_at, 'YYYY-MM-DD'));
  elsif new.suspended_at is null and old.suspended_at is not null then
    update public.automations set status = 'active', paused_by_suspension = false where business_id = new.id and paused_by_suspension;
    perform public.zella_resolve_platform_alerts('business_suspended', new.id, null, 'Reinstated');
  end if;
  return new;
end $$;
-- retention_until is set before the row is written, so use a BEFORE trigger for it
create or replace function public.zella_business_before_trigger() returns trigger
language plpgsql set search_path = public as $$
declare v_days integer;
begin
  if new.cancelled_at is not null and old.cancelled_at is null then
    v_days := coalesce((select (value)::text::integer from public.platform_settings where key = 'retention_days'), 90);
    new.retention_until := new.cancelled_at + make_interval(days => v_days);
  end if;
  return new;
end $$;
drop trigger if exists zella_business_before_trg on public.businesses;
create trigger zella_business_before_trg before update of cancelled_at on public.businesses for each row execute function public.zella_business_before_trigger();
drop trigger if exists zella_business_status_trg on public.businesses;
create trigger zella_business_status_trg after update of onboarding_status, suspended_at on public.businesses for each row execute function public.zella_business_status_trigger();

-- records past their retention date are listed for a person to review. Nothing is deleted automatically.
create or replace function public.zella_retention_due() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('business_id', id, 'name', name, 'retention_until', retention_until)), '[]'::jsonb)
    from public.businesses where cancelled_at is not null and retention_until is not null and retention_until < now();
$$;

-- 2. invitations: remind on a schedule, flag expired ones
create or replace function public.zella_check_invitations() returns jsonb
language plpgsql security definer set search_path = public as $$
declare i record; v_hours jsonb := public.zella_setting('invitation_reminder_hours', '[24, 72]'); v_due jsonb := '[]'::jsonb; v_next numeric; v_expired integer := 0;
begin
  for i in select * from public.business_invitations where status in ('pending', 'sent', 'failed') for update skip locked loop
    if i.expires_at is not null and i.expires_at < now() then
      update public.business_invitations set status = 'expired', updated_at = now() where id = i.id; v_expired := v_expired + 1;
      perform public.zella_platform_alert('invitation_expired', 'Owner invitation expired', i.email, 'warning', i.business_id, i.id::text);
      continue;
    end if;
    if i.reminder_count < jsonb_array_length(v_hours) then
      v_next := (v_hours ->> i.reminder_count)::numeric;
      if coalesce(i.last_reminded_at, i.invited_at, i.created_at) <= now() - make_interval(secs => v_next * 3600)
         and coalesce(i.invited_at, i.created_at) <= now() - make_interval(secs => v_next * 3600) then
        v_due := v_due || jsonb_build_array(jsonb_build_object('invitation_id', i.id, 'business_id', i.business_id, 'email', i.email, 'owner_name', i.owner_name, 'reminder_no', i.reminder_count + 1));
      end if;
    end if;
  end loop;
  return jsonb_build_object('reminders_due', v_due, 'expired', v_expired);
end $$;
create or replace function public.zella_mark_invitation_reminded(p_invitation_id uuid) returns void
language sql security definer set search_path = public as $$
  update public.business_invitations set reminder_count = reminder_count + 1, last_reminded_at = now(), updated_at = now() where id = p_invitation_id;
$$;

-- 3. setup incomplete
create or replace function public.zella_check_setup_incomplete() returns integer
language plpgsql security definer set search_path = public as $$
declare b record; v_days integer := (public.zella_setting('setup_incomplete_after_days', '3'))::text::integer; v_rep jsonb; v_missing text; n integer := 0;
begin
  for b in select * from public.businesses where onboarding_status not in ('active', 'paused', 'failed') and suspended_at is null and cancelled_at is null and created_at < now() - make_interval(days => v_days) loop
    v_rep := public.zella_activation_report(b.id);
    select string_agg(c ->> 'label', ', ') into v_missing from jsonb_array_elements(v_rep -> 'checks') c where not (c ->> 'ok')::boolean;
    if v_missing is not null then
      perform public.zella_platform_alert('setup_incomplete', b.name || ' has not finished setup', 'Still missing: ' || v_missing, 'warning', b.id, to_char(now(), 'IYYY-IW'));
      -- the business owner is told too, once a week
      if not exists (select 1 from public.staff_notifications where business_id = b.id and kind = 'setup_incomplete' and created_at > now() - interval '7 days') then
        perform public.zella_notify_owners(b.id, 'setup_incomplete', 'Finish setting up Zella', 'Still to do: ' || v_missing, 'info', 'receptionist');
      end if;
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- 5/6. subscriptions: payment failures and trials (no prices anywhere)
create or replace function public.zella_subscription_trigger() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    new.status_changed_at := now();
    new.past_due_since := case when new.status = 'past_due' then coalesce(old.past_due_since, now()) when new.status in ('active', 'trial') then null else old.past_due_since end;
  end if;
  return new;
end $$;
drop trigger if exists zella_subscription_before_trg on public.subscriptions;
create trigger zella_subscription_before_trg before update on public.subscriptions for each row execute function public.zella_subscription_trigger();
create or replace function public.zella_subscription_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'past_due' and old.status is distinct from 'past_due' then
    perform public.zella_platform_alert('payment_failed', 'A payment failed', null, 'urgent', new.business_id, 'payment');
    perform public.zella_notify_owners(new.business_id, 'payment_failed', 'Your payment did not go through', 'Please update your billing details to keep Zella running.', 'urgent', 'settings');
  elsif new.status in ('active', 'trial') and old.status in ('past_due', 'grace_period') then
    perform public.zella_resolve_platform_alerts('payment_failed', new.business_id, 'payment', 'Payment recovered');
    perform public.zella_resolve_platform_alerts('payment_overdue', new.business_id, 'payment', 'Payment recovered');
  end if;
  return new;
end $$;
drop trigger if exists zella_subscription_after_trg on public.subscriptions;
create trigger zella_subscription_after_trg after update of status on public.subscriptions for each row execute function public.zella_subscription_after();

-- the payment provider (via n8n) reports a result
create or replace function public.zella_record_payment_result(p_business_id uuid, p_ok boolean, p_provider_ref text default null, p_error text default null) returns text
language plpgsql security definer set search_path = public as $$
declare s record;
begin
  select * into s from public.subscriptions where business_id = p_business_id order by created_at desc limit 1 for update;
  if not found then raise exception 'SUBSCRIPTION_NOT_FOUND'; end if;
  if p_ok then update public.subscriptions set status = 'active' where id = s.id and status in ('past_due', 'grace_period', 'renewal_due', 'trial'); return 'active'; end if;
  update public.subscriptions set status = 'past_due' where id = s.id and status in ('active', 'renewal_due', 'trial', 'past_due');
  perform public.zella_platform_alert('payment_failed', 'A payment failed', left(p_error, 300), 'urgent', p_business_id, 'payment', jsonb_build_object('provider_ref', p_provider_ref));
  return 'past_due';
end $$;
-- configured policy: after the grace period move to grace_period, and (only if switched on) suspend later
create or replace function public.zella_apply_payment_policy() returns integer
language plpgsql security definer set search_path = public as $$
declare s record; v_grace integer := (public.zella_setting('payment_grace_days', '7'))::text::integer; v_susp integer := (public.zella_setting('payment_suspend_after_days', '14'))::text::integer;
        v_auto boolean := (public.zella_setting('payment_auto_suspend', 'false'))::text::boolean; n integer := 0;
begin
  for s in select * from public.subscriptions where status in ('past_due', 'grace_period') and past_due_since is not null for update skip locked loop
    if s.status = 'past_due' and s.past_due_since < now() - make_interval(days => v_grace) then
      update public.subscriptions set status = 'grace_period' where id = s.id;
      perform public.zella_notify_owners(s.business_id, 'payment_overdue', 'Your account is overdue', 'Update your billing details soon to avoid your service being paused.', 'urgent', 'settings');
      perform public.zella_platform_alert('payment_overdue', 'Payment overdue', null, 'urgent', s.business_id, 'payment');
      n := n + 1;
    end if;
    if v_auto and s.past_due_since < now() - make_interval(days => v_susp) then
      update public.businesses set suspended_at = now(), suspension_reason = 'Payment overdue' where id = s.business_id and suspended_at is null and cancelled_at is null;
      if found then n := n + 1; end if;
    end if;
  end loop;
  return n;
end $$;
-- trial ending: notices at the configured days; stops when the plan changes or the subscription ends
create or replace function public.zella_check_trials() returns integer
language plpgsql security definer set search_path = public as $$
declare s record; v_days jsonb := public.zella_setting('trial_notice_days', '[7, 3, 1]'); d integer; v_left numeric; n integer := 0;
begin
  for s in select * from public.subscriptions where status = 'trial' and trial_end_at is not null for update skip locked loop
    v_left := extract(epoch from (s.trial_end_at - now())) / 86400.0;
    if v_left <= 0 then
      perform public.zella_platform_alert('trial_ended', 'A trial has ended', null, 'warning', s.business_id, to_char(s.trial_end_at, 'YYYY-MM-DD'));
      perform public.zella_notify_owners(s.business_id, 'trial_ended', 'Your trial has ended', 'Choose a plan to keep using Zella.', 'urgent', 'settings');
      n := n + 1; continue;
    end if;
    select min(x::integer) into d from jsonb_array_elements_text(v_days) x where v_left <= x::integer;
    if d is not null and not (d = any (s.trial_notice_days)) then
      -- remember every threshold already passed so only one notice goes out
      update public.subscriptions set trial_notice_days = array(select distinct unnest(trial_notice_days || array(select x::integer from jsonb_array_elements_text(v_days) x where x::integer >= d))) where id = s.id;
      perform public.zella_notify_owners(s.business_id, 'trial_ending', 'Your trial ends in ' || ceil(v_left)::int || ' day(s)', 'Choose a plan to keep your AI receptionist running.', 'warning', 'settings');
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- 9. new platform administrator: validate the role, record an audit event, tell the owners
do $$ begin
  if to_regclass('public.platform_admins') is not null then
    create or replace function public.zella_platform_admin_trigger() returns trigger
    language plpgsql security definer set search_path = public as $f$
    begin
      if tg_op in ('INSERT', 'UPDATE') then
        if new.role not in ('super_admin', 'zella_owner') then raise exception 'INVALID_ADMIN_ROLE'; end if;
      end if;
      return new;
    end $f$;
    create or replace function public.zella_platform_admin_audit() returns trigger
    language plpgsql security definer set search_path = public as $f$
    declare v_action text;
    begin
      if tg_op = 'INSERT' and new.is_active then v_action := 'platform_admin_granted';
      elsif tg_op = 'UPDATE' and new.is_active and not old.is_active then v_action := 'platform_admin_reactivated';
      elsif tg_op = 'UPDATE' and not new.is_active and old.is_active then v_action := 'platform_admin_removed';
      elsif tg_op = 'UPDATE' and new.role is distinct from old.role then v_action := 'platform_admin_role_changed';
      else return new; end if;
      insert into public.audit_logs (user_id, action, entity_type, entity_id, old_data, new_data)
      values (auth.uid(), v_action, 'platform_admin', new.user_id, case when tg_op = 'UPDATE' then jsonb_build_object('role', old.role, 'is_active', old.is_active) end, jsonb_build_object('role', new.role, 'is_active', new.is_active));
      perform public.zella_platform_alert('platform_admin_change', replace(v_action, '_', ' '), 'Role: ' || new.role, 'info', null, new.user_id::text || ':' || v_action || ':' || to_char(now(), 'YYYYMMDDHH24MISS'));
      return new;
    end $f$;
    drop trigger if exists zella_platform_admin_before_trg on public.platform_admins;
    create trigger zella_platform_admin_before_trg before insert or update on public.platform_admins for each row execute function public.zella_platform_admin_trigger();
    drop trigger if exists zella_platform_admin_after_trg on public.platform_admins;
    create trigger zella_platform_admin_after_trg after insert or update on public.platform_admins for each row execute function public.zella_platform_admin_audit();
  end if;
end $$;

-- 10. platform service incident: only VERIFIED health signals create one
create or replace function public.zella_report_service_health(p_service text, p_ok boolean, p_detail text default null, p_verified boolean default false) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if p_ok then
    perform public.zella_resolve_platform_alerts('service_incident', null, p_service, 'Service healthy again');
    return null;
  end if;
  if not coalesce(p_verified, false) then return null; end if;   -- a single unverified blip is not an incident
  v_id := public.zella_platform_alert('service_incident', initcap(p_service) || ' is having problems', p_detail, 'urgent', null, p_service);
  return v_id;
end $$;

revoke all on function public.zella_track_provisioning(uuid, text, text, text) from public, anon, authenticated;
revoke all on function public.zella_verify_provisioning(uuid) from public, anon, authenticated;
revoke all on function public.zella_business_status_trigger() from public, anon, authenticated;
revoke all on function public.zella_retention_due() from public, anon, authenticated;
revoke all on function public.zella_check_invitations() from public, anon, authenticated;
revoke all on function public.zella_mark_invitation_reminded(uuid) from public, anon, authenticated;
revoke all on function public.zella_check_setup_incomplete() from public, anon, authenticated;
revoke all on function public.zella_subscription_after() from public, anon, authenticated;
revoke all on function public.zella_record_payment_result(uuid, boolean, text, text) from public, anon, authenticated;
revoke all on function public.zella_apply_payment_policy() from public, anon, authenticated;
revoke all on function public.zella_check_trials() from public, anon, authenticated;
revoke all on function public.zella_report_service_health(text, boolean, text, boolean) from public, anon, authenticated;
grant execute on function public.zella_track_provisioning(uuid, text, text, text) to service_role;
grant execute on function public.zella_verify_provisioning(uuid) to service_role;
grant execute on function public.zella_retention_due() to service_role;
grant execute on function public.zella_check_invitations() to service_role;
grant execute on function public.zella_mark_invitation_reminded(uuid) to service_role;
grant execute on function public.zella_check_setup_incomplete() to service_role;
grant execute on function public.zella_record_payment_result(uuid, boolean, text, text) to service_role;
grant execute on function public.zella_apply_payment_policy() to service_role;
grant execute on function public.zella_check_trials() to service_role;
grant execute on function public.zella_report_service_health(text, boolean, text, boolean) to service_role;
