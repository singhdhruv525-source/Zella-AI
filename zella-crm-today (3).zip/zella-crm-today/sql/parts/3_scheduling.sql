-- =========================================================
-- Zella workflows, part 3: appointments. Booking states, reminders
-- that follow reschedules/cancellations, safe booking + rescheduling,
-- cancellation slot recovery with a waitlist, staff-unavailable handling,
-- post-appointment follow-up.
-- Run AFTER parts 1 and 2. Safe to re-run.
-- =========================================================

alter table public.appointments
  add column if not exists booking_state text not null default 'confirmed',
  add column if not exists hold_expires_at timestamptz,
  add column if not exists original_start_time timestamptz,
  add column if not exists rescheduled_at timestamptz,
  add column if not exists reschedule_count integer not null default 0,
  add column if not exists reschedule_requested_by text,
  add column if not exists cancelled_at timestamptz,
  add column if not exists cancel_reason text,
  add column if not exists conflict_note text;
do $$ begin
  alter table public.appointments add constraint appointments_booking_state_chk check (booking_state in ('requested', 'tentative', 'confirmed'));
exception when duplicate_object then null; end $$;

create table if not exists public.appointment_reminders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  appointment_id uuid not null references public.appointments(id) on delete cascade,
  customer_id uuid,
  kind text not null check (kind in ('reminder', 'confirmation', 'confirmation_request')),
  channel text not null default 'sms',
  hours_before numeric,
  reason text,                         -- booked | rescheduled
  due_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending', 'sending', 'sent', 'failed', 'cancelled', 'skipped')),
  attempts integer not null default 0,
  sent_at timestamptz,
  error text,
  created_at timestamptz not null default now()
);
create index if not exists appointment_reminders_due_idx on public.appointment_reminders (due_at) where status = 'pending';
create index if not exists appointment_reminders_appt_idx on public.appointment_reminders (appointment_id);
create unique index if not exists appointment_reminders_one_live_idx
  on public.appointment_reminders (appointment_id, kind, coalesce(hours_before, 0)) where status in ('pending', 'sending');
-- older installs
alter table public.appointment_reminders add column if not exists channel text not null default 'sms';
do $$ begin alter table public.appointment_reminders drop constraint if exists appointment_reminders_kind_check;
  alter table public.appointment_reminders add constraint appointment_reminders_kind_check check (kind in ('reminder', 'confirmation', 'confirmation_request')); end $$;
alter table public.appointment_reminders enable row level security;
drop policy if exists appointment_reminders_select on public.appointment_reminders;
create policy appointment_reminders_select on public.appointment_reminders for select to authenticated using (public.zella_is_member(business_id));
revoke all on public.appointment_reminders from anon;
revoke insert, update, delete on public.appointment_reminders from authenticated;
grant select on public.appointment_reminders to authenticated;

create table if not exists public.waitlist_entries (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  title text,                          -- service / reason
  duration_minutes integer not null default 30,
  earliest_at timestamptz,
  latest_at timestamptz,
  staff_id uuid,
  notes text,
  status text not null default 'waiting' check (status in ('waiting', 'offered', 'booked', 'removed')),
  offered_start timestamptz,
  offered_end timestamptz,
  offered_staff_id uuid,
  offer_expires_at timestamptz,
  appointment_id uuid,
  created_at timestamptz not null default now()
);
create index if not exists waitlist_biz_idx on public.waitlist_entries (business_id, status, created_at);
create unique index if not exists waitlist_one_active_idx on public.waitlist_entries (business_id, customer_id, coalesce(title, '')) where status in ('waiting', 'offered');
alter table public.waitlist_entries enable row level security;
drop policy if exists waitlist_select on public.waitlist_entries;
create policy waitlist_select on public.waitlist_entries for select to authenticated using (public.zella_is_member(business_id));
revoke all on public.waitlist_entries from anon;
revoke insert, update, delete on public.waitlist_entries from authenticated;
grant select on public.waitlist_entries to authenticated;

-- ---- reminders ------------------------------------------------------------
create or replace function public.zella_replace_reminders(p_appointment_id uuid, p_send_confirmation boolean default false, p_reason text default 'booked')
returns void language plpgsql security definer set search_path = public as $$
declare a record; v_rem record; v_conf record; v_hours numeric[]; h numeric;
begin
  update public.appointment_reminders set status = 'cancelled', error = 'replaced' where appointment_id = p_appointment_id and status in ('pending');
  select * into a from public.appointments where id = p_appointment_id;
  if not found or a.status not in ('scheduled', 'confirmed') or coalesce(a.booking_state, 'confirmed') <> 'confirmed' or a.start_time <= now() then return; end if;

  select x.* into v_rem from public.automations x where x.business_id = a.business_id and x.trigger_type = 'appointment_reminder' and x.status = 'active' limit 1;
  if v_rem.id is not null then
    v_hours := case when v_rem.trigger_config ? 'hours_before' and jsonb_typeof(v_rem.trigger_config -> 'hours_before') = 'array'
                    then array(select jsonb_array_elements_text(v_rem.trigger_config -> 'hours_before')::numeric) else array[24]::numeric[] end;
    foreach h in array v_hours loop
      if a.start_time - make_interval(secs => h * 3600) > now() then
        insert into public.appointment_reminders (business_id, appointment_id, customer_id, kind, hours_before, reason, due_at, channel)
        values (a.business_id, a.id, a.customer_id, 'reminder', h, p_reason, a.start_time - make_interval(secs => h * 3600), coalesce(v_rem.trigger_config ->> 'channel', 'sms')) on conflict do nothing;
      end if;
    end loop;
  end if;
  select x.* into v_conf from public.automations x where x.business_id = a.business_id and x.trigger_type = 'appointment_confirmation' and x.status = 'active' limit 1;
  if v_conf.id is not null then
    if p_send_confirmation then
      insert into public.appointment_reminders (business_id, appointment_id, customer_id, kind, reason, due_at, channel)
      values (a.business_id, a.id, a.customer_id, 'confirmation', p_reason, now(), coalesce(v_conf.trigger_config ->> 'channel', 'sms')) on conflict do nothing;
    end if;
    -- later, ask them to confirm they are still coming
    h := coalesce((v_conf.trigger_config ->> 'hours_before')::numeric, 24);
    if a.start_time - make_interval(secs => h * 3600) > now() then
      insert into public.appointment_reminders (business_id, appointment_id, customer_id, kind, hours_before, reason, due_at, channel)
      values (a.business_id, a.id, a.customer_id, 'confirmation_request', h, p_reason, a.start_time - make_interval(secs => h * 3600), coalesce(v_conf.trigger_config ->> 'channel', 'sms')) on conflict do nothing;
    end if;
  end if;
end $$;
revoke all on function public.zella_replace_reminders(uuid, boolean, text) from public, anon, authenticated;

create or replace function public.zella_appointment_before() returns trigger
language plpgsql set search_path = public as $$
begin
  if tg_op = 'UPDATE' then
    if new.start_time is distinct from old.start_time then
      new.original_start_time := coalesce(old.original_start_time, old.start_time);
      new.rescheduled_at := now();
      new.reschedule_count := coalesce(old.reschedule_count, 0) + 1;
      new.conflict_note := null;
    end if;
    if new.status = 'cancelled' and old.status is distinct from 'cancelled' then new.cancelled_at := now(); end if;
  end if;
  return new;
end $$;
drop trigger if exists zella_appointment_before_trg on public.appointments;
create trigger zella_appointment_before_trg before update on public.appointments for each row execute function public.zella_appointment_before();

-- ---- cancellation: offer the freed slot to the waitlist ----------------------------
create or replace function public.zella_offer_slot(p_business_id uuid, p_start timestamptz, p_end timestamptz, p_staff_id uuid, p_exclude_customer uuid default null)
returns integer language plpgsql security definer set search_path = public as $$
declare v_auto record; w record; v_n integer := 0; v_max integer; v_tz text; v_mins integer;
begin
  select a.* into v_auto from public.automations a where a.business_id = p_business_id and a.trigger_type = 'waitlist_offer' and a.status = 'active' limit 1;
  if v_auto.id is null or p_start <= now() then return 0; end if;
  v_max := coalesce((v_auto.trigger_config ->> 'offers')::integer, 1);
  v_mins := coalesce((v_auto.trigger_config ->> 'offer_minutes')::integer, 30);
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id and b.suspended_at is null and b.cancelled_at is null;
  if v_tz is null then return 0; end if;
  for w in
    select e.* from public.waitlist_entries e join public.customers c on c.id = e.customer_id
     where e.business_id = p_business_id and e.status = 'waiting'
       and (p_exclude_customer is null or e.customer_id <> p_exclude_customer)
       and (e.earliest_at is null or e.earliest_at <= p_start) and (e.latest_at is null or e.latest_at >= p_end)
       and (e.staff_id is null or p_staff_id is null or e.staff_id = p_staff_id)
       and e.duration_minutes <= extract(epoch from (p_end - p_start)) / 60
       and not coalesce(c.do_not_contact, false) and public.zella_digits(c.phone) is not null
     order by e.created_at limit v_max for update of e skip locked
  loop
    update public.waitlist_entries set status = 'offered', offered_start = p_start, offered_end = p_start + make_interval(mins => w.duration_minutes),
           offered_staff_id = p_staff_id, offer_expires_at = now() + make_interval(mins => v_mins) where id = w.id;
    -- the customer is only asked; nothing is reserved until they say yes
    insert into public.followup_tasks (business_id, customer_id, kind, channel, due_at, max_attempts, entity_ref)
    values (p_business_id, w.customer_id, 'waitlist_offer', 'sms', public.zella_next_call_time(now(), v_tz), 1, w.id);
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;
revoke all on function public.zella_offer_slot(uuid, timestamptz, timestamptz, uuid, uuid) from public, anon, authenticated;
grant execute on function public.zella_offer_slot(uuid, timestamptz, timestamptz, uuid, uuid) to service_role;

create or replace function public.zella_appointment_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_old jsonb := case when tg_op = 'UPDATE' then to_jsonb(old) else '{}'::jsonb end; v_new jsonb := to_jsonb(new);
        v_time_changed boolean := tg_op = 'UPDATE' and new.start_time is distinct from old.start_time;
        v_status_changed boolean := tg_op = 'UPDATE' and new.status is distinct from old.status;
        v_state_changed boolean := tg_op = 'UPDATE' and coalesce(v_new ->> 'booking_state', '') is distinct from coalesce(v_old ->> 'booking_state', '');
        v_auto record; v_tz text; v_who text;
begin
  select coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), new.title) into v_who from public.customers c where c.id = new.customer_id;
  v_who := coalesce(v_who, new.title);

  if tg_op = 'INSERT' then
    if new.status in ('scheduled', 'confirmed') then perform public.zella_replace_reminders(new.id, true, 'booked'); end if;
    return new;
  end if;

  if new.status in ('cancelled', 'no_show', 'completed') and v_status_changed then
    update public.appointment_reminders set status = 'cancelled', error = 'appointment_' || new.status where appointment_id = new.id and status = 'pending';
  end if;

  if new.status = 'cancelled' and v_status_changed then
    perform public.zella_notify(new.business_id, 'appointment_cancelled', 'Appointment cancelled', v_who || ' cancelled.' || coalesce(' ' || new.cancel_reason, ''), 'info', 'calendar', new.id);
    -- release the slot: offer it to people on the waitlist if the business turned that on
    perform public.zella_offer_slot(new.business_id, new.start_time, new.end_time, new.staff_id, new.customer_id);
  elsif new.status in ('scheduled', 'confirmed') and (v_time_changed or (v_status_changed and old.status in ('cancelled', 'no_show')) or (v_state_changed and new.booking_state = 'confirmed')) then
    perform public.zella_replace_reminders(new.id, v_time_changed or v_state_changed, case when v_time_changed then 'rescheduled' else 'booked' end);
    if v_time_changed then
      perform public.zella_notify(new.business_id, 'appointment_rescheduled', 'Appointment rescheduled', v_who || ' moved to a new time.', 'info', 'calendar', new.id);
      -- the old slot is free again
      if old.start_time > now() then perform public.zella_offer_slot(new.business_id, old.start_time, old.end_time, old.staff_id, new.customer_id); end if;
    end if;
  end if;

  -- post-appointment follow-up (feedback, thank you, maintenance reminder)
  if new.status = 'completed' and v_status_changed and new.customer_id is not null then
    select x.* into v_auto from public.automations x where x.business_id = new.business_id and x.trigger_type = 'post_appointment_follow_up' and x.status = 'active' limit 1;
    if v_auto.id is not null and exists (select 1 from public.customers c where c.id = new.customer_id and not coalesce(c.do_not_contact, false) and public.zella_digits(c.phone) is not null) then
      select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = new.business_id;
      insert into public.followup_tasks (business_id, customer_id, appointment_id, kind, channel, due_at, max_attempts)
      values (new.business_id, new.customer_id, new.id, 'post_appointment_follow_up', case when v_auto.trigger_config ->> 'channel' = 'call' then 'call' else 'sms' end,
              public.zella_next_call_time(now() + make_interval(hours => coalesce((v_auto.trigger_config ->> 'hours_after')::integer, 24)), v_tz), 1) on conflict do nothing;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists zella_appointment_after_trg on public.appointments;
create trigger zella_appointment_after_trg after insert or update on public.appointments for each row execute function public.zella_appointment_after();

-- n8n: take reminders / confirmations that are due.
create or replace function public.zella_claim_reminders(p_limit integer default 25) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_res jsonb := '[]'::jsonb; r record; a record; c record; b record; v_staff text;
begin
  for r in select * from public.appointment_reminders where status = 'pending' and due_at <= now() order by due_at
           limit greatest(1, least(coalesce(p_limit, 25), 100)) for update skip locked loop
    select * into a from public.appointments where id = r.appointment_id;
    select * into c from public.customers where id = r.customer_id;
    select id, name, coalesce(timezone, 'America/New_York') as tz, suspended_at, cancelled_at into b from public.businesses where id = r.business_id;
    if a.id is null or a.status not in ('scheduled', 'confirmed') or coalesce(a.booking_state, 'confirmed') <> 'confirmed' or (r.kind in ('reminder', 'confirmation_request') and a.start_time <= now()) then
      update public.appointment_reminders set status = 'skipped', error = 'appointment_no_longer_active' where id = r.id; continue;
    end if;
    if b.suspended_at is not null or b.cancelled_at is not null or c.id is null or coalesce(c.do_not_contact, false) or (public.zella_digits(c.phone) is null and nullif(trim(coalesce(c.email, '')), '') is null) then
      update public.appointment_reminders set status = 'skipped', error = 'cannot_contact' where id = r.id; continue;
    end if;
    select s.name into v_staff from public.staff_members s where s.id = a.staff_id;
    update public.appointment_reminders set status = 'sending', attempts = attempts + 1 where id = r.id;
    v_res := v_res || jsonb_build_array(jsonb_build_object('reminder_id', r.id, 'kind', r.kind, 'channel', r.channel, 'reason', r.reason, 'hours_before', r.hours_before,
      'business', jsonb_build_object('id', b.id, 'name', b.name, 'timezone', b.tz),
      'customer', jsonb_build_object('id', c.id, 'first_name', c.first_name, 'phone', c.phone, 'email', c.email, 'preferred_contact', to_jsonb(c) ->> 'preferred_contact'),
      'appointment', jsonb_build_object('id', a.id, 'title', a.title, 'start_time', a.start_time, 'end_time', a.end_time, 'staff', v_staff)));
  end loop;
  return v_res;
end $$;
create or replace function public.zella_complete_reminder(p_reminder_id uuid, p_ok boolean, p_error text default null) returns text
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  select * into r from public.appointment_reminders where id = p_reminder_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if r.status <> 'sending' then return r.status; end if;
  if p_ok then update public.appointment_reminders set status = 'sent', sent_at = now(), error = null where id = p_reminder_id; return 'sent'; end if;
  if r.attempts < 2 then
    update public.appointment_reminders set status = 'pending', due_at = now() + interval '10 minutes', error = left(p_error, 300) where id = p_reminder_id; return 'retry';
  end if;
  update public.appointment_reminders set status = 'failed', error = left(p_error, 300) where id = p_reminder_id;
  perform public.zella_notify(r.business_id, 'reminder_failed', 'A customer message was not delivered', 'A ' || r.kind || ' could not be sent. Contact them another way.', 'warning', 'calendar', r.appointment_id);
  return 'failed';
end $$;
-- The customer answered a reminder.
create or replace function public.zella_reminder_response(p_appointment_id uuid, p_response text, p_note text default null) returns text
language plpgsql security definer set search_path = public as $$
declare a record;
begin
  select * into a from public.appointments where id = p_appointment_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if p_response = 'confirm' then
    update public.appointments set status = 'confirmed', updated_at = now() where id = p_appointment_id and status = 'scheduled'; return 'confirmed';
  elsif p_response = 'cancel' then
    update public.appointments set status = 'cancelled', cancel_reason = coalesce(nullif(p_note, ''), 'Customer cancelled'), updated_at = now() where id = p_appointment_id and status in ('scheduled', 'confirmed'); return 'cancelled';
  elsif p_response = 'reschedule' then
    perform public.zella_create_callback(a.business_id, null, 'appointment_request', 'normal', coalesce(nullif(p_note, ''), 'Customer asked to reschedule.'), null, a.customer_id, null, a.id, 'ai'); return 'reschedule_requested';
  end if;
  return 'no_change';
end $$;
revoke all on function public.zella_claim_reminders(integer) from public, anon, authenticated;
revoke all on function public.zella_complete_reminder(uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.zella_reminder_response(uuid, text, text) from public, anon, authenticated;
grant execute on function public.zella_claim_reminders(integer) to service_role;
grant execute on function public.zella_complete_reminder(uuid, boolean, text) to service_role;
grant execute on function public.zella_reminder_response(uuid, text, text) to service_role;

-- ---- safe booking: a booking is confirmed only after the schedule accepts it ----------
create or replace function public.zella_book_appointment(
  p_business_id uuid, p_customer_id uuid, p_title text, p_start timestamptz, p_duration_minutes integer default 30,
  p_staff_id uuid default null, p_party_size integer default null, p_notes text default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_slot record; v_tz text; v_id uuid;
begin
  if auth.uid() is not null and not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  if p_customer_id is not null and not exists (select 1 from public.customers where id = p_customer_id and business_id = p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  if extract(minute from p_start)::int % 5 <> 0 then raise exception 'BAD_TIME'; end if;
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id and b.suspended_at is null and b.cancelled_at is null;
  if v_tz is null then raise exception 'BUSINESS_NOT_AVAILABLE'; end if;
  select * into v_slot from public.zella_available_slots(p_business_id, p_start, p_start, p_duration_minutes, p_staff_id, 5, 1, null) limit 1;
  if v_slot.slot_start is null or v_slot.slot_start <> p_start then raise exception 'SLOT_TAKEN'; end if;
  insert into public.appointments (business_id, customer_id, title, start_time, end_time, timezone, status, staff_id, party_size, description, booking_state)
  values (p_business_id, p_customer_id, coalesce(nullif(trim(p_title), ''), 'Appointment'), v_slot.slot_start, v_slot.slot_end, v_tz, 'scheduled', v_slot.staff_id, p_party_size, p_notes, 'confirmed')
  returning id into v_id;
  if p_customer_id is not null then perform public.zella_stop_callbacks_for(p_business_id, p_customer_id, null, 'booked'); end if;
  return v_id;
end $$;

-- The AI could not verify a slot: record a REQUEST (never a booking) and ask staff to finish it.
create or replace function public.zella_request_appointment(
  p_business_id uuid, p_customer_id uuid, p_phone text, p_title text, p_preferred_start timestamptz default null, p_notes text default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_tz text; v_id uuid; v_start timestamptz := coalesce(p_preferred_start, now() + interval '1 day');
begin
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id and b.suspended_at is null and b.cancelled_at is null;
  if v_tz is null then raise exception 'BUSINESS_NOT_AVAILABLE'; end if;
  insert into public.appointments (business_id, customer_id, title, start_time, end_time, timezone, status, description, booking_state)
  values (p_business_id, p_customer_id, coalesce(nullif(trim(p_title), ''), 'Appointment request'), v_start, v_start + interval '30 minutes', v_tz, 'scheduled', p_notes, 'requested')
  returning id into v_id;
  perform public.zella_create_callback(p_business_id, p_phone, 'appointment_request', 'normal',
    'Appointment request: ' || coalesce(p_title, 'a visit') || coalesce('. ' || p_notes, '') || '. Not booked yet.', p_preferred_start, p_customer_id, null, v_id, 'ai');
  return v_id;
end $$;

-- Staff finish a request: check the schedule, then confirm it.
create or replace function public.zella_confirm_requested_appointment(p_appointment_id uuid, p_start timestamptz, p_duration_minutes integer default 30, p_staff_id uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare a record; v_slot record;
begin
  select * into a from public.appointments where id = p_appointment_id for update;
  if not found or not public.zella_is_member(a.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if a.booking_state = 'confirmed' then raise exception 'ALREADY_CONFIRMED'; end if;
  if extract(minute from p_start)::int % 5 <> 0 then raise exception 'BAD_TIME'; end if;
  select * into v_slot from public.zella_available_slots(a.business_id, p_start, p_start, p_duration_minutes, p_staff_id, 5, 1, p_appointment_id) limit 1;
  if v_slot.slot_start is null or v_slot.slot_start <> p_start then raise exception 'SLOT_TAKEN'; end if;
  update public.appointments set start_time = v_slot.slot_start, end_time = v_slot.slot_end, staff_id = v_slot.staff_id, booking_state = 'confirmed', hold_expires_at = null, updated_at = now() where id = p_appointment_id;
  update public.callbacks set status = 'completed', outcome = 'booked', completed_at = now(), auto_call = false, updated_at = now()
   where appointment_id = p_appointment_id and reason = 'appointment_request' and status not in ('completed', 'cancelled');
  return p_appointment_id;
end $$;

-- Reschedule: moves the SAME appointment after the schedule accepts the new time.
create or replace function public.zella_reschedule_appointment(p_appointment_id uuid, p_start timestamptz, p_staff_id uuid default null, p_requested_by text default 'customer')
returns jsonb language plpgsql security definer set search_path = public as $$
declare a record; v_dur integer; v_slot record;
begin
  select * into a from public.appointments where id = p_appointment_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if auth.uid() is not null and not public.zella_is_member(a.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if a.status in ('cancelled', 'completed') then raise exception 'NOT_RESCHEDULABLE'; end if;
  if extract(minute from p_start)::int % 5 <> 0 then raise exception 'BAD_TIME'; end if;
  v_dur := greatest(5, (extract(epoch from (a.end_time - a.start_time)) / 60)::int);
  select * into v_slot from public.zella_available_slots(a.business_id, p_start, p_start, v_dur, coalesce(p_staff_id, a.staff_id), 5, 1, p_appointment_id) limit 1;
  if v_slot.slot_start is null or v_slot.slot_start <> p_start then raise exception 'SLOT_TAKEN'; end if;
  update public.appointments set start_time = v_slot.slot_start, end_time = v_slot.slot_end, staff_id = coalesce(v_slot.staff_id, staff_id),
         status = case when status in ('no_show') then 'scheduled' else status end,
         reschedule_requested_by = case when p_requested_by in ('customer', 'staff', 'ai') then p_requested_by else 'staff' end, updated_at = now()
   where id = p_appointment_id;
  return jsonb_build_object('appointment_id', p_appointment_id, 'original_start', a.start_time, 'new_start', v_slot.slot_start);
end $$;

-- tentative holds that were never confirmed
create or replace function public.zella_expire_holds() returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  update public.appointments set status = 'cancelled', cancel_reason = 'Hold expired', updated_at = now()
   where booking_state = 'tentative' and hold_expires_at < now() and status in ('scheduled', 'confirmed');
  get diagnostics n = row_count; return n;
end $$;
create or replace function public.zella_hold_slot(p_business_id uuid, p_customer_id uuid, p_title text, p_start timestamptz, p_duration_minutes integer default 30, p_staff_id uuid default null, p_hold_minutes integer default 15)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_slot record; v_tz text; v_id uuid;
begin
  if extract(minute from p_start)::int % 5 <> 0 then raise exception 'BAD_TIME'; end if;
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id and b.suspended_at is null and b.cancelled_at is null;
  if v_tz is null then raise exception 'BUSINESS_NOT_AVAILABLE'; end if;
  select * into v_slot from public.zella_available_slots(p_business_id, p_start, p_start, p_duration_minutes, p_staff_id, 5, 1, null) limit 1;
  if v_slot.slot_start is null or v_slot.slot_start <> p_start then raise exception 'SLOT_TAKEN'; end if;
  insert into public.appointments (business_id, customer_id, title, start_time, end_time, timezone, status, staff_id, booking_state, hold_expires_at)
  values (p_business_id, p_customer_id, coalesce(nullif(trim(p_title), ''), 'Appointment'), v_slot.slot_start, v_slot.slot_end, v_tz, 'scheduled', v_slot.staff_id, 'tentative', now() + make_interval(mins => greatest(5, p_hold_minutes)))
  returning id into v_id;
  return v_id;
end $$;
-- the customer said yes to a held slot
create or replace function public.zella_confirm_hold(p_appointment_id uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare a record;
begin
  select * into a from public.appointments where id = p_appointment_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if auth.uid() is not null and not public.zella_is_member(a.business_id) then raise exception 'NOT_ALLOWED'; end if;
  if a.booking_state <> 'tentative' or a.status <> 'scheduled' or a.hold_expires_at < now() then raise exception 'HOLD_EXPIRED'; end if;
  update public.appointments set booking_state = 'confirmed', hold_expires_at = null, updated_at = now() where id = p_appointment_id;
  return p_appointment_id;
end $$;
revoke all on function public.zella_book_appointment(uuid, uuid, text, timestamptz, integer, uuid, integer, text) from public, anon;
revoke all on function public.zella_request_appointment(uuid, uuid, text, text, timestamptz, text) from public, anon, authenticated;
revoke all on function public.zella_confirm_requested_appointment(uuid, timestamptz, integer, uuid) from public, anon;
revoke all on function public.zella_reschedule_appointment(uuid, timestamptz, uuid, text) from public, anon;
revoke all on function public.zella_expire_holds() from public, anon, authenticated;
revoke all on function public.zella_hold_slot(uuid, uuid, text, timestamptz, integer, uuid, integer) from public, anon, authenticated;
revoke all on function public.zella_confirm_hold(uuid) from public, anon;
grant execute on function public.zella_book_appointment(uuid, uuid, text, timestamptz, integer, uuid, integer, text) to authenticated, service_role;
grant execute on function public.zella_request_appointment(uuid, uuid, text, text, timestamptz, text) to service_role;
grant execute on function public.zella_confirm_requested_appointment(uuid, timestamptz, integer, uuid) to authenticated, service_role;
grant execute on function public.zella_reschedule_appointment(uuid, timestamptz, uuid, text) to authenticated, service_role;
grant execute on function public.zella_expire_holds() to service_role;
grant execute on function public.zella_hold_slot(uuid, uuid, text, timestamptz, integer, uuid, integer) to service_role;
grant execute on function public.zella_confirm_hold(uuid) to authenticated, service_role;

-- ---- waitlist ------------------------------------------------------------------------------
create or replace function public.zella_join_waitlist(p_business_id uuid, p_customer_id uuid, p_title text default null, p_duration_minutes integer default 30,
  p_earliest timestamptz default null, p_latest timestamptz default null, p_staff_id uuid default null, p_notes text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is not null and not public.zella_is_member(p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  if not exists (select 1 from public.customers where id = p_customer_id and business_id = p_business_id) then raise exception 'NOT_ALLOWED'; end if;
  insert into public.waitlist_entries (business_id, customer_id, title, duration_minutes, earliest_at, latest_at, staff_id, notes)
  values (p_business_id, p_customer_id, nullif(trim(p_title), ''), greatest(5, coalesce(p_duration_minutes, 30)), p_earliest, p_latest, p_staff_id, left(p_notes, 500))
  on conflict (business_id, customer_id, coalesce(title, '')) where status in ('waiting', 'offered') do update set earliest_at = excluded.earliest_at, latest_at = excluded.latest_at, notes = excluded.notes
  returning id into v_id;
  return v_id;
end $$;
create or replace function public.zella_remove_waitlist_entry(p_id uuid) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_b uuid;
begin
  select business_id into v_b from public.waitlist_entries where id = p_id;
  if v_b is null or not public.zella_is_member(v_b) then raise exception 'NOT_ALLOWED'; end if;
  update public.waitlist_entries set status = 'removed' where id = p_id and status in ('waiting', 'offered');
  return found;
end $$;
-- The customer said yes: re-check the slot, then book. A taken slot is never double-booked.
create or replace function public.zella_accept_waitlist_offer(p_entry_id uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare e record; v_id uuid;
begin
  select * into e from public.waitlist_entries where id = p_entry_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if e.status <> 'offered' or e.offer_expires_at < now() then raise exception 'OFFER_EXPIRED'; end if;
  begin
    v_id := public.zella_book_appointment(e.business_id, e.customer_id, coalesce(e.title, 'Appointment'), e.offered_start, e.duration_minutes, e.offered_staff_id, null, e.notes);
  exception when others then
    if sqlerrm = 'SLOT_TAKEN' then
      update public.waitlist_entries set status = 'waiting', offered_start = null, offered_end = null, offer_expires_at = null where id = p_entry_id;
    end if;
    raise;
  end;
  update public.waitlist_entries set status = 'booked', appointment_id = v_id where id = p_entry_id;
  return v_id;
end $$;
create or replace function public.zella_decline_waitlist_offer(p_entry_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare e record;
begin
  select * into e from public.waitlist_entries where id = p_entry_id for update;
  if not found or e.status <> 'offered' then return; end if;
  update public.waitlist_entries set status = 'waiting', offered_start = null, offered_end = null, offer_expires_at = null where id = p_entry_id;
  perform public.zella_offer_slot(e.business_id, e.offered_start, e.offered_end, e.offered_staff_id, e.customer_id);
end $$;
-- offers nobody answered go to the next person
create or replace function public.zella_expire_waitlist_offers() returns integer
language plpgsql security definer set search_path = public as $$
declare e record; n integer := 0;
begin
  for e in select * from public.waitlist_entries where status = 'offered' and offer_expires_at < now() for update skip locked loop
    update public.waitlist_entries set status = 'waiting', offered_start = null, offered_end = null, offer_expires_at = null where id = e.id;
    perform public.zella_offer_slot(e.business_id, e.offered_start, e.offered_end, e.offered_staff_id, e.customer_id);
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.zella_join_waitlist(uuid, uuid, text, integer, timestamptz, timestamptz, uuid, text) from public, anon;
revoke all on function public.zella_remove_waitlist_entry(uuid) from public, anon;
revoke all on function public.zella_accept_waitlist_offer(uuid) from public, anon, authenticated;
revoke all on function public.zella_decline_waitlist_offer(uuid) from public, anon, authenticated;
revoke all on function public.zella_expire_waitlist_offers() from public, anon, authenticated;
grant execute on function public.zella_join_waitlist(uuid, uuid, text, integer, timestamptz, timestamptz, uuid, text) to authenticated, service_role;
grant execute on function public.zella_remove_waitlist_entry(uuid) to authenticated, service_role;
grant execute on function public.zella_accept_waitlist_offer(uuid) to service_role;
grant execute on function public.zella_decline_waitlist_offer(uuid) to service_role;
grant execute on function public.zella_expire_waitlist_offers() to service_role;

-- ---- staff or resource unavailable -------------------------------------------------------------
create or replace function public.zella_handle_staff_unavailable(p_business_id uuid, p_staff_id uuid, p_from timestamptz, p_to timestamptz, p_reason text default null)
returns integer language plpgsql security definer set search_path = public as $$
declare a record; v_alt text; v_n integer := 0; v_auto record; v_tz text; v_who text; v_staff_name text;
begin
  select coalesce(b.timezone, 'America/New_York') into v_tz from public.businesses b where b.id = p_business_id;
  select name into v_staff_name from public.staff_members where id = p_staff_id;
  select x.* into v_auto from public.automations x where x.business_id = p_business_id and x.trigger_type = 'staff_unavailable' and x.status = 'active' limit 1;
  for a in select * from public.appointments ap
            where ap.business_id = p_business_id and ap.status in ('scheduled', 'confirmed') and coalesce(ap.booking_state, 'confirmed') = 'confirmed'
              and ap.start_time > now() and ap.start_time < p_to and ap.end_time > p_from
              and (p_staff_id is null or ap.staff_id = p_staff_id) and ap.conflict_note is null loop
    select string_agg(to_char(s.slot_start at time zone v_tz, 'Dy Mon DD HH12:MI AM') || coalesce(' with ' || s.staff_name, ''), '; ' order by s.slot_start) into v_alt
      from public.zella_available_slots(p_business_id, greatest(now(), p_from), greatest(now(), p_from) + interval '7 days',
             greatest(5, (extract(epoch from (a.end_time - a.start_time)) / 60)::int), null, 30, 3, a.id) s
     where s.slot_start >= p_to or s.slot_start + (a.end_time - a.start_time) <= p_from;
    select coalesce(nullif(trim(coalesce(c.first_name,'') || ' ' || coalesce(c.last_name,'')), ''), a.title) into v_who from public.customers c where c.id = a.customer_id;
    v_who := coalesce(v_who, a.title);
    update public.appointments set conflict_note = left(coalesce(v_staff_name, 'The team') || ' is unavailable' || coalesce(' (' || p_reason || ')', '') || '.', 200) where id = a.id;
    perform public.zella_create_task(p_business_id, a.customer_id, 'staff_unavailable', 'Reschedule ' || v_who || ': ' || coalesce(v_staff_name, 'staff') || ' is unavailable',
      'Appointment ' || to_char(a.start_time at time zone v_tz, 'Dy Mon DD HH12:MI AM') || '. ' || case when v_alt is null then 'No alternative found yet.' else 'Possible times: ' || v_alt || '.' end,
      'high', a.start_time - interval '1 day', null, 'automation', a.id);
    -- ask the customer only when the business enabled it; never move them without their confirmation
    if v_auto.id is not null and a.customer_id is not null and exists (select 1 from public.customers c where c.id = a.customer_id and not coalesce(c.do_not_contact, false) and public.zella_digits(c.phone) is not null) then
      insert into public.followup_tasks (business_id, customer_id, appointment_id, kind, channel, due_at, max_attempts)
      values (p_business_id, a.customer_id, a.id, 'reschedule_offer', case when v_auto.trigger_config ->> 'channel' = 'sms' then 'sms' else 'call' end, public.zella_next_call_time(now(), v_tz), 2) on conflict do nothing;
    end if;
    v_n := v_n + 1;
  end loop;
  if v_n > 0 then
    perform public.zella_notify(p_business_id, 'staff_unavailable', v_n || (case when v_n = 1 then ' appointment is' else ' appointments are' end) || ' affected',
      coalesce(v_staff_name, 'Someone') || ' is unavailable. Review the tasks to rebook them.', 'warning', 'tasks', null);
  end if;
  return v_n;
end $$;
revoke all on function public.zella_handle_staff_unavailable(uuid, uuid, timestamptz, timestamptz, text) from public, anon, authenticated;
grant execute on function public.zella_handle_staff_unavailable(uuid, uuid, timestamptz, timestamptz, text) to service_role;

create or replace function public.zella_block_trigger() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.zella_handle_staff_unavailable(new.business_id, new.staff_id, new.start_time, new.end_time, nullif(new.reason, ''));
  return new;
end $$;
drop trigger if exists zella_block_trg on public.blocked_times;
create trigger zella_block_trg after insert or update of start_time, end_time, staff_id on public.blocked_times for each row execute function public.zella_block_trigger();

create or replace function public.zella_staff_deactivated() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.is_active and not new.is_active then
    perform public.zella_handle_staff_unavailable(new.business_id, new.id, now(), now() + interval '365 days', 'no longer available');
  end if;
  return new;
end $$;
drop trigger if exists zella_staff_deactivated_trg on public.staff_members;
create trigger zella_staff_deactivated_trg after update of is_active on public.staff_members for each row execute function public.zella_staff_deactivated();
