# ZELLA AI — MASTER ADMIN DASHBOARD & PLATFORM FLOW
## Google Stitch UI/UX Design Specification

### 1. PROJECT OVERVIEW

Design a complete, premium, responsive SaaS web application for **Zella AI**, an AI-powered business receptionist and customer relationship management platform for small and medium-sized businesses in the United States.

Zella AI helps businesses manage customer enquiries, AI-powered phone calls, leads, appointments, follow-ups, messages, team members, and business operations from one unified workspace.

This is not a basic CRM template, a generic analytics dashboard, or a chatbot landing page. It is a multi-tenant SaaS platform with two distinct experiences:

1. **Zella Owner Admin Portal:** Used by the Zella platform owner and authorized platform administrators to create businesses, provision their workspaces, configure products and modules, manage subscriptions, monitor usage and health, and support business customers.
2. **Business Workspace:** Used by each business owner and their employees to operate their CRM, manage customers, appointments, calls, AI receptionist, automations, and integrations.

The platform owner creates and configures a workspace for each business. Each business gets its own isolated data, CRM, AI receptionist configuration, users, integrations, and settings.

**Core principle:** One Zella platform, multiple business workspaces, one configurable CRM architecture, and industry-specific experiences.

---

### 2. VISUAL THEME: OAT & SLATE SAAS BEIGE

Use this one theme everywhere in Zella: the Owner Admin portal, every business CRM workspace, sign-in pages and emails' landing pages.

#### Color tokens

- Canvas background: `#FDF6ED`
- Surfaces (cards, modals, tables): `#FFFFFF`; subdued `#F4EFE6`; alternate `#F8F5EE`
- Borders: subtle `#E6DEC8`, strong `#D4CBB6`
- Text: primary `#221F1E`, secondary `#57534E`, muted `#78716C`, inverse `#FFFFFF`
- Primary (buttons, links, active navigation, focus): `#2563EB`, hover `#1D4ED8`, subtle background `#EFF6FF`
- Status: success `#15803D` on `#DCFCE7`; warning `#D97706` on `#FEF3C7`; danger `#DC2626` on `#FEE2E2`; info `#0284C7` on `#E0F2FE`

#### Shape, type and depth

- Font: Inter (fallback -apple-system, BlinkMacSystemFont, sans-serif); tabular figures for numbers.
- Radius: 6px small controls, 10px inputs and buttons, 12px cards, 14px large panels, full pills for badges.
- Card shadow: `0 1px 3px 0 rgba(34, 31, 30, 0.04), 0 1px 2px -1px rgba(34, 31, 30, 0.03)`. Prefer borders over heavy shadows.

#### Design rules

- Clean left sidebar with icons and readable labels; the active item uses the blue subtle background with blue text.
- White cards on the beige canvas, separated by subtle borders.
- Compact, readable tables with filters, search, pagination and row actions.
- Polished loading, empty, error, confirmation and success states.
- Desktop, tablet and mobile layouts.

Do not use other color schemes (no sage, indigo or purple themes), bright gradients, heavy glassmorphism or cartoon illustrations.

---

### 3. USER ROLES AND PERMISSIONS

Create the following role-based experiences.

**A. Platform Owner / Super Admin**

Has authorized access to platform-wide management:

- View platform overview and business statistics.
- Create, provision, edit, suspend, and deactivate business workspaces.
- Configure industry templates and available modules.
- Manage subscription plans and billing records.
- View platform-level calls, errors, provisioning status, and system health.
- Manage authorized platform administrators.
- Send invitations and manage onboarding.
- Access support tools and audit logs.
- Open a business workspace through a clearly labeled, permission-controlled support action.

**B. Platform Support Administrator**

Can access assigned business-management and support functions according to permissions. Cannot automatically change billing, security, or platform-owner settings.

**C. Business Owner**

Can access only their own business workspace:

- CRM and customer records.
- Leads, appointments, calls, SMS and email records.
- AI receptionist configuration.
- Staff and team management.
- Automations and integrations.
- Business settings and subscription information.

**D. Business Staff**

Can access only the features and records allowed by their assigned role.

Implement role-aware UI states. Do not show platform-wide data to business users.

---

### 4. OWNER ADMIN DASHBOARD — HOME

Create the primary Owner Admin dashboard.

#### Sidebar navigation

Use a persistent left sidebar with the Zella AI logo and these sections:

**Overview**
- Dashboard

**Business Operations**
- Businesses
- Onboarding
- Industry Templates
- Modules

**Platform Management**
- Platform Users
- Plans & Subscriptions
- Billing & Payments

**Communication & AI**
- Calls
- SMS & Messages
- AI Agents
- Automations

**Platform Services**
- Integrations
- Notifications
- Support Tickets
- Audit Logs

**System**
- Platform Settings
- Profile
- Logout

Use grouped sidebar sections, subtle dividers, active-page highlighting, and collapsible navigation where appropriate.

The sidebar should remain consistent across all Owner Admin pages.

#### Dashboard header

Include:
- Page title: Dashboard.
- Welcome message.
- Global search.
- Notification icon.
- Admin profile menu.
- Date range selector where applicable.
- Refresh action.

#### Overview metrics

Create cards for:
- Total Businesses.
- Active Workspaces.
- Pending Invitations.
- Businesses Requiring Attention.
- Active Subscriptions.
- Total Calls.
- Appointments Created.
- AI Receptionist Activity.

Metrics must be data-driven in the final implementation. Use clearly labeled illustrative placeholders only in the Stitch design preview.

#### Main dashboard content

Include:
- Business growth chart.
- Business onboarding funnel.
- Subscription status breakdown.
- Recent business registrations.
- Recent provisioning failures.
- AI receptionist activity summary.
- Latest platform events.
- Quick actions: Create Business, Invite Admin, View Subscriptions, Review Issues.

Each card or row should have an appropriate navigation action. Charts should have sensible labels, tooltips, and empty states.

---

### 5. BUSINESSES — CENTRAL MANAGEMENT MODULE

The Businesses module is one of the most important parts of the platform.

The Zella owner must be able to create a new business and provision its dedicated workspace.

#### Businesses listing page

Create a professional table containing:

- Business name.
- Business ID.
- Industry.
- Business email.
- Phone number.
- Workspace status.
- Onboarding progress.
- AI receptionist status.
- Subscription plan.
- Assigned owner.
- Created date.
- Actions.

Include:
- Search by business name, email, phone, or business ID.
- Filters for industry, status, plan, onboarding stage, and AI status.
- Sorting and pagination.
- Refresh button.
- Export action where permitted.
- Create Business button.
- Empty state with a Create Business CTA.
- Loading skeletons and error recovery.

Possible workspace statuses:
- Draft.
- Provisioning.
- Setup Required.
- Active.
- Suspended.
- Deactivated.
- Provisioning Failed.

Do not confuse workspace status with subscription status or AI activation status. They are separate concepts.

#### Business row actions

Provide:
- View Details.
- Edit Business.
- Continue Setup.
- Open Workspace.
- Manage Subscription.
- View Activity.
- Retry Failed Provisioning.
- Suspend or Deactivate, subject to confirmation and permissions.

Every action must open a real designed destination, modal, or workflow in the prototype.

---

### 6. CREATE BUSINESS — COMPLETE MULTI-STEP WIZARD

Clicking **Create Business** opens a multi-step wizard. Do not use one long, crowded form.

Display a stepper across the top and a persistent summary panel when space allows.

#### Step 1: Business Information

Fields:
- Legal business name.
- Display name.
- Industry.
- Business type.
- Business email.
- Business phone.
- Website.
- Country.
- Street address.
- City.
- State.
- ZIP/postal code.
- Time zone.
- Preferred language.

Default the target market to the United States while allowing supported locations to be configured.

Industry choices come from the platform's configured industries list, not a hardcoded list. The current configured industries are: Automotive, Beauty & Salon, Dental, E-commerce, Education, Electrical, Financial Services, Fitness, Healthcare, Home Services, Hospitality, HVAC, Legal, Plumbing, Professional Services, Real Estate, Restaurant, Travel, and Other.

Use searchable dropdowns for long option lists.

Validate required fields and provide clear inline error messages.

#### Step 2: Business Owner and Access

Fields:
- Owner's full name.
- Owner's email.
- Owner's phone.
- Initial workspace role.
- Invitation method.

Allow the administrator to create an invitation and send it through the configured invitation system.

Show invitation status:
- Not Sent.
- Pending.
- Accepted.
- Expired.
- Failed.

Never display or invent a user's password. Do not imply that a real invitation was sent unless the backend confirms success.

#### Step 3: Industry Template

Select an industry configuration.

Explain that the selected template determines the default:
- CRM terminology.
- Customer record fields.
- Appointment or job workflows.
- Default statuses.
- Available modules.
- AI receptionist starting configuration.
- Automation templates.

Show a live preview of the selected industry's workspace.

Examples:

Dental:
- Patients.
- Providers.
- Appointments.
- Treatments.

Plumbing:
- Customers.
- Technicians.
- Service Jobs.
- Service Appointments.

Salon:
- Clients.
- Stylists.
- Services.
- Bookings.

Real Estate:
- Leads.
- Clients.
- Properties.
- Viewings.

Restaurant:
- Guests.
- Reservations.
- Orders or enquiries.
- Service staff.

These are examples of configurable terminology, not separate applications.

#### Step 4: Select Modules

Show available modules as selectable cards with descriptions.

Core modules:
- Dashboard.
- CRM / Customers.
- Leads.
- Appointments or Jobs.
- Calls.
- SMS and Messages.
- AI Receptionist.
- Calendar.
- Automations.
- Integrations.
- Team Management.
- Reports.
- Billing and Settings.

Allow the owner to select which modules the business receives, subject to its plan and permissions.

Show:
- Included modules.
- Optional modules.
- Modules unavailable on the selected plan.
- Required dependencies.

Do not allow users to enable unsupported modules simply by clicking a UI control.

#### Step 5: AI Receptionist Setup

Allow the administrator to initialize the AI receptionist configuration for this specific business.

Fields and sections:
- AI receptionist name.
- Business description.
- Services offered.
- Business hours.
- Service area.
- FAQs.
- Pricing information, if provided.
- Booking rules.
- Escalation contact.
- Call transfer preferences.
- Languages.
- Voice selection.
- Greeting.
- Tone and personality.
- Information the AI must never invent.
- Questions the AI should ask.
- Situations requiring human assistance.

The configuration must belong to the selected business. Different businesses must never share customer-specific instructions or knowledge unintentionally.

Allow the admin to save a draft and continue AI setup later.

#### Step 6: Subscription

Display:
- Selected plan (from plan configuration).
- Billing frequency.
- Trial or activation terms, if configured.
- Payment status.
- Subscription status.

Pricing has not been decided. Do not show any prices, fees, dollar amounts or pricing tiers anywhere in the design. Plans, amounts and terms will come from plan configuration later; where an amount would appear, show "Pricing not configured".

This step may be skipped during provisioning and completed later.

Do not charge a customer automatically during a visual preview.

#### Step 7: Review and Provision

Show a final review containing:
- Business information.
- Owner invitation.
- Industry template.
- Enabled modules.
- AI setup status.
- Subscription status.

Primary button: **Create Business Workspace**.

Secondary actions:
- Save as Draft.
- Go Back.
- Cancel.

On confirmation, show a progress screen with the actual provisioning stages:

1. Validating business information.
2. Creating the workspace.
3. Applying industry configuration.
4. Enabling selected modules.
5. Preparing CRM configuration.
6. Initializing AI receptionist settings.
7. Preparing owner invitation.
8. Finalizing workspace status.

Display each stage as pending, in progress, completed, or failed based on actual server responses.

Do not show a successful workspace as Active if required provisioning has failed.

#### Step 8: Business Created

Show a confirmation screen with:
- Business name.
- Business ID.
- Workspace status.
- Selected industry.
- Enabled modules.
- Owner invitation status.
- AI receptionist setup status.
- Subscription status.

Actions:
- Open Business Details.
- Continue AI Setup.
- Retry Failed Steps.
- Return to Businesses.

A newly created workspace should be isolated and free of unrelated sample records.

---

### 7. BUSINESS DETAILS — OWNER ADMIN VIEW

Clicking a business opens a dedicated business detail page.

Create a header with the business name, industry, workspace status, and contextual actions.

Use tabs:

**Overview**
- Workspace summary.
- Onboarding progress.
- Enabled modules.
- Recent activity.
- Important warnings.

**Configuration**
- Business details.
- Industry template.
- Terminology.
- CRM fields.
- Module settings.

**Users & Invitations**
- Owner and staff.
- Roles.
- Invitation history.
- Access status.

**CRM**
- Customer and lead counts.
- Appointments or jobs.
- CRM configuration status.
- Workspace-level record links.

**AI Receptionist**
- Configuration status.
- Knowledge base status.
- Voice provider status.
- Phone number connection status.
- Activation state.
- Recent calls and errors.

**Integrations**
- Connected services.
- Connection health.
- Required permissions.
- Reconnection actions.

**Subscription**
- Plan.
- Billing state.
- Payment history.
- Renewal information.
- Change-plan and cancellation actions.

**Activity & Audit**
- Who performed an action.
- What changed.
- When it changed.
- Result and relevant event details.

All business-specific information must be scoped to the selected workspace.

---

### 8. BUSINESS WORKSPACE — THE ACTUAL CUSTOMER PRODUCT

Design the separate experience that a business owner or staff member sees after signing in.

This is the CRM that Zella provides to each business.

It must not look like the platform Owner Admin portal. Use the same Oat & Slate design language, but show only the business's own operations.

#### Business sidebar

- Today.
- Leads.
- Customers or industry-specific equivalent.
- Calls.
- Messages.
- Calendar.
- Jobs or Appointments.
- Automations.
- Integrations.
- AI Receptionist.
- Reports.
- Team.
- Settings.

Menu items must be configurable according to enabled modules and role permissions.

#### Business Today dashboard

Display:
- New leads.
- Upcoming appointments or jobs.
- Missed calls.
- AI-handled calls.
- Calls requiring human follow-up.
- Recent customer activity.
- Today's schedule.
- Tasks and reminders.
- Conversion and response summaries.

Every card must navigate to the relevant record or list.

Do not use fake numbers as real production metrics.

#### CRM

Create a complete CRM with:
- Searchable customer list.
- Lead pipeline.
- Customer detail pages.
- Contact information.
- Interaction history.
- Call and message history.
- Notes and tasks.
- Appointment or job history.
- Follow-up reminders.
- Record assignment.
- Customizable fields.
- Status management.

Provide create, view, edit, search, filter, and archive workflows according to permissions.

Industry-specific terminology must update consistently across the sidebar, page titles, buttons, forms, filters, detail pages, and empty states.

#### Appointments and Jobs

Support configurable scheduling workflows.

For appointment-based industries:
- Calendar views.
- Appointment creation.
- Staff assignment.
- Customer selection.
- Appointment status.
- Reschedule and cancellation.
- Reminder configuration.
- Attendance tracking.

For service businesses:
- Service jobs.
- Technician assignment.
- Service location.
- Job status.
- Scheduling.
- Completion notes.

Do not force all industries into the same business vocabulary.

#### Calls and Messages

Show:
- Caller or customer.
- Phone number.
- Date and time.
- Call direction.
- Duration.
- AI or human handling status.
- Outcome.
- Follow-up requirement.
- Recording or transcript availability, where legally permitted and configured.

Include call detail pages with transcripts and summaries only when actual data exists and access is authorized.

Include SMS and email history where those integrations are enabled.

#### Automations

Allow businesses to configure reusable workflows such as:
- New lead follow-up.
- Appointment reminders.
- Missed-call follow-up.
- Post-appointment messages.
- Unanswered enquiry notifications.
- Lead re-engagement.

Include triggers, conditions, actions, enable/disable controls, execution history, and failure states.

---

### 9. AI RECEPTIONIST — PER-BUSINESS CONFIGURATION

Every business must have its own AI receptionist configuration, knowledge, rules, and activation state.

Create the following setup workflow:

1. Business Profile.
2. Knowledge Base.
3. Personality and Voice.
4. Call Handling Rules.
5. Booking and CRM Actions.
6. Test and Review.
7. Phone Setup.
8. Activate.

#### Knowledge Base

Allow the business to add:
- FAQs.
- Services.
- Business hours.
- Policies.
- Pricing information.
- Service areas.
- Contact information.
- Uploaded documents, if supported.
- Website content, if the integration supports it.

Show indexing and processing status when relevant.

The AI should answer from approved business information and clearly handle questions it cannot answer.

#### Personality and Voice

Configure:
- Voice.
- Tone.
- Greeting.
- Language.
- Speaking style.
- Business-specific instructions.

#### Call Handling Rules

Configure:
- Which enquiries the AI can handle.
- Which information to collect.
- How to capture leads.
- How to request appointments.
- When to transfer a call.
- Emergency or urgent escalation rules appropriate to the business.
- When to notify staff.
- What the AI must not promise or invent.

#### Testing

Provide a test conversation interface with:
- Customer question.
- AI response.
- Detected intent.
- Information collected.
- Proposed CRM action.
- Escalation decision.

Clearly label simulated tests as simulations. Never present simulated calls as real customer interactions.

#### Activation

The AI receptionist can be marked Active only when all required setup and telephony checks are confirmed by the backend.

---

### 10. TELEPHONY AND INTEGRATIONS

Create a dedicated Phone Setup screen.

Zella's providers are: **Telnyx** for phone numbers, calls and SMS; **Vapi** as the voice AI agent (each business gets its own Vapi assistant built from its AI receptionist configuration); and **n8n** as the automation engine for follow-ups, reminders, check-ins, no-shows, missed-call recovery and lead callbacks.

Support the configured provider's appropriate setup method, such as:
- Connecting an eligible phone number.
- Configuring call forwarding.
- Connecting supported telephony services.
- Configuring call transfer destinations.
- Selecting a voice AI provider.
- Testing incoming and outgoing call handling.

Show connection states:
- Not Connected.
- Setup Required.
- Connecting.
- Connected.
- Error.
- Action Required.

Do not display a connected status before verification succeeds.

Create an Integrations directory for supported services, including:
- Telephony provider.
- Voice AI provider.
- Google Calendar.
- Gmail or other supported email services.
- SMS provider.
- Website lead capture.
- Supported advertising or lead-source integrations.

Each integration should include:
- Description.
- Connection status.
- Connect or Disconnect action.
- Permission status.
- Last successful sync, if available.
- Error details.
- Reconnect action.

Only show features supported by the actual integration. Do not fake OAuth success.

---

### 11. ONBOARDING AND ACTIVATION FLOW

Create a dedicated Onboarding page in Owner Admin.

Show all businesses currently progressing through setup.

Onboarding stages:
1. Business Created.
2. Owner Invited.
3. Owner Access Confirmed.
4. Business Profile Completed.
5. Industry and CRM Configured.
6. AI Knowledge Configured.
7. Phone Connected.
8. Test Completed.
9. Subscription Confirmed.
10. Workspace Activated.

Each stage should show its status, completion date if available, responsible party, and next action.

Allow administrators to:
- Open the business setup.
- Send or resend an invitation.
- Review missing information.
- Retry failed provisioning.
- Resume incomplete configuration.
- View the activation checklist.

Do not block a business from progressing because of optional features that are not required by its plan. Required activation rules must be configurable.

---

### 12. INDUSTRY TEMPLATES AND MODULE MANAGEMENT

Create a configuration-driven system, not separate hardcoded applications for each industry.

#### Industry Templates page

Show a list of templates with:
- Industry name.
- Description.
- Enabled modules.
- Default terminology.
- Default record fields.
- Workflow configuration.
- Status.
- Version.

Provide actions to create, edit, duplicate, publish, and archive templates, subject to permissions.

#### Module Management page

Show reusable platform modules and their availability.

Each module should include:
- Name.
- Description.
- Dependencies.
- Availability by plan.
- Availability by industry.
- Configuration options.
- Activation status.

A business should receive the modules selected for its workspace, subject to plan entitlements.

Changes to a shared template must not silently overwrite existing business-specific settings. Provide a preview and controlled migration or update workflow.

---

### 13. USERS, SUBSCRIPTIONS, BILLING AND SUPPORT

#### Platform Users

Manage authorized platform administrators, their roles, invitations, account status, and permissions.

Business users should be managed within their own business workspace unless the platform owner has a specifically authorized support function.

#### Plans and Subscriptions

Create:
- Plan list.
- Plan details.
- Feature entitlements.
- Business subscriptions.
- Billing history.
- Payment statuses.
- Renewal dates.
- Failed payment alerts.
- Cancellation and suspension workflows.

Keep subscription status separate from workspace status.

Never invent a payment result or imply that a real payment was charged when it was not.

#### Support Tickets

Show:
- Ticket ID.
- Business.
- Issue category.
- Priority.
- Status.
- Assigned support administrator.
- Last updated.

Provide a detailed support view with conversation history, internal notes, relevant business context, and resolution actions.

#### Audit Logs

Record important administrative actions:
- Workspace created or modified.
- User invited.
- Role changed.
- Subscription changed.
- Integration connected or disconnected.
- AI configuration modified.
- Workspace suspended or reactivated.

Display actor, action, target, timestamp, result, and relevant metadata.

---

### 14. PLATFORM SETTINGS

Create settings sections for:
- Platform profile.
- Platform administrators.
- Security and permissions.
- Default onboarding settings.
- Industry configuration.
- Module catalog.
- Plan configuration.
- Notification preferences.
- Integration configuration.
- System status.
- Audit and retention policies.

Sensitive credentials must never be displayed in plain text. Show configuration status and masked values where appropriate.

Administrative actions involving deletion, suspension, billing, or access changes must have confirmation dialogs and appropriate permission checks.

---

### 15. COMPLETE NAVIGATION AND PROTOTYPE FLOW

Build the clickable prototype using this flow:

**Flow A — New Business Provisioning**

Owner Admin Dashboard → Businesses → Create Business → Business Information → Owner Access → Industry Template → Modules → AI Setup → Subscription → Review → Provisioning → Business Created → Business Details.

**Flow B — Business Onboarding**

Onboarding → Select Business → Review Progress → Complete Missing Steps → Configure Knowledge → Test AI → Connect Phone → Verify Requirements → Activate Workspace.

**Flow C — Business Owner Experience**

Invitation → Business Sign-In → Workspace Dashboard → CRM → Customers or Industry-Specific Records → Calendar or Jobs → Calls and Messages → AI Receptionist → Automations → Settings.

**Flow D — Subscription Management**

Owner Admin → Plans & Subscriptions → Select Business → View Subscription → Review Plan → Change Plan or Billing Action → Confirm → Display Actual Result.

**Flow E — Industry Configuration**

Owner Admin → Industry Templates → Select Industry → Edit Terminology → Configure Fields and Workflows → Preview Workspace → Save Draft → Publish → Apply to New Businesses or Offer a Controlled Update to Existing Businesses.

**Flow F — Failed Provisioning**

Create Business → Provisioning Error → View Failed Step → Inspect Error → Retry or Correct Configuration → Verify Completion → Continue Onboarding.

All buttons, sidebar items, tabs, dropdowns, modals, and wizard actions should lead somewhere meaningful in the prototype. Avoid dead-end screens.

---

### 16. TECHNICAL AND DATA ARCHITECTURE REQUIREMENTS

Design the UI to support a real multi-tenant application.

Use the following conceptual data relationships:

- Platform administrators manage the Zella platform.
- Businesses own their workspaces.
- Business memberships associate users with specific businesses and roles.
- Industry configurations define default terminology, fields, statuses, and features.
- Business modules define which modules are enabled for a particular workspace.
- AI agent configurations belong to individual businesses.
- Customers, leads, calls, messages, appointments, automations, and integrations are scoped to their owning business.
- Subscriptions belong to the appropriate business and plan.
- Audit logs track important actions.

Use a reusable configuration model:

**Zella Core + Industry Configuration + Business Configuration + Enabled Modules + AI Configuration.**

For example, the core customer record system remains reusable while a dental workspace displays “Patients” and a plumbing workspace displays “Customers.” The underlying implementation should not require a separate app for every industry.

The existing project uses React, Supabase, and server-side functions, with Telnyx (telephony), Vapi (voice AI) and n8n (automations). The UI should be designed so it can connect to those systems without redesigning the interface.

Security requirements:
- Enforce tenant isolation at the database and server levels.
- Use Supabase Row Level Security where appropriate.
- Validate authorization on the server.
- Do not rely on hidden buttons as a security mechanism.
- Do not expose service-role credentials or API secrets in the frontend.
- Do not bypass existing RLS policies to make a screen work.
- Keep demo data out of production.
- Do not use another business's customer data to populate a new workspace.

Google Stitch creates the visual prototype; actual provisioning, authentication, permissions, integrations, AI calls, and billing must be implemented and verified in the application backend.

---

### 17. REQUIRED DESIGN DELIVERABLES

Generate the complete connected screen set, not just the home dashboard.

At minimum include:

1. Owner Admin Dashboard.
2. Businesses List.
3. Create Business Wizard — every step.
4. Provisioning Progress.
5. Business Created Confirmation.
6. Business Details — every tab.
7. Onboarding Management.
8. Industry Templates.
9. Module Management.
10. Platform Users.
11. Plans and Subscriptions.
12. Billing and Payment History.
13. Calls and Messages.
14. AI Agents Management.
15. AI Receptionist Configuration.
16. Integrations.
17. Automations.
18. Support Tickets.
19. Audit Logs.
20. Platform Settings.
21. Business Sign-In and Invitation Acceptance.
22. Business Workspace Dashboard.
23. CRM Customer and Lead Views.
24. Appointments and Jobs.
25. Calendar.
26. Team Management.
27. Business Settings.
28. Responsive mobile and tablet layouts.
29. Empty, loading, error, confirmation, and success states for the major flows.

Use reusable components and a consistent spacing, typography, color, and interaction system.

If the full scope is too large to generate in one pass, prioritize in this order:

**First:** Owner Admin Dashboard, Businesses List, Create Business Wizard, and Business Details.

**Second:** Onboarding, Industry Templates, Modules, and AI Receptionist Setup.

**Third:** Business Workspace, CRM, Calendar, Calls, and Messages.

**Fourth:** Integrations, Automations, Subscriptions, Billing, Support, and Audit Logs.

Continue using the same theme and design system across every batch.

---

### FINAL INSTRUCTION

Build Zella AI as a premium SaaS management platform where the platform owner can create and configure a business workspace, the system provisions its industry-specific CRM, and the business owner completes onboarding to activate their own AI receptionist and customer operations.

Prioritize clarity, consistency, operational usability, tenant separation, and realistic workflows.

Do not simplify the product into a generic dashboard. Do not create separate hardcoded apps for each industry. Do not populate production workspaces with demo data. Do not invent successful backend operations.

The final result should feel like a coherent, production-oriented SaaS product that can be implemented in React and Supabase while preserving the established Oat & Slate visual identity.