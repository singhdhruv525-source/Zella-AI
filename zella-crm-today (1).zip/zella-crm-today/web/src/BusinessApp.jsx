import { useCallback, useEffect, useState } from "react";
import {
  AutomationsPage, CalendarPage, CallsPage, CustomersPage, LeadsPage,
  MessagesPage, ReceptionistPage, SettingsPage, TeamPage,
} from "./BusinessPages";
import "./BusinessApp.css";
import { supabase } from "./supabase";
import { BusinessSignIn, Welcome } from "./BusinessAuth";
import BusinessToday from "./BusinessToday";
import { AddLeadModal, BookAppointmentModal } from "./BusinessForms";
import { Icon, Pill, initials, loadBusinessFonts } from "./BusinessUI";
import { formatLongDate } from "./businessTime";
import { makeTerm, receptionistState } from "./businessWorkspace";

// The CRM each client business uses (Stitch design). Routes:
//   /welcome  set password from an invitation or reset email
//   /app      sign in, then the business's own workspace

loadBusinessFonts();

// Sidebar groups from the design. Core CRM pages always show; the rest follow
// the business's enabled modules. Pages not built yet are marked "Soon".
function navigation(workspace) {
  const term = makeTerm(workspace);
  const has = (slug) => workspace.modules.includes(slug);
  const groups = [
    {
      label: "Core",
      items: [
        { key: "today", label: "Today", icon: "dashboard", ready: true },
        { key: "leads", label: "Leads", icon: "filter_alt", ready: true },
        { key: "customers", label: term("customers"), icon: "group", ready: true },
        { key: "calendar", label: "Calendar", icon: "calendar_today", ready: true },
      ],
    },
    {
      label: "Communications",
      items: [
        { key: "inbox", label: "Unified Inbox", icon: "forum" },
        has("calls") && { key: "calls", label: "Calls", icon: "call", ready: true },
        (has("sms") || has("email")) && { key: "messages", label: "Messages", icon: "chat", ready: true },
        { key: "lead-sources", label: "Lead sources", icon: "hub" },
      ],
    },
    {
      label: "AI & Intelligence",
      items: [
        has("ai-receptionist") && { key: "receptionist", label: "AI Receptionist", icon: "record_voice_over", ready: true },
        has("calls") && { key: "transcripts", label: "Transcripts", icon: "insights", ready: true },
        has("automations") && { key: "automations", label: "Automations", icon: "bolt", ready: true },
      ],
    },
    {
      label: "Management",
      items: [
        { key: "team", label: "Team", icon: "badge", ready: true },
        { key: "reports", label: "Reports", icon: "monitoring" },
        { key: "integrations", label: "Integrations", icon: "extension" },
        { key: "settings", label: "Settings", icon: "settings", ready: true },
      ],
    },
  ];
  return groups
    .map((g) => ({ ...g, items: g.items.filter(Boolean) }))
    .filter((g) => g.items.length);
}

function Blocked({ workspace, onSignOut }) {
  const cancelled = Boolean(workspace.cancelled_at);
  return (
    <main className="ba-auth">
      <section className="ba-auth-card">
        <div className="ba-brand">
          <div className="ba-logo">Z</div>
          <div className="ba-brand-name">Zella AI</div>
        </div>
        <div className="ba-eyebrow">{workspace.name}</div>
        <h1>{cancelled ? "This plan has ended" : "This workspace is paused"}</h1>
        <p className="ba-auth-description">
          {cancelled
            ? "Your Zella membership has ended, so your workspace and AI receptionist are off. Your information is kept. Contact the Zella team to start again."
            : "Your workspace and AI receptionist are paused for now. Please contact the Zella team to get it running again."}
        </p>
        <button type="button" className="ba-btn block" onClick={onSignOut}>Sign out</button>
      </section>
    </main>
  );
}

function Workspace({ workspace, workspaces, onSwitch, email, onSignOut, onReload }) {
  const [page, setPage] = useState("today");
  const [modal, setModal] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const term = makeTerm(workspace);
  const groups = navigation(workspace);
  const agent = receptionistState(workspace);
  const isOwner = workspace.role === "owner";

  async function keepPlan() {
    setBusy(true);
    setError("");
    try {
      const { error: rpcError } = await supabase.rpc("zella_owner_continue_plan", { p_business_id: workspace.id });
      if (rpcError) throw rpcError;
      setNotice("Your plan will continue. Thanks for staying with Zella.");
      await onReload();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function saved(message) {
    setModal(null);
    setNotice(message);
    setRefreshKey((k) => k + 1);
  }

  const allItems = groups.flatMap((g) => g.items);
  const current = allItems.find((i) => i.key === page) ?? allItems[0];

  return (
    <div className="ba-root">
      <aside className="ba-sidebar">
        <div className="ba-brand">
          <div className="ba-logo">Z</div>
          <div>
            <div className="ba-brand-name">Zella AI</div>
            <div className="ba-brand-sub">{workspace.industry ?? "Business"} CRM</div>
          </div>
        </div>

        {groups.map((group) => (
          <div key={group.label}>
            <div className="ba-nav-group">{group.label}</div>
            <nav className="ba-nav">
              {group.items.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  className={`ba-nav-item ${page === item.key ? "active" : ""} ${item.ready ? "" : "soon"}`}
                  onClick={() => item.ready && setPage(item.key)}
                  aria-disabled={!item.ready}
                  title={item.label}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {!item.ready && <span className="ba-soon">Soon</span>}
                </button>
              ))}
            </nav>
          </div>
        ))}

        <div className="ba-sidebar-foot">
          <div className="ba-agent-card">
            <div className="ba-agent-row">
              <strong>{workspace.receptionist?.name ?? "AI receptionist"}</strong>
              <Pill tone={agent.tone} dot={agent.live} pulse={agent.live}>{agent.label}</Pill>
            </div>
            <span>{agent.live ? "Answering your calls" : "Zella connects your phone line before it goes live"}</span>
          </div>
          <div className="ba-user-card">
            <div className="ba-avatar">{initials(email)}</div>
            <div>
              <strong title={email}>{email}</strong>
              <span>{workspace.role}</span>
            </div>
            <button type="button" className="ba-btn ghost sm" onClick={onSignOut} title="Sign out" aria-label="Sign out">
              <Icon name="logout" size="sm" />
            </button>
          </div>
        </div>
      </aside>

      <div className="ba-main">
        <header className="ba-header">
          <div className="ba-business">
            <Icon name="domain" />
            {workspaces.length > 1 ? (
              <select value={workspace.id} onChange={(e) => onSwitch(e.target.value)} aria-label="Switch business">
                {workspaces.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            ) : (
              <div>
                <strong>{workspace.name}</strong>
                <span>{workspace.industry ?? ""}</span>
              </div>
            )}
          </div>

          <label className="ba-search">
            <Icon name="search" size="sm" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); if (page !== "customers" && page !== "leads") setPage("customers"); }}
              placeholder={`Search ${term("customers").toLowerCase()}`}
              aria-label={`Search ${term("customers").toLowerCase()}`}
            />
          </label>

          <div className="ba-header-actions">
            <button type="button" className="ba-btn primary" onClick={() => setModal("lead")}>
              <Icon name="person_add" /><span>Add lead</span>
            </button>
            <button type="button" className="ba-btn" onClick={() => setModal("book")}>
              <Icon name="event" /><span>Book {term("appointment").toLowerCase()}</span>
            </button>
          </div>
        </header>

        <main className="ba-content">
          {workspace.cancel_at && !workspace.cancelled_at && (
            <div className="ba-banner">
              <span>
                Your Zella plan ends on <strong>{formatLongDate(workspace.cancel_at, workspace.timezone)}</strong>.
                After that your AI receptionist stops answering calls.
              </span>
              {isOwner && (
                <button type="button" className="ba-btn primary sm" onClick={keepPlan} disabled={busy}>
                  {busy ? "Saving..." : "Keep my plan"}
                </button>
              )}
            </div>
          )}
          {notice && (
            <div className="ba-banner success" role="status">
              <span>{notice}</span>
              <button type="button" className="ba-btn ghost sm" onClick={() => setNotice("")} aria-label="Dismiss">
                <Icon name="close" size="sm" />
              </button>
            </div>
          )}
          {error && <div className="ba-banner error">{error}</div>}

          {current.key === "today" && (
            <BusinessToday
              key={refreshKey}
              workspace={workspace}
              onAddLead={() => setModal("lead")}
              onBook={() => setModal("book")}
              onNotice={setNotice}
            />
          )}
          {current.key === "leads" && <LeadsPage workspace={workspace} query={search} refreshKey={refreshKey} onNotice={setNotice} />}
          {current.key === "customers" && <CustomersPage workspace={workspace} query={search} refreshKey={refreshKey} onNotice={setNotice} />}
          {current.key === "calendar" && <CalendarPage workspace={workspace} refreshKey={refreshKey} onNotice={setNotice} />}
          {current.key === "calls" && <CallsPage workspace={workspace} refreshKey={refreshKey} onNotice={setNotice} />}
          {current.key === "transcripts" && <CallsPage workspace={workspace} refreshKey={refreshKey} onNotice={setNotice} transcriptsOnly />}
          {current.key === "messages" && <MessagesPage workspace={workspace} refreshKey={refreshKey} />}
          {current.key === "receptionist" && <ReceptionistPage workspace={workspace} />}
          {current.key === "automations" && <AutomationsPage workspace={workspace} />}
          {current.key === "team" && <TeamPage workspace={workspace} email={email} />}
          {current.key === "settings" && <SettingsPage workspace={workspace} email={email} onSignOut={onSignOut} />}
        </main>
      </div>

      {modal === "lead" && <AddLeadModal workspace={workspace} term={term} onClose={() => setModal(null)} onSaved={saved} />}
      {modal === "book" && <BookAppointmentModal workspace={workspace} term={term} onClose={() => setModal(null)} onSaved={saved} />}
    </div>
  );
}

function Loading({ text }) {
  return (
    <main className="ba-auth">
      <p className="ba-muted">{text}</p>
    </main>
  );
}

function BusinessHome() {
  const [session, setSession] = useState(undefined);
  const [workspaces, setWorkspaces] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [error, setError] = useState("");

  const loadWorkspaces = useCallback(async () => {
    setError("");
    // Activates any invitation this person hasn't accepted yet (safe to repeat).
    const { error: acceptError } = await supabase.rpc("zella_accept_my_invitations");
    if (acceptError) console.error("Accepting invitations failed", acceptError);

    const { data, error: loadError } = await supabase.rpc("zella_my_workspaces");
    if (loadError) {
      setError(loadError.message);
      setWorkspaces([]);
      return;
    }
    setWorkspaces(data ?? []);
    setSelectedId((current) => ((data ?? []).some((w) => w.id === current) ? current : data?.[0]?.id ?? null));
  }, []);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => active && setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (session) loadWorkspaces();
    else setWorkspaces(null);
  }, [session, loadWorkspaces]);

  async function signOut() {
    await supabase.auth.signOut();
    setWorkspaces(null);
  }

  if (session === undefined) return <Loading text="Loading..." />;
  if (!session) return <BusinessSignIn />;
  if (workspaces === null) return <Loading text="Loading your workspace..." />;

  if (!workspaces.length) {
    return (
      <main className="ba-auth">
        <section className="ba-auth-card">
          <div className="ba-brand">
            <div className="ba-logo">Z</div>
            <div className="ba-brand-name">Zella AI</div>
          </div>
          <h1>No workspace yet</h1>
          <p className="ba-auth-description">
            {error
              ? `Your workspace couldn't be loaded: ${error}`
              : `${session.user.email} isn't linked to a Zella business yet. If you were invited, open the link in your invitation email first, or ask the Zella team to resend it.`}
          </p>
          <button type="button" className="ba-btn block" onClick={signOut}>Sign out</button>
        </section>
      </main>
    );
  }

  const workspace = workspaces.find((w) => w.id === selectedId) ?? workspaces[0];
  if (workspace.cancelled_at || workspace.suspended_at) return <Blocked workspace={workspace} onSignOut={signOut} />;

  return (
    <Workspace
      key={workspace.id}
      workspace={workspace}
      workspaces={workspaces}
      onSwitch={setSelectedId}
      email={session.user.email}
      onSignOut={signOut}
      onReload={loadWorkspaces}
    />
  );
}

// Look-only preview of the workspace without signing in. It exists only
// while running locally (npm run dev) and is removed from production builds.
// It has no data and cannot save anything, because there is no signed-in user.
const PREVIEW_WORKSPACE = {
  id: "preview",
  name: "Bright Smile Dental",
  timezone: "America/New_York",
  industry: "Dental clinic",
  role: "owner",
  is_active: true,
  onboarding_status: "active",
  suspended_at: null,
  cancel_at: null,
  cancelled_at: null,
  terminology: {
    customer: "Patient", customers: "Patients", appointment: "Appointment",
    appointments: "Appointments", staff: "Dentist", staff_plural: "Dentists",
  },
  modules: ["ai-receptionist", "automations", "calendar", "calls", "sms", "email"],
  receptionist: { name: "Ava", status: "active" },
  phone_connected: true,
  voice_connected: true,
};

function Preview() {
  return (
    <Workspace
      workspace={PREVIEW_WORKSPACE}
      workspaces={[PREVIEW_WORKSPACE]}
      onSwitch={() => {}}
      email="preview@zella.ai"
      onSignOut={() => { window.location.href = "/app"; }}
      onReload={() => {}}
    />
  );
}

export default function BusinessApp() {
  const path = window.location.pathname;
  if (path.startsWith("/welcome")) return <Welcome />;
  if (import.meta.env.DEV && path.startsWith("/app/preview")) return <Preview />;
  return <BusinessHome />;
}
