import { useEffect, useState } from "react";
import { supabase } from "./supabase";
import { Field, Modal, personName } from "./BusinessUI";
import { todayInput, zonedDateTime } from "./businessTime";

// Quick actions from the header: add a lead and book an appointment.
// Both write with the signed-in member's session, so Row Level Security
// only allows records for their own business.

const SOURCES = [
  ["manual", "Added by team"],
  ["phone", "Phone call"],
  ["walk_in", "Walk-in"],
  ["website", "Website"],
  ["google", "Google"],
  ["meta", "Facebook / Instagram"],
  ["referral", "Referral"],
  ["other", "Other"],
];

const PHONE_RE = /^[0-9+()\-.\s]{7,30}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function AddLeadModal({ workspace, term, onClose, onSaved }) {
  const [form, setForm] = useState({ first_name: "", last_name: "", phone: "", email: "", source: "manual", notes: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (key) => (event) => setForm({ ...form, [key]: event.target.value });

  async function save(event) {
    event.preventDefault();
    const values = Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim()]));
    if (!values.first_name && !values.last_name) return setError("Enter a name.");
    if (!values.phone && !values.email) return setError("Enter a phone number or email so you can follow up.");
    if (values.phone && !PHONE_RE.test(values.phone)) return setError("Check the phone number.");
    if (values.email && !EMAIL_RE.test(values.email)) return setError("Check the email address.");

    setBusy(true);
    setError("");
    const { data, error: insertError } = await supabase
      .from("customers")
      .insert({
        business_id: workspace.id,
        first_name: values.first_name || null,
        last_name: values.last_name || null,
        phone: values.phone || null,
        email: values.email ? values.email.toLowerCase() : null,
        source: values.source,
        notes: values.notes || null,
        status: "active",
      })
      .select("id, first_name, last_name")
      .single();
    setBusy(false);

    if (insertError) return setError(insertError.message);
    onSaved(`${personName(data) ?? "New lead"} was added.`);
  }

  return (
    <Modal
      title="Add a lead"
      description={`A new enquiry. They'll appear in your ${term("customers").toLowerCase()} and on Today.`}
      onClose={onClose}
      busy={busy}
      footer={
        <>
          <button type="button" className="ba-btn" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="submit" form="ba-add-lead" className="ba-btn primary" disabled={busy}>
            {busy ? "Saving..." : "Add lead"}
          </button>
        </>
      }
    >
      <form id="ba-add-lead" className="ba-modal-body" onSubmit={save}>
        <div className="ba-form-grid">
          <Field label="First name"><input value={form.first_name} onChange={set("first_name")} autoFocus /></Field>
          <Field label="Last name"><input value={form.last_name} onChange={set("last_name")} /></Field>
          <Field label="Phone"><input type="tel" value={form.phone} onChange={set("phone")} placeholder="+1 (555) 000-0000" /></Field>
          <Field label="Email"><input type="email" value={form.email} onChange={set("email")} /></Field>
          <Field label="Where did they come from?" full>
            <select value={form.source} onChange={set("source")}>
              {SOURCES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </Field>
          <Field label="Notes" full>
            <textarea value={form.notes} onChange={set("notes")} placeholder="What are they looking for?" />
          </Field>
        </div>
        {error && <div className="ba-error">{error}</div>}
      </form>
    </Modal>
  );
}

export function BookAppointmentModal({ workspace, term, onClose, onSaved }) {
  const tz = workspace.timezone;
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [form, setForm] = useState({
    title: "",
    date: todayInput(tz),
    time: "09:00",
    duration: "30",
    location: "",
    description: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (key) => (event) => setForm({ ...form, [key]: event.target.value });

  // Find an existing customer by name, phone or email.
  useEffect(() => {
    const q = query.trim();
    if (q.length < 2 || customer) {
      setResults([]);
      return undefined;
    }
    const safe = q.replace(/[%*,()]/g, " ").trim();
    const timer = setTimeout(async () => {
      const { data } = await supabase
        .from("customers")
        .select("id, first_name, last_name, company_name, phone, email")
        .eq("business_id", workspace.id)
        .or(`first_name.ilike.*${safe}*,last_name.ilike.*${safe}*,phone.ilike.*${safe}*,email.ilike.*${safe}*`)
        .limit(8);
      setResults(data ?? []);
    }, 250);
    return () => clearTimeout(timer);
  }, [query, customer, workspace.id]);

  async function save(event) {
    event.preventDefault();
    if (!form.title.trim()) return setError(`Give the ${term("appointment").toLowerCase()} a title.`);
    if (!form.date || !form.time) return setError("Choose a date and time.");

    const start = zonedDateTime(form.date, form.time, tz);
    const end = new Date(start.getTime() + Number(form.duration) * 60000);

    setBusy(true);
    setError("");
    const { error: insertError } = await supabase.from("appointments").insert({
      business_id: workspace.id,
      customer_id: customer?.id ?? null,
      title: form.title.trim(),
      start_time: start.toISOString(),
      end_time: end.toISOString(),
      timezone: tz,
      status: "scheduled",
      location: form.location.trim() || null,
      description: form.description.trim() || null,
    });
    setBusy(false);

    if (insertError) return setError(insertError.message);
    onSaved(`${term("appointment")} booked${customer ? ` for ${personName(customer)}` : ""}.`);
  }

  return (
    <Modal
      title={`Book ${term("appointment").toLowerCase()}`}
      description={`Times are in ${workspace.name}'s time zone (${tz.replace("_", " ")}).`}
      onClose={onClose}
      busy={busy}
      footer={
        <>
          <button type="button" className="ba-btn" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="submit" form="ba-book" className="ba-btn primary" disabled={busy}>
            {busy ? "Booking..." : "Book"}
          </button>
        </>
      }
    >
      <form id="ba-book" className="ba-modal-body" onSubmit={save}>
        <Field label={term("customer")} hint={customer ? undefined : "Search by name, phone or email. Optional."}>
          {customer ? (
            <div className="ba-status-row">
              <strong>{personName(customer) ?? customer.phone}</strong>
              <button type="button" className="ba-link" onClick={() => { setCustomer(null); setQuery(""); }}>Change</button>
            </div>
          ) : (
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Find a ${term("customer").toLowerCase()}`} />
          )}
        </Field>
        {!customer && results.length > 0 && (
          <div className="ba-picker">
            {results.map((r) => (
              <button type="button" key={r.id} onClick={() => setCustomer(r)}>
                <strong>{personName(r) ?? "Unnamed"}</strong>
                <span>{r.phone || r.email || ""}</span>
              </button>
            ))}
          </div>
        )}
        <div className="ba-form-grid">
          <Field label="Title" full>
            <input value={form.title} onChange={set("title")} placeholder={`e.g. ${term("service")}`} />
          </Field>
          <Field label="Date"><input type="date" value={form.date} onChange={set("date")} required /></Field>
          <Field label="Start time"><input type="time" value={form.time} onChange={set("time")} required /></Field>
          <Field label="Length">
            <select value={form.duration} onChange={set("duration")}>
              {[15, 30, 45, 60, 90, 120].map((m) => (
                <option key={m} value={m}>{m < 60 ? `${m} min` : `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ""}`}</option>
              ))}
            </select>
          </Field>
          <Field label="Location"><input value={form.location} onChange={set("location")} placeholder="Optional" /></Field>
          <Field label="Notes" full><textarea value={form.description} onChange={set("description")} /></Field>
        </div>
        {error && <div className="ba-error">{error}</div>}
      </form>
    </Modal>
  );
}
