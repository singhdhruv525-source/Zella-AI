import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "./supabase";
import { Icon, Modal, Pill, initials, personName } from "./BusinessUI";
import { makeTerm, receptionistState } from "./businessWorkspace";
import { dayRange, formatDay, formatLongDate, formatTime, timeAgo } from "./businessTime";

// The rest of the business app: Leads, People (Patients / Customers / Clients…),
// Calendar, Calls, Messages, AI Receptionist, Automations, Team and Settings.
// Everything is read with the signed-in member's own session, so Row Level
// Security returns this business's records only. Where there is nothing yet,
// each page says so instead of showing made-up numbers.

const SOURCE_LABELS = {
  manual: "Team", phone: "Phone", walk_in: "Walk-in", website: "Website", google: "Google",
  meta: "Meta", referral: "Referral", call: "Call", voice: "Voice AI", other: "Other",
};
const APPT_TONE = { scheduled: "warning", confirmed: "success", completed: "info", cancelled: "", no_show: "danger" };
const APPT_LABEL = { scheduled: "Scheduled", confirmed: "Confirmed", completed: "Completed", cancelled: "Cancelled", no_show: "No-show" };
const PAGE_SIZE = 25;

const sourceLabel = (s) => SOURCE_LABELS[s] ?? (s ? s.replace(/_/g, " ") : "Other");
const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;
const clock = (seconds) =>
  seconds || seconds === 0 ? `${Math.floor(seconds / 60)}:${String(Math.round(seconds % 60)).padStart(2, "0")}` : "—";

function PageHead({ crumb, title, sub, children }) {
  return (
    <div className="ba-page-head">
      <div>
        <div className="ba-crumb">{crumb}</div>
        <h1>{title}</h1>
        {sub && <p>{sub}</p>}
      </div>
      {children && <div className="ba-page-actions">{children}</div>}
    </div>
  );
}

function Segment({ value, onChange, options, label }) {
  return (
    <div className="ba-segment" role="tablist" aria-label={label}>
      {options.map(([key, text]) => (
        <button key={key} type="button" role="tab" aria-selected={value === key} className={value === key ? "active" : ""} onClick={() => onChange(key)}>
          {text}
        </button>
      ))}
    </div>
  );
}

function Empty({ title, children }) {
  return (
    <div className="ba-empty">
      {title && <strong>{title}</strong>}
      {children}
    </div>
  );
}

function Notice({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="ba-banner error">
      <span>Couldn't load this page: {error}</span>
      {onRetry && <button type="button" className="ba-btn sm" onClick={onRetry}>Try again</button>}
    </div>
  );
}

// Runs a loader and keeps rows, loading and error state together.
function useLoad(loader, deps) {
  const [state, setState] = useState({ data: null, error: "", loading: true });
  const run = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: "" }));
    try {
      const data = await loader();
      setState({ data, error: "", loading: false });
    } catch (err) {
      setState((s) => ({ ...s, error: err.message || String(err), loading: false }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...state, reload: run };
}

function orThrow(result) {
  if (result.error) throw result.error;
  return result.data ?? [];
}

// Names of the people referenced by other records.
async function loadPeople(ids) {
  const unique = [...new Set(ids.filter(Boolean))];
  if (!unique.length) return {};
  const rows = orThrow(await supabase.from("customers").select("id, first_name, last_name, company_name, phone, email").in("id", unique));
  return Object.fromEntries(rows.map((p) => [p.id, p]));
}

function Pager({ page, pages, total, onPage, noun }) {
  if (total <= PAGE_SIZE) return <div className="ba-table-foot"><span>{plural(total, noun)}</span></div>;
  return (
    <div className="ba-table-foot">
      <span>{plural(total, noun)} · page {page + 1} of {pages}</span>
      <div className="ba-page-actions">
        <button type="button" className="ba-btn sm" disabled={page === 0} onClick={() => onPage(page - 1)}>Previous</button>
        <button type="button" className="ba-btn sm" disabled={page >= pages - 1} onClick={() => onPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Leads and people                                                    */
/* ------------------------------------------------------------------ */

function PersonDetail({ person, workspace, term, onClose, onChanged, onNotice }) {
  const tz = workspace.timezone;
  const [notes, setNotes] = useState(person.notes ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const history = useLoad(async () => {
    const [appts, calls] = await Promise.all([
      supabase.from("appointments").select("id, title, start_time, status").eq("customer_id", person.id).order("start_time", { ascending: false }).limit(10),
      supabase.from("calls").select("id, status, ai_handled, duration_seconds, created_at").eq("customer_id", person.id).order("created_at", { ascending: false }).limit(10),
    ]);
    return { appts: orThrow(appts), calls: orThrow(calls) };
  }, [person.id]);

  async function update(values, message) {
    setBusy(true);
    setError("");
    const { error: updateError } = await supabase.from("customers").update({ ...values, updated_at: new Date().toISOString() }).eq("id", person.id);
    setBusy(false);
    if (updateError) return setError(updateError.message);
    onNotice(message);
    onChanged();
  }

  const name = personName(person) ?? "Unnamed";
  return (
    <Modal
      title={name}
      description={`${term("customer")} · added ${timeAgo(person.created_at)} · ${sourceLabel(person.source)}`}
      onClose={onClose}
      busy={busy}
      footer={
        <>
          {person.phone && <a className="ba-btn" href={`tel:${person.phone}`}><Icon name="call" size="sm" />Call</a>}
          <button type="button" className="ba-btn" disabled={busy} onClick={() => update({ last_contacted_at: new Date().toISOString() }, `${name} marked as contacted.`)}>
            Mark contacted
          </button>
          <button type="button" className="ba-btn primary" disabled={busy || notes === (person.notes ?? "")} onClick={() => update({ notes: notes.trim() || null }, "Notes saved.")}>
            Save notes
          </button>
        </>
      }
    >
      <div className="ba-detail">
        {error && <div className="ba-banner error">{error}</div>}
        <dl className="ba-facts">
          <div><dt>Phone</dt><dd>{person.phone ?? "—"}</dd></div>
          <div><dt>Email</dt><dd>{person.email ?? "—"}</dd></div>
          <div><dt>Last contacted</dt><dd>{person.last_contacted_at ? timeAgo(person.last_contacted_at) : "Not yet"}</dd></div>
        </dl>
        <label className="ba-field full">
          <span>Notes</span>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything the team should know" />
        </label>
        <div className="ba-detail-cols">
          <div>
            <h3>{term("appointments")}</h3>
            {history.loading && !history.data ? <p className="ba-muted">Loading…</p> : !history.data?.appts.length ? (
              <p className="ba-muted">No {term("appointments").toLowerCase()} yet.</p>
            ) : history.data.appts.map((a) => (
              <div key={a.id} className="ba-mini">
                <span>{a.title}<small>{formatDay(a.start_time, tz)} · {formatTime(a.start_time, tz)}</small></span>
                <Pill tone={APPT_TONE[a.status]}>{APPT_LABEL[a.status] ?? a.status}</Pill>
              </div>
            ))}
          </div>
          <div>
            <h3>Calls</h3>
            {history.loading && !history.data ? <p className="ba-muted">Loading…</p> : !history.data?.calls.length ? (
              <p className="ba-muted">No calls yet.</p>
            ) : history.data.calls.map((c) => (
              <div key={c.id} className="ba-mini">
                <span>{c.ai_handled ? "AI receptionist" : "Team"}<small>{timeAgo(c.created_at)} · {clock(c.duration_seconds)}</small></span>
                <Pill tone={c.status === "missed" ? "danger" : "success"}>{c.status === "missed" ? "Missed" : "Answered"}</Pill>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}

function PeoplePage({ mode, workspace, query, refreshKey, onNotice }) {
  const term = makeTerm(workspace);
  const isLeads = mode === "leads";
  const [filter, setFilter] = useState(isLeads ? "new" : "all");
  const [source, setSource] = useState("all");
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(null);
  const { data, error, loading, reload } = useLoad(async () => {
    return orThrow(await supabase
      .from("customers")
      .select("id, first_name, last_name, company_name, phone, email, source, notes, last_contacted_at, created_at, status")
      .eq("business_id", workspace.id)
      .order("created_at", { ascending: false })
      .limit(1000));
  }, [workspace.id, refreshKey]);

  const rows = useMemo(() => {
    const q = (query ?? "").trim().toLowerCase();
    const cutoff = Date.now() - 30 * 86400000;
    return (data ?? []).filter((p) => {
      if (isLeads) {
        if (new Date(p.created_at).getTime() < cutoff) return false;
        if (filter === "new" && p.last_contacted_at) return false;
        if (filter === "contacted" && !p.last_contacted_at) return false;
      }
      if (source !== "all" && (p.source || "other") !== source) return false;
      if (!q) return true;
      return [personName(p), p.phone, p.email, p.company_name].some((v) => v && v.toLowerCase().includes(q));
    });
  }, [data, filter, source, query, isLeads]);

  useEffect(() => setPage(0), [filter, source, query, mode]);
  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const visible = rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const sources = [...new Set((data ?? []).map((p) => p.source || "other"))].sort();
  const noun = isLeads ? "lead" : term("customer").toLowerCase();

  return (
    <>
      <PageHead
        crumb={`Core / ${isLeads ? "Leads" : term("customers")}`}
        title={isLeads ? "Leads" : term("customers")}
        sub={isLeads
          ? "People who reached out in the last 30 days. Follow up with anyone you haven't contacted yet."
          : `Everyone your business has spoken with, with their ${term("appointments").toLowerCase()} and calls.`}
      >
        {isLeads && (
          <Segment label="Lead filter" value={filter} onChange={setFilter} options={[["new", "Needs follow-up"], ["contacted", "Contacted"], ["all", "All"]]} />
        )}
      </PageHead>

      <Notice error={error} onRetry={reload} />
      <section className="ba-panel">
        <div className="ba-toolbar">
          <span className="ba-muted">Use the search box at the top to find someone by name, phone or email.</span>
          <label className="ba-select">
            <span>Source</span>
            <select value={source} onChange={(e) => setSource(e.target.value)}>
              <option value="all">All sources</option>
              {sources.map((s) => <option key={s} value={s}>{sourceLabel(s)}</option>)}
            </select>
          </label>
        </div>

        {loading && !data ? <div className="ba-panel-body"><p className="ba-muted">Loading…</p></div> : !rows.length ? (
          <div className="ba-panel-body">
            <Empty title={query || source !== "all" ? "No matches" : isLeads ? "No leads to follow up" : `No ${term("customers").toLowerCase()} yet`}>
              {query || source !== "all"
                ? "Try a different search or source."
                : isLeads
                  ? "New leads from calls, your website and the team will appear here."
                  : `${term("customers")} appear when someone calls, books or is added by your team.`}
            </Empty>
          </div>
        ) : (
          <>
            <div className="ba-table-wrap">
              <table className="ba-table">
                <thead>
                  <tr><th>Name</th><th>Phone</th><th>Source</th><th>Added</th><th>Last contacted</th><th /></tr>
                </thead>
                <tbody>
                  {visible.map((p) => {
                    const name = personName(p) ?? "Unnamed";
                    return (
                      <tr key={p.id} onClick={() => setOpen(p)} tabIndex={0} onKeyDown={(e) => e.key === "Enter" && setOpen(p)}>
                        <td>
                          <div className="ba-person">
                            <div className="ba-avatar sm">{initials(name)}</div>
                            <div><strong>{name}</strong><small>{p.email ?? ""}</small></div>
                          </div>
                        </td>
                        <td>{p.phone ?? "—"}</td>
                        <td><Pill tone="indigo">{sourceLabel(p.source)}</Pill></td>
                        <td>{timeAgo(p.created_at)}</td>
                        <td>{p.last_contacted_at ? timeAgo(p.last_contacted_at) : <span className="ba-flag">Not yet</span>}</td>
                        <td className="ba-actions" onClick={(e) => e.stopPropagation()}>
                          {p.phone && <a className="ba-btn sm" href={`tel:${p.phone}`} aria-label={`Call ${name}`}><Icon name="call" size="sm" /></a>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pager page={page} pages={pages} total={rows.length} onPage={setPage} noun={noun} />
          </>
        )}
      </section>

      {open && (
        <PersonDetail
          person={open}
          workspace={workspace}
          term={term}
          onClose={() => setOpen(null)}
          onChanged={() => { setOpen(null); reload(); }}
          onNotice={onNotice}
        />
      )}
    </>
  );
}

export const LeadsPage = (props) => <PeoplePage mode="leads" {...props} />;
export const CustomersPage = (props) => <PeoplePage mode="customers" {...props} />;

/* ------------------------------------------------------------------ */
/* Calendar                                                            */
/* ------------------------------------------------------------------ */

function AppointmentDetail({ appt, person, tz, term, onClose, onChanged, onNotice }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function setStatus(status) {
    setBusy(true);
    setError("");
    const { error: updateError } = await supabase.from("appointments").update({ status, updated_at: new Date().toISOString() }).eq("id", appt.id);
    setBusy(false);
    if (updateError) return setError(updateError.message);
    onNotice(`${appt.title} marked ${APPT_LABEL[status].toLowerCase()}.`);
    onChanged();
  }

  const name = personName(person);
  const next = ["confirmed", "completed", "no_show", "cancelled"].filter((s) => s !== appt.status);
  return (
    <Modal
      title={appt.title}
      description={`${formatLongDate(appt.start_time, tz)} · ${formatTime(appt.start_time, tz)} to ${formatTime(appt.end_time, tz)}`}
      onClose={onClose}
      busy={busy}
      footer={next.map((s) => (
        <button key={s} type="button" className={`ba-btn ${s === "cancelled" || s === "no_show" ? "danger-outline" : ""}`} disabled={busy} onClick={() => setStatus(s)}>
          {s === "confirmed" ? "Confirm" : s === "completed" ? "Mark done" : s === "no_show" ? "No-show" : "Cancel"}
        </button>
      ))}
    >
      <div className="ba-detail">
        {error && <div className="ba-banner error">{error}</div>}
        <dl className="ba-facts">
          <div><dt>Status</dt><dd><Pill tone={APPT_TONE[appt.status]}>{APPT_LABEL[appt.status] ?? appt.status}</Pill></dd></div>
          <div><dt>{term("customer")}</dt><dd>{name ?? "Not linked"}</dd></div>
          <div><dt>Phone</dt><dd>{person?.phone ? <a className="ba-link" href={`tel:${person.phone}`}>{person.phone}</a> : "—"}</dd></div>
          <div><dt>Where</dt><dd>{appt.location ?? "—"}</dd></div>
        </dl>
        {appt.description && <p className="ba-note">{appt.description}</p>}
      </div>
    </Modal>
  );
}

export function CalendarPage({ workspace, refreshKey, onNotice }) {
  const tz = workspace.timezone;
  const term = makeTerm(workspace);
  const [offset, setOffset] = useState(0);
  const [open, setOpen] = useState(null);
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => dayRange(tz, offset * 7 + i)), [tz, offset]);

  const { data, error, loading, reload } = useLoad(async () => {
    const appts = orThrow(await supabase
      .from("appointments")
      .select("id, title, start_time, end_time, status, customer_id, location, description")
      .eq("business_id", workspace.id)
      .gte("start_time", days[0].start.toISOString())
      .lt("start_time", days[6].end.toISOString())
      .order("start_time"));
    return { appts, people: await loadPeople(appts.map((a) => a.customer_id)) };
  }, [workspace.id, days, refreshKey]);

  const todayStart = dayRange(tz, 0).start.getTime();
  const total = data?.appts.filter((a) => a.status !== "cancelled").length ?? 0;
  return (
    <>
      <PageHead crumb="Core / Calendar" title="Calendar" sub={`${term("appointments")} for ${formatDay(days[0].start, tz)} to ${formatDay(days[6].start, tz)} (${tz.replace("_", " ")})`}>
        <div className="ba-segment">
          <button type="button" onClick={() => setOffset(offset - 1)} aria-label="Previous 7 days"><Icon name="chevron_left" size="sm" /></button>
          <button type="button" className={offset === 0 ? "active" : ""} onClick={() => setOffset(0)}>Today</button>
          <button type="button" onClick={() => setOffset(offset + 1)} aria-label="Next 7 days"><Icon name="chevron_right" size="sm" /></button>
        </div>
      </PageHead>

      <Notice error={error} onRetry={reload} />
      <div className="ba-week">
        {days.map((d) => {
          const items = (data?.appts ?? []).filter((a) => {
            const t = new Date(a.start_time).getTime();
            return t >= d.start.getTime() && t < d.end.getTime();
          });
          return (
            <section key={d.start.toISOString()} className={`ba-day ${d.start.getTime() === todayStart ? "today" : ""}`}>
              <header>
                <strong>{formatDay(d.start, tz)}</strong>
                <span>{items.length ? plural(items.length, "booking") : "Free"}</span>
              </header>
              {items.map((a) => (
                <button key={a.id} type="button" className={`ba-slot ${a.status}`} onClick={() => setOpen(a)}>
                  <span className="ba-slot-time">{formatTime(a.start_time, tz)}</span>
                  <span className="ba-slot-title">{a.title}</span>
                  <span className="ba-slot-who">{personName(data.people[a.customer_id]) ?? ""}</span>
                </button>
              ))}
            </section>
          );
        })}
      </div>
      {!loading && data && total === 0 && (
        <Empty title={`No ${term("appointments").toLowerCase()} in these 7 days`}>Book one yourself, or let your AI receptionist fill the calendar.</Empty>
      )}

      {open && (
        <AppointmentDetail
          appt={open}
          person={data.people[open.customer_id]}
          tz={tz}
          term={term}
          onClose={() => setOpen(null)}
          onChanged={() => { setOpen(null); reload(); }}
          onNotice={onNotice}
        />
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Calls                                                               */
/* ------------------------------------------------------------------ */

function transcriptLines(transcript) {
  if (!transcript) return [];
  if (typeof transcript === "string") return transcript.split("\n").map((t) => t.trim()).filter(Boolean).map((text) => ({ who: "", text }));
  if (Array.isArray(transcript)) {
    return transcript.map((m) => ({ who: m.role ?? m.speaker ?? "", text: m.text ?? m.content ?? m.message ?? "" })).filter((m) => m.text);
  }
  return [{ who: "", text: JSON.stringify(transcript) }];
}

function CallDetail({ call, person, tz, onClose, onChanged, onNotice }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const lines = transcriptLines(call.transcript);
  const missed = call.status === "missed";

  async function followedUp() {
    setBusy(true);
    setError("");
    const { error: updateError } = await supabase.from("calls")
      .update({ metadata: { ...(call.metadata ?? {}), followed_up_at: new Date().toISOString() }, updated_at: new Date().toISOString() })
      .eq("id", call.id);
    setBusy(false);
    if (updateError) return setError(updateError.message);
    onNotice("Missed call marked as followed up.");
    onChanged();
  }

  const number = person?.phone ?? call.from_number;
  return (
    <Modal
      title={personName(person) ?? call.from_number ?? "Unknown caller"}
      description={`${call.direction === "outbound" ? "Outgoing" : "Incoming"} call · ${formatDay(call.created_at, tz)} · ${formatTime(call.created_at, tz)}`}
      onClose={onClose}
      busy={busy}
      footer={
        <>
          {number && <a className="ba-btn" href={`tel:${number}`}><Icon name="call" size="sm" />Call back</a>}
          {missed && !call.metadata?.followed_up_at && (
            <button type="button" className="ba-btn primary" disabled={busy} onClick={followedUp}>Mark followed up</button>
          )}
        </>
      }
    >
      <div className="ba-detail">
        {error && <div className="ba-banner error">{error}</div>}
        <dl className="ba-facts">
          <div><dt>Result</dt><dd><Pill tone={missed ? "danger" : "success"}>{missed ? "Missed" : "Answered"}</Pill></dd></div>
          <div><dt>Handled by</dt><dd>{call.ai_handled ? "AI receptionist" : "Your team"}</dd></div>
          <div><dt>Length</dt><dd>{clock(call.duration_seconds)}</dd></div>
        </dl>
        <h3>Transcript</h3>
        {lines.length ? (
          <div className="ba-transcript">
            {lines.map((l, i) => (
              <p key={i} className={/assistant|ai|bot/i.test(l.who) ? "ai" : "caller"}>
                {l.who && <b>{/assistant|ai|bot/i.test(l.who) ? "Receptionist" : "Caller"}</b>}
                {l.text}
              </p>
            ))}
          </div>
        ) : <p className="ba-muted">No transcript was saved for this call.</p>}
      </div>
    </Modal>
  );
}

export function CallsPage({ workspace, refreshKey, onNotice, transcriptsOnly }) {
  const tz = workspace.timezone;
  const [filter, setFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(null);
  const { data, error, loading, reload } = useLoad(async () => {
    const calls = orThrow(await supabase
      .from("calls")
      .select("id, direction, status, ai_handled, duration_seconds, from_number, customer_id, created_at, transcript, metadata")
      .eq("business_id", workspace.id)
      .order("created_at", { ascending: false })
      .limit(300));
    return { calls, people: await loadPeople(calls.map((c) => c.customer_id)) };
  }, [workspace.id, refreshKey]);

  const all = (data?.calls ?? []).filter((c) => !transcriptsOnly || c.transcript);
  const rows = all.filter((c) =>
    filter === "missed" ? c.status === "missed" : filter === "ai" ? c.ai_handled : filter === "answered" ? c.status !== "missed" : true);
  useEffect(() => setPage(0), [filter]);
  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const visible = rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const missedOpen = all.filter((c) => c.status === "missed" && !c.metadata?.followed_up_at).length;

  return (
    <>
      <PageHead
        crumb={transcriptsOnly ? "AI & Intelligence / Transcripts" : "Communications / Calls"}
        title={transcriptsOnly ? "Transcripts" : "Calls"}
        sub={transcriptsOnly ? "What callers said and how your AI receptionist answered." : missedOpen ? `${plural(missedOpen, "missed call")} still waiting for a follow-up.` : "Every call, answered or missed."}
      >
        <Segment label="Call filter" value={filter} onChange={setFilter} options={[["all", "All"], ["answered", "Answered"], ["missed", "Missed"], ["ai", "AI handled"]]} />
      </PageHead>

      <Notice error={error} onRetry={reload} />
      <section className="ba-panel">
        {loading && !data ? <div className="ba-panel-body"><p className="ba-muted">Loading…</p></div> : !rows.length ? (
          <div className="ba-panel-body">
            <Empty title={filter === "all" ? "No calls yet" : "No calls match"}>
              {filter === "all" ? "Calls appear here once your phone line is live." : "Try another filter."}
            </Empty>
          </div>
        ) : (
          <>
            <div className="ba-table-wrap">
              <table className="ba-table">
                <thead><tr><th>Caller</th><th>When</th><th>Result</th><th>Handled by</th><th>Length</th></tr></thead>
                <tbody>
                  {visible.map((c) => {
                    const person = data.people[c.customer_id];
                    const name = personName(person) ?? c.from_number ?? "Unknown caller";
                    const missed = c.status === "missed";
                    return (
                      <tr key={c.id} onClick={() => setOpen(c)} tabIndex={0} onKeyDown={(e) => e.key === "Enter" && setOpen(c)}>
                        <td><div className="ba-person"><div className="ba-avatar sm">{initials(name)}</div><div><strong>{name}</strong><small>{person ? c.from_number ?? "" : ""}</small></div></div></td>
                        <td>{formatDay(c.created_at, tz)} · {formatTime(c.created_at, tz)}</td>
                        <td><Pill tone={missed ? "danger" : "success"}>{missed ? (c.metadata?.followed_up_at ? "Missed, followed up" : "Missed") : "Answered"}</Pill></td>
                        <td>{c.ai_handled ? "AI receptionist" : "Team"}</td>
                        <td>{clock(c.duration_seconds)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pager page={page} pages={pages} total={rows.length} onPage={setPage} noun="call" />
          </>
        )}
      </section>

      {open && (
        <CallDetail
          call={open}
          person={data.people[open.customer_id]}
          tz={tz}
          onClose={() => setOpen(null)}
          onChanged={() => { setOpen(null); reload(); }}
          onNotice={onNotice}
        />
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Messages                                                            */
/* ------------------------------------------------------------------ */

const CHANNEL_ICON = { sms: "sms", email: "mail", whatsapp: "chat", chat: "chat", voice: "call", phone: "call" };

export function MessagesPage({ workspace, refreshKey }) {
  const [filter, setFilter] = useState("all");
  const { data, error, loading, reload } = useLoad(async () => {
    const rows = orThrow(await supabase
      .from("conversations")
      .select("id, subject, channel, status, last_message_at, customer_id, ai_handled")
      .eq("business_id", workspace.id)
      .order("last_message_at", { ascending: false, nullsFirst: false })
      .limit(200));
    return { rows, people: await loadPeople(rows.map((r) => r.customer_id)) };
  }, [workspace.id, refreshKey]);

  const channels = [...new Set((data?.rows ?? []).map((r) => r.channel).filter(Boolean))];
  const rows = (data?.rows ?? []).filter((r) => filter === "all" || r.channel === filter);
  return (
    <>
      <PageHead crumb="Communications / Messages" title="Messages" sub="Conversations by text and email. Your AI receptionist answers the routine ones.">
        {channels.length > 1 && (
          <Segment label="Channel" value={filter} onChange={setFilter} options={[["all", "All"], ...channels.map((c) => [c, c.toUpperCase() === c ? c : c[0].toUpperCase() + c.slice(1)])]} />
        )}
      </PageHead>
      <Notice error={error} onRetry={reload} />
      <section className="ba-panel">
        {loading && !data ? <div className="ba-panel-body"><p className="ba-muted">Loading…</p></div> : !rows.length ? (
          <div className="ba-panel-body"><Empty title="No conversations yet">Texts and emails from your {makeTerm(workspace)("customers").toLowerCase()} will appear here.</Empty></div>
        ) : (
          <ul className="ba-threads">
            {rows.map((r) => {
              const name = personName(data.people[r.customer_id]) ?? "Unknown contact";
              return (
                <li key={r.id}>
                  <span className="ba-thread-icon"><Icon name={CHANNEL_ICON[r.channel] ?? "forum"} size="sm" /></span>
                  <div>
                    <strong>{name}</strong>
                    <small>{r.subject || `${r.channel ?? "Message"} conversation`}</small>
                  </div>
                  <div className="ba-thread-meta">
                    {r.ai_handled && <Pill tone="indigo">AI</Pill>}
                    <Pill tone={r.status === "open" ? "warning" : r.status === "pending" ? "info" : ""}>{r.status}</Pill>
                    <span>{r.last_message_at ? timeAgo(r.last_message_at) : "—"}</span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* AI Receptionist and automations                                     */
/* ------------------------------------------------------------------ */

export function ReceptionistPage({ workspace }) {
  const tz = workspace.timezone;
  const agent = receptionistState(workspace);
  const { data, error, reload } = useLoad(async () => {
    const week = dayRange(tz, -6).start.toISOString();
    const [agents, calls] = await Promise.all([
      supabase.from("ai_agents").select("id, name, status, description, channels, is_default").eq("business_id", workspace.id).order("is_default", { ascending: false }),
      supabase.from("calls").select("id, status, ai_handled, duration_seconds").eq("business_id", workspace.id).gte("created_at", week).limit(1000),
    ]);
    return { agents: orThrow(agents), calls: orThrow(calls) };
  }, [workspace.id]);

  const calls = data?.calls ?? [];
  const aiCalls = calls.filter((c) => c.ai_handled);
  const missed = calls.filter((c) => c.status === "missed").length;
  const primary = data?.agents?.[0];
  const checks = [
    ["Receptionist created", Boolean(workspace.receptionist), "Zella sets this up for you."],
    ["Phone line connected", workspace.phone_connected, "Zella connects your number before going live."],
    ["Voice assistant connected", workspace.voice_connected, "Zella links the voice assistant to your number."],
    ["Receptionist switched on", workspace.receptionist?.status === "active", "It starts answering once everything above is done."],
  ];

  return (
    <>
      <PageHead crumb="AI & Intelligence / AI Receptionist" title={workspace.receptionist?.name ?? "AI receptionist"} sub="Answers your calls, books appointments and adds new people to your CRM.">
        <Pill tone={agent.tone} dot={agent.live} pulse={agent.live}>{agent.label}</Pill>
      </PageHead>
      <Notice error={error} onRetry={reload} />
      <div className="ba-grid-2">
        <section className="ba-panel">
          <div className="ba-panel-head"><div className="ba-panel-title"><div><h2>Setup status</h2><p>What has to be in place before calls are answered.</p></div></div></div>
          <ul className="ba-checks">
            {checks.map(([label, done, hint]) => (
              <li key={label} className={done ? "done" : ""}>
                <span><Icon name={done ? "check_circle" : "radio_button_unchecked"} size="sm" /></span>
                <div><strong>{label}</strong>{!done && <small>{hint}</small>}</div>
              </li>
            ))}
          </ul>
        </section>
        <section className="ba-panel">
          <div className="ba-panel-head"><div className="ba-panel-title"><div><h2>Last 7 days</h2><p>From your recorded calls.</p></div></div></div>
          <dl className="ba-stats">
            <div><dt>Calls</dt><dd>{calls.length}</dd></div>
            <div><dt>Handled by AI</dt><dd>{aiCalls.length}</dd></div>
            <div><dt>Missed</dt><dd>{missed}</dd></div>
            <div><dt>Avg length</dt><dd>{aiCalls.length ? clock(Math.round(aiCalls.reduce((s, c) => s + (c.duration_seconds ?? 0), 0) / aiCalls.length)) : "—"}</dd></div>
          </dl>
          {primary?.description && <p className="ba-note pad">{primary.description}</p>}
          {primary?.channels?.length > 0 && (
            <p className="ba-note pad">Works on: {primary.channels.map((c) => c.replace(/_/g, " ")).join(", ")}</p>
          )}
        </section>
      </div>
      <p className="ba-muted pad-top">To change what your receptionist says or knows, ask the Zella team. Editing from here is coming.</p>
    </>
  );
}

export function AutomationsPage({ workspace }) {
  const { data, error, loading, reload } = useLoad(async () =>
    orThrow(await supabase.from("automations").select("id, name, description, status, trigger_type").eq("business_id", workspace.id).order("name")), [workspace.id]);
  return (
    <>
      <PageHead crumb="AI & Intelligence / Automations" title="Automations" sub="Follow-ups, reminders and check-ins that run for you." />
      <Notice error={error} onRetry={reload} />
      <section className="ba-panel">
        {loading && !data ? <div className="ba-panel-body"><p className="ba-muted">Loading…</p></div> : !data?.length ? (
          <div className="ba-panel-body"><Empty title="No automations yet">Zella sets up reminders, missed-call callbacks and no-show follow-ups for you.</Empty></div>
        ) : (
          <ul className="ba-threads">
            {data.map((a) => (
              <li key={a.id}>
                <span className="ba-thread-icon"><Icon name="bolt" size="sm" /></span>
                <div><strong>{a.name}</strong><small>{a.description || (a.trigger_type ? `Starts on: ${a.trigger_type.replace(/_/g, " ")}` : "")}</small></div>
                <div className="ba-thread-meta"><Pill tone={a.status === "active" ? "success" : a.status === "disabled" ? "" : "warning"}>{a.status}</Pill></div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Team and settings                                                   */
/* ------------------------------------------------------------------ */

export function TeamPage({ workspace, email }) {
  const [me, setMe] = useState(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setMe(data?.user?.id ?? null)).catch(() => {});
  }, []);
  const { data, error, loading, reload } = useLoad(async () =>
    orThrow(await supabase.from("business_members").select("id, user_id, role, status, created_at").eq("business_id", workspace.id).order("created_at")), [workspace.id]);
  const staff = makeTerm(workspace)("staff_plural");

  return (
    <>
      <PageHead crumb="Management / Team" title="Team" sub={`People who can sign in to ${workspace.name}. To add or remove ${staff.toLowerCase()}, ask the Zella team.`} />
      <Notice error={error} onRetry={reload} />
      <section className="ba-panel">
        {loading && !data ? <div className="ba-panel-body"><p className="ba-muted">Loading…</p></div> : !data?.length ? (
          <div className="ba-panel-body"><Empty title="No team members found" /></div>
        ) : (
          <ul className="ba-threads">
            {data.map((m) => {
              const mine = m.user_id === me;
              const label = mine ? email : `Team member`;
              return (
                <li key={m.id}>
                  <span className="ba-avatar sm">{initials(label)}</span>
                  <div><strong>{label}{mine ? " (you)" : ""}</strong><small>Joined {timeAgo(m.created_at)}</small></div>
                  <div className="ba-thread-meta">
                    <Pill tone="indigo">{m.role}</Pill>
                    <Pill tone={m.status === "active" ? "success" : m.status === "invited" ? "warning" : ""}>{m.status}</Pill>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </>
  );
}

export function SettingsPage({ workspace, email, onSignOut }) {
  const term = makeTerm(workspace);
  const words = [
    ["Customer", "customer"], ["Customers", "customers"], ["Appointment", "appointment"],
    ["Appointments", "appointments"], ["Staff", "staff_plural"],
  ];
  const state = workspace.cancelled_at ? "Ended" : workspace.suspended_at ? "Paused" : workspace.cancel_at ? `Ends ${formatLongDate(workspace.cancel_at, workspace.timezone)}` : "Active";
  return (
    <>
      <PageHead crumb="Management / Settings" title="Settings" sub="Your business details. Changes to these are made by the Zella team for now." />
      <div className="ba-grid-2">
        <section className="ba-panel">
          <div className="ba-panel-head"><div className="ba-panel-title"><div><h2>Business</h2></div></div></div>
          <dl className="ba-facts pad">
            <div><dt>Name</dt><dd>{workspace.name}</dd></div>
            <div><dt>Industry</dt><dd>{workspace.industry ?? "—"}</dd></div>
            <div><dt>Time zone</dt><dd>{workspace.timezone.replace("_", " ")}</dd></div>
            <div><dt>Plan</dt><dd><Pill tone={state === "Active" ? "success" : "warning"}>{state}</Pill></dd></div>
          </dl>
        </section>
        <section className="ba-panel">
          <div className="ba-panel-head"><div className="ba-panel-title"><div><h2>Your words</h2><p>How this workspace names things.</p></div></div></div>
          <dl className="ba-facts pad">
            {words.map(([label, key]) => <div key={key}><dt>{label}</dt><dd>{term(key)}</dd></div>)}
          </dl>
        </section>
        <section className="ba-panel">
          <div className="ba-panel-head"><div className="ba-panel-title"><div><h2>Your account</h2></div></div></div>
          <dl className="ba-facts pad">
            <div><dt>Signed in as</dt><dd>{email}</dd></div>
            <div><dt>Role</dt><dd>{workspace.role}</dd></div>
          </dl>
          <div className="ba-panel-foot"><span /><button type="button" className="ba-btn" onClick={onSignOut}><Icon name="logout" size="sm" />Sign out</button></div>
        </section>
      </div>
    </>
  );
}
