-- =========================================================
-- Zella: business suspension and cancellation
-- Run once in Supabase → SQL Editor (after zella_business_setup.sql).
--
-- Cancelling a business schedules it to stop at the end of its
-- current month. Until then everything keeps working, and the
-- cancellation can be undone. Suspension stops a business now.
-- =========================================================

alter table public.businesses
  add column if not exists suspended_at timestamptz,
  add column if not exists suspension_reason text,
  add column if not exists cancel_at timestamptz,
  add column if not exists cancel_requested_at timestamptz,
  add column if not exists cancellation_reason text,
  add column if not exists cancelled_at timestamptz;

comment on column public.businesses.cancel_at is
  'When a scheduled cancellation takes effect (end of the business''s current month).';

-- Suspend now: pause the AI receptionist and running automations,
-- remembering exactly what was running so reactivation restores it.
create or replace function public.zella_suspend_business(p_business_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_business businesses%rowtype;
  v_agents uuid[];
  v_automations uuid[];
begin
  select * into v_business from businesses where id = p_business_id for update;
  if not found then raise exception 'BUSINESS_NOT_FOUND'; end if;
  if v_business.cancelled_at is not null then raise exception 'BUSINESS_CANCELLED'; end if;
  if v_business.suspended_at is not null then raise exception 'ALREADY_SUSPENDED'; end if;

  select coalesce(array_agg(id), '{}') into v_agents
  from ai_agents where business_id = p_business_id and status = 'active';

  select coalesce(array_agg(id), '{}') into v_automations
  from automations where business_id = p_business_id and status = 'active';

  update ai_agents set status = 'paused', updated_at = now() where id = any(v_agents);
  update automations set status = 'paused', updated_at = now() where id = any(v_automations);

  update businesses
  set suspended_at = now(),
      suspension_reason = nullif(p_reason, ''),
      is_active = false,
      setup_data = setup_data || jsonb_build_object(
        'suspended_state', jsonb_build_object(
          'was_active', v_business.is_active,
          'agents', to_jsonb(v_agents),
          'automations', to_jsonb(v_automations)
        )
      ),
      updated_at = now()
  where id = p_business_id;
end;
$$;

-- Reactivate: put back exactly what suspension paused.
create or replace function public.zella_reactivate_business(p_business_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_business businesses%rowtype;
  v_state jsonb;
begin
  select * into v_business from businesses where id = p_business_id for update;
  if not found then raise exception 'BUSINESS_NOT_FOUND'; end if;
  if v_business.cancelled_at is not null then raise exception 'BUSINESS_CANCELLED'; end if;
  if v_business.suspended_at is null then raise exception 'NOT_SUSPENDED'; end if;

  v_state := coalesce(v_business.setup_data->'suspended_state', '{}'::jsonb);

  update ai_agents set status = 'active', updated_at = now()
  where business_id = p_business_id and status = 'paused'
    and id::text in (select jsonb_array_elements_text(coalesce(v_state->'agents', '[]')));

  update automations set status = 'active', updated_at = now()
  where business_id = p_business_id and status = 'paused'
    and id::text in (select jsonb_array_elements_text(coalesce(v_state->'automations', '[]')));

  update businesses
  set suspended_at = null,
      suspension_reason = null,
      is_active = coalesce((v_state->>'was_active')::boolean, true),
      setup_data = setup_data - 'suspended_state',
      updated_at = now()
  where id = p_business_id;
end;
$$;

-- Carry out cancellations whose date has passed. Safe to run any time;
-- it runs hourly (pg_cron) and whenever the admin dashboard loads.
create or replace function public.zella_process_cancellations()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ids uuid[];
begin
  select coalesce(array_agg(id), '{}') into v_ids
  from businesses
  where cancel_at is not null and cancel_at <= now() and cancelled_at is null;

  if cardinality(v_ids) = 0 then return 0; end if;

  update ai_agents set status = 'disabled', updated_at = now()
  where business_id = any(v_ids) and status <> 'disabled';

  update automations set status = 'disabled', updated_at = now()
  where business_id = any(v_ids) and status <> 'disabled';

  update subscriptions set status = 'cancelled'
  where business_id = any(v_ids)
    and status in ('trial', 'active', 'renewal_due', 'past_due', 'grace_period');

  update businesses
  set cancelled_at = now(),
      is_active = false,
      updated_at = now()
  where id = any(v_ids);

  insert into audit_logs (action, business_id, entity_type, entity_id, new_data)
  select 'business.cancelled', id, 'business', id,
         jsonb_build_object('cancel_at', cancel_at, 'reason', cancellation_reason)
  from businesses where id = any(v_ids);

  return cardinality(v_ids);
end;
$$;

revoke all on function public.zella_suspend_business(uuid, text) from public, anon, authenticated;
revoke all on function public.zella_reactivate_business(uuid) from public, anon, authenticated;
revoke all on function public.zella_process_cancellations() from public, anon, authenticated;
grant execute on function public.zella_suspend_business(uuid, text) to service_role;
grant execute on function public.zella_reactivate_business(uuid) to service_role;
grant execute on function public.zella_process_cancellations() to service_role;

-- Run the cancellation check every hour if pg_cron is enabled.
-- (Supabase → Database → Extensions → pg_cron.) The dashboard also runs it
-- on load, so cancellations still happen without pg_cron, just less promptly.
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.unschedule(jobid) from cron.job where jobname = 'zella-process-cancellations';
    perform cron.schedule('zella-process-cancellations', '5 * * * *',
                          'select public.zella_process_cancellations()');
    raise notice 'Hourly cancellation check scheduled with pg_cron.';
  else
    raise notice 'pg_cron is not enabled: cancellations will be processed when the admin dashboard loads.';
  end if;
end $$;
