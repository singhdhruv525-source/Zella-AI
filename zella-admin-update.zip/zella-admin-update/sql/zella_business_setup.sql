-- =========================================================
-- Zella: full client setup (run once in Supabase → SQL Editor)
--
-- Replaces the earlier zella_provision_business function.
-- Adds per-client terminology, wizard setup data, and the
-- server-only functions the setup wizard uses.
-- =========================================================

-- 1. Per-client data on the business
alter table public.businesses
  add column if not exists terminology_overrides jsonb not null default '{}'::jsonb,
  add column if not exists setup_data jsonb not null default '{}'::jsonb;

comment on column public.businesses.terminology_overrides is
  'Client-specific CRM terms that replace the industry defaults (only changed keys).';
comment on column public.businesses.setup_data is
  'Setup wizard choices: owner phone, phone-number and integration preferences. Live connections live in integrations.';

-- 2. Remove the earlier one-shot function (it used an invalid agent status)
drop function if exists public.zella_provision_business(text, uuid, text, text, text, text, uuid);

-- 3. Create a draft business with its modules and AI receptionist
create or replace function public.zella_create_business_draft(p_fields jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_industry    uuid := (p_fields->>'industry_id')::uuid;
  v_business_id uuid;
  v_agent_id    uuid;
  v_modules     integer;
  v_timezone    text := coalesce(nullif(p_fields->>'timezone', ''), 'America/New_York');
begin
  if not exists (select 1 from industries where id = v_industry and is_active) then
    raise exception 'INDUSTRY_NOT_FOUND';
  end if;

  insert into businesses (
    name, legal_name, industry_id, email, phone, website,
    address_line_1, address_line_2, city, state, postal_code, country,
    timezone, onboarding_status, is_active
  )
  values (
    p_fields->>'name',
    nullif(p_fields->>'legal_name', ''),
    v_industry,
    nullif(p_fields->>'email', ''),
    nullif(p_fields->>'phone', ''),
    nullif(p_fields->>'website', ''),
    nullif(p_fields->>'address_line_1', ''),
    nullif(p_fields->>'address_line_2', ''),
    nullif(p_fields->>'city', ''),
    nullif(p_fields->>'state', ''),
    nullif(p_fields->>'postal_code', ''),
    coalesce(nullif(p_fields->>'country', ''), 'US'),
    v_timezone,
    'business_info',
    false            -- workspace stays inactive until setup is finished
  )
  returning id into v_business_id;

  -- All of the industry's active modules start enabled; step 4 adjusts them.
  insert into business_modules (business_id, module_id, enabled)
  select v_business_id, m.id, true
  from industry_modules m
  where m.industry_id = v_industry and m.is_active;
  get diagnostics v_modules = row_count;

  -- AI receptionist is created disabled; it goes live only after setup and phone connection.
  insert into ai_agents (business_id, name, agent_type, status, channels, is_default)
  values (v_business_id, 'AI Receptionist', 'receptionist', 'disabled', '{}', true)
  returning id into v_agent_id;

  insert into ai_agent_configs (agent_id, business_context)
  values (
    v_agent_id,
    jsonb_build_object(
      'business_name', p_fields->>'name',
      'industry_id',   v_industry,
      'timezone',      v_timezone
    )
  );

  return jsonb_build_object(
    'business_id',     v_business_id,
    'agent_id',        v_agent_id,
    'modules_enabled', v_modules
  );
end;
$$;

-- 4. Change a draft's industry: resets its terminology and modules
create or replace function public.zella_change_business_industry(
  p_business_id uuid,
  p_industry_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from industries where id = p_industry_id and is_active) then
    raise exception 'INDUSTRY_NOT_FOUND';
  end if;

  update businesses
  set industry_id = p_industry_id,
      terminology_overrides = '{}'::jsonb,
      updated_at = now()
  where id = p_business_id;

  delete from business_modules where business_id = p_business_id;

  insert into business_modules (business_id, module_id, enabled)
  select p_business_id, m.id, true
  from industry_modules m
  where m.industry_id = p_industry_id and m.is_active;
end;
$$;

-- 5. Set which of the industry's modules are enabled for a business
create or replace function public.zella_set_business_modules(
  p_business_id uuid,
  p_enabled     uuid[]
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_industry uuid;
  v_enabled  integer;
begin
  select industry_id into v_industry from businesses where id = p_business_id;

  if v_industry is null then
    raise exception 'BUSINESS_NOT_FOUND';
  end if;

  if exists (
    select 1 from unnest(coalesce(p_enabled, '{}')) as e(id)
    where not exists (
      select 1 from industry_modules m
      where m.id = e.id and m.industry_id = v_industry and m.is_active
    )
  ) then
    raise exception 'MODULE_NOT_AVAILABLE';
  end if;

  delete from business_modules where business_id = p_business_id;

  insert into business_modules (business_id, module_id, enabled)
  select p_business_id, m.id, m.id = any(coalesce(p_enabled, '{}'))
  from industry_modules m
  where m.industry_id = v_industry and m.is_active;

  select count(*) into v_enabled
  from business_modules
  where business_id = p_business_id and enabled;

  return v_enabled;
end;
$$;

-- 6. Move onboarding forward (never backwards)
create or replace function public.zella_advance_onboarding(
  p_business_id uuid,
  p_status      text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order text[] := array[
    'started', 'business_info', 'owner_setup', 'industry_setup', 'ai_setup',
    'communications_setup', 'automation_setup', 'testing', 'ready', 'active'
  ];
begin
  if array_position(v_order, p_status) is null then
    raise exception 'INVALID_STATUS';
  end if;

  update businesses
  set onboarding_status = p_status,
      updated_at = now()
  where id = p_business_id
    and onboarding_status not in ('paused', 'failed')
    and coalesce(array_position(v_order, onboarding_status), 0)
        < array_position(v_order, p_status);
end;
$$;

-- 7. Only the server can call these
revoke all on function public.zella_create_business_draft(jsonb) from public, anon, authenticated;
revoke all on function public.zella_change_business_industry(uuid, uuid) from public, anon, authenticated;
revoke all on function public.zella_set_business_modules(uuid, uuid[]) from public, anon, authenticated;
revoke all on function public.zella_advance_onboarding(uuid, text) from public, anon, authenticated;

grant execute on function public.zella_create_business_draft(jsonb) to service_role;
grant execute on function public.zella_change_business_industry(uuid, uuid) to service_role;
grant execute on function public.zella_set_business_modules(uuid, uuid[]) to service_role;
grant execute on function public.zella_advance_onboarding(uuid, text) to service_role;
